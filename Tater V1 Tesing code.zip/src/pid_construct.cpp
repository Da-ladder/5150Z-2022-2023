#include "vex.h"
#include "math.h"

using namespace vex;

double x = 0;
double y = 0;

using namespace vex;

void pid(int x, int y) {
   Drivetrain.setStopping(brake);
}

double result = tan(y/x);
double travel = 0;
double target = 0;
double error = 0;
double setpoint = 0;
double m_power = 0;
double sensor_value = 0;
double kP = 0;
double kI = 0;
double kD = 0;
double integral = 0;
double derivative = 0;
double prevError = 0;

void myPID(int setpoint) 
{ 
   while (!(travel == target))
   {
   error = setpoint - sensor_value;
  integral = integral + error;
   if (error == 0 or error > setpoint)
	  integral = 0;
   if (error > 4000)
	integral = 0;
   derivative = error - prevError;
   prevError = error;
   m_power = error*kP + integral*kI + derivative*kD; 
   vex::task::sleep(15);
   }
}
//All units in mm currently. Adjust using math forulas 
