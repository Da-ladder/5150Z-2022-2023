#include "Odom.h"
#include "vex.h"
#include "Pid.h"

void auto_chassis::odom () {
  bool AUX = false;
  double X = 0; //X offset
  double Y = 0; //Y offset
  double RB = 2; //Back to center length
  double tpr = 360;  //Degrees per single encoder rotation
  double SL = 2.497; //distance from tracking center to middle of left wheel 3.125 //2 = 100
  double SR = 2.497; //distance from tracking center to middle of right wheel 
  double Theta2 = 0;
  double currentR = 0;
  double currentL = 0;
  double currentA = 0;
  double DeltaL = 0;
  double DeltaR = 0;
  double DeltaA = 0;
  double DeltaTheta = 0;
  double OdomHeading = 0;
  double PreviousL = 0;
  double PreviousR = 0;
  double PreviousA = 0;
  double SideChord = 0;
  double acord = 0;
  double DeltaYSide = 0;
  double DeltaXSide = 0;
  double DeltaXBack = 0;
  double PrevIntertia = 0;
  double Inertial;
  wait(1, sec);
  while (odom_enabled) {
    currentR = rtracking.position(degrees);
    currentL = lTracking.position(degrees);
    currentA = atracking.position(degrees);
    
    DeltaL = ((currentL - PreviousL) * 8.63938) / tpr;
    DeltaR = ((currentR - PreviousR) * 8.63938) / tpr;
    DeltaA = ((currentA - PreviousA) * 8.63938) / tpr;
    //Inertial = (-IMU.rotation(deg) * M_PI/180) - PrevIntertia;

    DeltaTheta = (DeltaR - DeltaL) / (SL + SR);//ANGLE IS IN RADS 

    if(DeltaTheta == 0) {  //If there is no change in angle
      Y += DeltaL * sin (Theta2);
      X += DeltaL * cos (Theta2);
    //If there is a change in angle, it will calculate the changes in X,Y from chords of an arc/circle.
    } else {  //If the angle changes
      if (AUX) {
       acord = 2 * ((DeltaA / DeltaTheta) + RB) * sin (DeltaTheta / 2);
       DeltaYSide = SideChord * sin (Theta2 + (DeltaTheta / 2));
       DeltaXBack = acord * sin (Theta2 + (DeltaTheta / 2));

       Theta2 += DeltaTheta; //delta theta
       Y += DeltaYSide;
       X += DeltaXBack;
      } else {
       SideChord = 2 * ((DeltaL / DeltaTheta) + SL) * sin (DeltaTheta / 2);

       //BackChord = 2 * ((DeltaB / DeltaTheta) + SS) * sin (DeltaTheta / 2);
       DeltaYSide = SideChord * cos (Theta2 + (DeltaTheta / 2));
       DeltaXSide = SideChord * sin (Theta2 + (DeltaTheta / 2));
       //DeltaXBack = BackChord * sin (Theta + (DeltaTheta / 2));
       //DeltaYBack = -BackChord * cos (Theta + (DeltaTheta / 2));
       Theta2 += DeltaTheta; //delta theta
       Y += DeltaXSide;
       X += DeltaYSide;
      }
      
      
    }
    //Odom heading is converting the radian value of Theta into degrees
    OdomHeading = Theta2 * 57.295779513;

    //Converts values into newer values to allow for code to effectively work in next cycle
    curen_x = X;
    curen_y = Y;
    glob_Theta.store(OdomHeading);
    
    Brain.Screen.clearScreen();
    Brain.Screen.setCursor(7, 1);
    Brain.Screen.print("X CORD :  ");
    Brain.Screen.print(curen_x); //curen_y
    Brain.Screen.setCursor(8, 1);
    Brain.Screen.print("Y CORD :   ");
    Brain.Screen.print(curen_y); //curen_x
    Brain.Screen.setCursor(9, 1);
    Brain.Screen.print("ANGLE :   ");
    Brain.Screen.print(OdomHeading);
    Brain.Screen.render();
    
    PreviousL = currentL;
    PreviousR = currentR;
    PreviousA = currentA;
    //PreviousB = currentB;
    PrevIntertia = Inertial;
    DeltaTheta = 0;
    Inertial = 0;
    wait(10, msec);
  }
}


void auto_chassis::trig_cal (double tar_x, double tar_y, bool backside) { // IN MAKE IT WORK STAGE --> MAKE IT RIGHT --> MAKE IT FAST
  wait(0.15, sec); //GLOBAL DELAY
  IMU_PID travel;

  double cur_x = curen_x;
  double cur_y = curen_y;
  double turn_angle = 0;
  double travel_dis = 0;
  double trig_angle = 0;
  double trig_angle_deg = 0;

  double dis_x = tar_x - cur_x;
  double dis_y = tar_y - cur_y;
  
  

  if (dis_x == 0) {
    if (dis_y < 0) { turn_angle = -180; } else { turn_angle = 0; }
    travel_dis = abs(dis_y);
  }
  else {
    //trig_angle = atan(dis_y / dis_x);
    trig_angle = atan2(dis_y, dis_x);
    travel_dis = hypot(dis_x, dis_y);
    trig_angle_deg = trig_angle * 57.295779513;
    trig_angle_deg = trig_angle_deg > 180 ? trig_angle_deg : trig_angle_deg - 180.0;
  }

  if (backside) { travel_dis = -travel_dis; turn_angle = turn_angle - 180; }
  Controller1.Screen.clearScreen();
  Controller1.Screen.setCursor(1, 1);
  Controller1.Screen.print("TURN ANGLE:  ");
  Controller1.Screen.print(turn_angle);
  Controller1.Screen.setCursor(2, 1);
  //Controller1.Screen.print("dis_x:  ");
  //Controller1.Screen.print(dis_x);
  Controller1.Screen.print("dis_x:  ");
  Controller1.Screen.print(dis_x);
  Controller1.Screen.setCursor(3, 1);
  //Controller1.Screen.print("dis_y:  ");
  //Controller1.Screen.print(dis_y);
  Controller1.Screen.print("dis_y:  ");
  Controller1.Screen.print(dis_y);
  //wait(4, sec);
  travel.turn(turn_angle, true, false, 4);
  wait(0.05, sec);
  travel.turn(turn_angle, true, false, 2);
  travel.test(travel_dis, turn_angle, 12);
}

double auto_chassis::curen_x = 0;
double auto_chassis::curen_y = 0;