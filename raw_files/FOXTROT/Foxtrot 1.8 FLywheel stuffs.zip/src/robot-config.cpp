#include "vex.h"
#include <atomic>
#include <array>

using namespace vex;

// A global instance of brain used for printing to the V5 brain screen
brain Brain;

// CONTROLLER DEFINTION
controller Controller1 = controller(primary);

// CHASSIS MOTOR DEFINITIONS A = front B = Back
motor leftMotorA = motor(PORT17, ratio6_1, false); //blue cartridge
motor leftMotorB = motor(PORT20, ratio6_1, false); //blue cartridge
motor leftMotorC = motor(PORT14, ratio6_1, false);
motor rightMotorA = motor(PORT11, ratio6_1, true); //blue cartridge
motor rightMotorB = motor(PORT18, ratio6_1, true); //blue cartridge
motor rightMotorC = motor(PORT12, ratio6_1, true);

//FLYWHEEL DEFINITION
motor flywheel = motor(PORT13, ratio6_1, false); //blue cartridge

//INTAKE DEFINITION
motor intake = motor(PORT10, ratio6_1, true);

// PNEUMATICS DEFINITION
digital_out mag_lift = digital_out(Brain.ThreeWirePort.D);
digital_out booper = digital_out(Brain.ThreeWirePort.B);
digital_out feeder = digital_out(Brain.ThreeWirePort.C);
digital_out t_junction = digital_out(Brain.ThreeWirePort.A);

// IMU DEFINTION
inertial IMU = inertial(PORT9);

// TRACKING WHEEL DEFINITIONS
rotation lTracking = rotation(PORT6, false); //tracking is not in use currently.
rotation rtracking = rotation(PORT4, true);
rotation atracking = rotation(PORT1, true);
rotation flywheel_sped = rotation(PORT7, true);

// OPTICAL SENSOR DEFINE
optical color_sense = optical(PORT8);

// MOTOR GROUPS
motor_group leftDrive(leftMotorA, leftMotorB, leftMotorC);
motor_group rightDrive(rightMotorA, rightMotorB, leftMotorC);

// GLOBAL VARIABLES

double auto_num = 0;
bool confirm = false;
bool intake_toggle = false;
bool fly_tog = false;
std::atomic<bool> auton_flywheel(false);
std::atomic<double> glob_Theta(0);
std::atomic<double> flywheel_velocity(0);
std::atomic<bool> odom_enabled(false);
std::atomic<bool> driver_Ready(false);
//double curen_x = 0;
//double curen_y = 0;



// DRIVE BASE
smartdrive chassis = smartdrive(leftDrive, rightDrive, IMU, 319.19, 320, 293, mm, 0.42857142857142855);
/**
 * Used to initialize code/tasks/devices added using tools in VEXcode Pro.
 *
 * This should be called at the start of your int main function.
 */
void vexcodeInit(void) {
  // Nothing to initialize
}