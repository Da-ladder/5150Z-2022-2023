#pragma once
// CONVERSION FILE NOT IN USE FOR PID
#include "vex.h"

using namespace vex;

double inchesToTicks(double inches);
double ticksToInches(double ticks);