#pragma once
#include "vex.h"
#include "Odom.h"
#include "Flywheel.h"
#include "Pid.h"

using namespace vex;

struct auto_routes {
  chassis_Set movement;
  auto_chassis attempt;// = new auto_chassis();
  IMU_PID auton;

  void leftEasySideSixShot();
  void skills_route();
  void rightHardSideRoller();
  void backUpDischarge();

};

struct dianostics {
  void temps();
  void power_speed();
  void flywheel_info();

};