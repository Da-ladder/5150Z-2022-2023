using namespace vex;
#include <atomic>

extern brain Brain;

// VEXcode devices
extern smartdrive chassis;
extern controller Controller1;




extern motor leftMotorA;
extern motor leftMotorB;
extern motor leftMotorC;
extern motor rightMotorA;
extern motor rightMotorB;
extern motor rightMotorC;



extern motor_group leftDrive;
extern motor_group rightDrive;



extern motor flywheel;
extern motor intake;

extern digital_out booper;
extern digital_out t_junction;
extern digital_out feeder;
extern digital_out mag_lift;


extern inertial IMU;
extern optical color_sense;

extern rotation lTracking;
extern rotation rtracking;
extern rotation atracking;

extern rotation flywheel_sped;

extern double inchesToTicks(double inches);
extern double ticksToInches(double ticks);

extern void chassisControlTank();
extern void PrimaryControlMap();
extern void SecondaryControlMap();



// EXTERN GLOBAL VARIABLES
extern std::atomic<bool> auton_flywheel;
extern std::atomic<double> flywheel_velocity;
extern std::atomic<double> glob_Theta;
extern std::atomic<bool> odom_enabled;
extern std::atomic<bool> driver_Ready;
extern double auto_num;
extern bool confirm;
extern bool intake_toggle;
extern bool fly_tog;
//extern double curen_x = 0;
//extern double curen_y = 0;


/**
 * Used to initialize code/tasks/devices added using tools in VEXcode Pro.
 *
 * This should be called at the start of your int main function.
 */
void vexcodeInit(void);
