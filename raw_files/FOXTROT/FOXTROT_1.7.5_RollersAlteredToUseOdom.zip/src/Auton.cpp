#include "vex.h"
#include "Auton.h"

using namespace vex;

chassis_Set movement;
auto_chassis attempt;// = new auto_chassis();
IMU_PID auton;

void auto_routes::leftEasySideSixShot() { //should probs document this tbh
  //roll roller and turn toward disks
  /*
  booper.set(true);
  movement.move(-3, -3);
  wait(0.2, sec);
  intake.spin(fwd, 12, voltageUnits::volt);
  wait(0.15, sec);
  intake.spin(fwd, 0, voltageUnits::volt);
  movement.move(5, 5);
  wait(0.2, sec);
  movement.move(0, 0);
  
  auton.turn(43.9, true, false, 3);
  wait(0.05, sec);

  //knock over disks
  auton.test(15, 10);
  movement.move(10.7, 10.7);
  wait(0.22, sec);
  movement.move(0, 0);
  wait(0.05, sec);

  //INTAKE disks
  intake.spin(fwd, -12, voltageUnits::volt);
  movement.move(1.2, 1.2);
  wait(2, sec);
  intake.spin(fwd, -12, voltageUnits::volt);
  movement.move(4, 4);
  wait(1, sec);
  movement.move(0, 0);
  auton.turn(-37, true, false, 1);
  wait(0.95, sec); //change this intake faster plx
  intake.spin(fwd, 0, voltageUnits::volt);
  //auton.turn(-41, true, false, 0.5);
  booper.set(false);
  wait(0.4, sec);
  
  auton.rep_shot(3, 1, 1);


  flywheel_velocity.store(9000);
  //booper.set(true);
  auton.turn(-133, true, false, 1);
  wait(0.05, sec);
  auton.turn(-133, true, false, 1);
  //intake.spin(fwd, -12, voltageUnits::volt);
  auton.test(-57, 12);
  //auton.turn(-90, true, false, 1);
  //auton.test(-6, 12);
  //intake.spin(fwd, 12, voltageUnits::volt);
  movement.move(-5, -10);
  wait(0.5, sec);
  movement.move(-3, -3);
  //intake.spin(fwd, 0, voltageUnits::volt);
  //wait(0.5, sec);

  intake.spin(fwd, 12, voltageUnits::volt);
  wait(0.25, sec);
  intake.spin(fwd, 0, voltageUnits::volt);
  movement.move(0, 0);
  //wait(0.2, sec);
  //movement.move(0, 0);
  */





  
  
}


void auto_routes::skills_route() {
  Brain.Timer.reset();
  booper.set(true);
  //skills auton = get 4 rollers, targeting 9 - 12 shots depending on time left

  //roller 1 -8.94
  
  movement.move(-2, -2);
  wait(0.2, sec);
  intake.spin(fwd, -12, voltageUnits::volt);
  wait(0.4, sec);
  intake.spin(fwd, 0, voltageUnits::volt);
  attempt.trig_cal(0, 0, false);
  intake.spin(fwd, -12, voltageUnits::volt);
  wait(0.05, sec);
  attempt.trig_cal(10, 11.5, false);
  wait(0.05, sec);
  auton.turn(-70, true, false, 4);
  intake.spin(fwd, 0, voltageUnits::volt);

  //roller 2
  movement.move(-4, -4);
  wait(0.2, sec);
  movement.move(-2, -2);
  wait(0.5, sec);
  intake.spin(fwd, -12, voltageUnits::volt);
  wait(0.4, sec);
  intake.spin(fwd, 0, voltageUnits::volt);
  movement.move(0, 0); 
  attempt.trig_cal(10, 11.5, false);
  intake.spin(fwd, -12, voltageUnits::volt);

  
  //VOLLY 1
  attempt.trig_cal(63, 10, false);
  auton.rep_turn(-1, 2, 0.05, 0.75);
  auton.rep_shot2(3, 0, 1);

  
  //VOLLY 2
  booper.set(false);
  intake.spin(fwd, -12, voltageUnits::volt);
  flywheel_velocity.store(15700);
  attempt.trig_cal(49, 2, false);
  movement.move(5, 5);
  wait(0.3, sec);
  movement.move(0, 0);
  wait(0.1, sec);
  attempt.trig_cal(51.5, -12.5, false);
  //auton.turn(-42, true, false, 2);
  //auton.test(29, -42, 12);
  attempt.trig_cal(61.6, -26.3, false);
  auton.rep_turn(34.3, 2, 0.05, 0.75);
  auton.rep_shot2(3, 0, 1);

  attempt.trig_cal(78, -45, false);//???
  intake.spin(fwd, -12, voltageUnits::volt);
  movement.move(2.5, 2.5);
  wait(2, sec);
  movement.move(0, 0);

  attempt.trig_cal(97, -43, false);
  auton.rep_turn(60, 2, 0.05, 0.75); //-290
  auton.rep_shot2(3, 0, 1);
  //attempt.trig_cal(74, -71.9, false);




  Controller1.Screen.clearScreen();
  Controller1.Screen.setCursor(1, 1);
  Controller1.Screen.print(Brain.timer(sec));





}


void auto_routes::rightHardSideRoller() { //do a quick auton roller for the right side
/*
  booper.set(true);
  movement.move(-3, -3);
  wait(0.2, sec);
  intake.spin(fwd, 12, voltageUnits::volt);
  wait(0.15, sec);
  intake.spin(fwd, 0, voltageUnits::volt);
  movement.move(5, 5);
  wait(0.2, sec);
  movement.move(0, 0);
  
  auton.turn(43.9, true, false, 1);
  wait(0.05, sec);
  
  
  //knock over disks
  auton.test(15, 10);
  movement.move(10.7, 10.7);
  wait(0.22, sec);
  movement.move(0, 0);
  wait(0.05, sec);

  //INTAKE disks
  intake.spin(fwd, -12, voltageUnits::volt);
  movement.move(1.2, 1.2);
  wait(2, sec);
  intake.spin(fwd, -12, voltageUnits::volt);
  movement.move(4, 4);
  wait(0.5, sec); //1 sec
  movement.move(0, 0);
  auton.turn(-34.8, true, false, 0.5);
  wait(2.95, sec); //change this intake faster plx dd
  intake.spin(fwd, 0, voltageUnits::volt);
  //auton.turn(-41, true, false, 0.5);
  booper.set(false);
  wait(0.4, sec);
  
  auton.rep_shot(3, 1, 1);
  movement.move(0, 0);
  flywheel_velocity.store(15000);
  */
  

}


void auto_routes::backUpDischarge() { //back up discharge is test code as of nowssede
  //booper.set(false);
  //wait(4, sec);
  //auton.rep_shot(3, 1, 1);
  //auton.turn(45, true, false, 1);
  //wait(0.05, sec);
  //auton.turn(90, true, false, 1);
  //wait(2, sec);
  //auton.test(48, 12);
  attempt.trig_cal(20, -20, false);
  //attempt.trig_cal(0, 0, false);
  }



void dianostics::temps() {
  Brain.Screen.clearScreen();
  Controller1.Screen.clearScreen();
  Controller1.Screen.setCursor(1, 1);
  Controller1.Screen.print(IMU.rotation(degrees));
  
  Brain.Screen.setCursor(1,1);
  Brain.Screen.print(IMU.orientation(yaw, degrees));
  Brain.Screen.setCursor(2,1);
  Brain.Screen.print("left motor A TEMP: ");
  Brain.Screen.print(leftMotorA.temperature(temperatureUnits::celsius));
  Brain.Screen.setCursor(3,1);
  Brain.Screen.print("left motor B TEMP: ");
  Brain.Screen.print(leftMotorB.temperature(temperatureUnits::celsius));
  Brain.Screen.setCursor(4,1);
  Brain.Screen.print("right motor A TEMP: ");
  Brain.Screen.print(rightMotorA.temperature(temperatureUnits::celsius));
  Brain.Screen.setCursor(6,1);
  Brain.Screen.print("right motor B TEMP: ");
  Brain.Screen.print(rightMotorB.temperature(temperatureUnits::celsius));
  Brain.Screen.setCursor(5,1);
  Brain.Screen.print("Flywheel TEMP: ");
  Brain.Screen.print(flywheel.temperature(temperatureUnits::celsius));
  Brain.Screen.setCursor(6,1);
  Brain.Screen.print("Intake TEMP: ");
  Brain.Screen.print(intake.temperature(temperatureUnits::celsius));
  Brain.Screen.render();
}

void dianostics::power_speed() {
  Brain.Screen.clearScreen();
  Brain.Screen.setCursor(1,1);
  Brain.Screen.print("left motor A Voltage (watts): ");
  Brain.Screen.print(leftMotorA.voltage());
  Brain.Screen.setCursor(2,1);
  Brain.Screen.print("left motor B Voltage (watts): ");
  Brain.Screen.print(leftMotorB.voltage());
  Brain.Screen.setCursor(3,1);
  Brain.Screen.print("right motor A Voltage (watts): ");
  Brain.Screen.print(rightMotorA.voltage());
  Brain.Screen.setCursor(4,1);
  Brain.Screen.print("right motor B Voltage (watts): ");
  Brain.Screen.print(rightMotorB.voltage());
  Brain.Screen.setCursor(5,1);
  Brain.Screen.print("left motor A SPEED (RPM 600 CAP): ");
  Brain.Screen.print(leftMotorA.velocity(velocityUnits::rpm));
  Brain.Screen.setCursor(6,1);
  Brain.Screen.print("left motor B SPEED (RPM 600 CAP): ");
  Brain.Screen.print(leftMotorB.velocity(velocityUnits::rpm));
  Brain.Screen.setCursor(7,1);
  Brain.Screen.print("right motor A SPEED (RPM 600 CAP): ");
  Brain.Screen.print(rightMotorA.velocity(velocityUnits::rpm));
  Brain.Screen.setCursor(8,1);
  Brain.Screen.print("right motor B SPEED (RPM 600 CAP): ");
  Brain.Screen.print(rightMotorB.velocity(velocityUnits::rpm));
  Brain.Screen.render();
}

void dianostics::flywheel_info() {
  Controller1.Screen.clearScreen();
  Controller1.Screen.setCursor(2, 1);
  Controller1.Screen.print(IMU.rotation(deg));
}