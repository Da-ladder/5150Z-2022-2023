#include "vex.h"
#include <math.h>
#include <cmath>
#include <atomic>
#include "Pid.cpp"

using namespace vex;

//LOCAL VARIABLE DECLARATIONS WITH ATOMIC


class auto_chassis {
  private:
   std::atomic<double> current_x_y[2];

  public:
   void odom () {
     while (odom_enabled) {
       //INPUT ODOM CODE FROM GRAPHICAL ODOM WHEN FULLY TUNED. DO NOT ATTEMPT AT THIS TIME. MAKE THE CODE WORK WITHOUT ODOM FOR NOW.
     }
   }

   void trig_cal (double tar_x, double tar_y) { // IN MAKE IT WORK STAGE --> MAKE IT RIGHT --> MAKE IT FAST
     IMU_PID travel;

     double cur_x = current_x_y[1].load();
     double cur_y = current_x_y[2].load();
     double turn_angle = 0;
     double travel_dis = 0;
     double trig_angle = 0;
     double trig_angle_deg = 0;

     double dis_x = tar_x - cur_x;
     double dis_y = tar_y - cur_y;

     if (dis_x == 0) {
       if (dis_y < 0) { turn_angle = -90; } else { turn_angle = 90; }
       travel_dis = abs(dis_y);
     }
     else {
       trig_angle = atan(dis_y / dis_x);
       travel_dis = sqrt(pow(dis_y, 2) + pow(dis_x, 2));
       trig_angle_deg = trig_angle * 57.295779513;

       if (dis_y > 0 && dis_x > 0) {
         turn_angle = trig_angle_deg;
       } else if (dis_y > 0 && dis_x < 0) {
         turn_angle = 180 + trig_angle_deg;
       } else if (dis_y < 0 && dis_x < 0) {
         turn_angle = -180 + trig_angle_deg;
       } else if (dis_y < 0 && dis_x > 0) {
         turn_angle = trig_angle_deg;
       } else { turn_angle = trig_angle_deg; }
      // EXCUTES THE RESULTS DIRECTLY
      travel.rep_turn(turn_angle, 3, 0.05, true);
      travel.test(travel_dis, 12);
     }
   }

  

};