#include "vex.h"
#include <iostream>
 
using namespace vex;
using namespace std;


struct chassis_Set {
 
 void reset() {
   leftMotorA.resetRotation();
   leftMotorB.resetRotation();
   rightMotorA.resetRotation();
   rightMotorB.resetRotation();
 }
 
 // CREATES A METHOD TO APPLY POWER TO CHASSIS
 void move(double rPower, double lPower) {
   leftMotorA.spin(fwd, lPower, voltageUnits::volt);
   rightMotorA.spin(fwd, rPower, voltageUnits::volt);
   rightMotorB.spin(fwd, rPower, voltageUnits::volt);
   leftMotorB.spin(fwd, lPower, voltageUnits::volt);
   leftMotorC.spin(fwd, lPower, voltageUnits::volt);
   rightMotorC.spin(fwd, rPower, voltageUnits::volt);
 }
 
 void fly_vol(double vol) {
   flywheel.spin(fwd, vol, voltageUnits::volt);
 }
 
 // CREATES A METHOD TO BRAKE THE CHASSIS MOTORS
 void brake() {
   leftMotorA.setBrake(hold);
   rightMotorA.setBrake(hold);
   rightMotorB.setBrake(hold);
   leftMotorB.setBrake(hold);
   leftMotorC.setBrake(hold);
   rightMotorC.setBrake(hold);
 }
 
 // CREATES A METHOD TO BOTH APPLY ZERO VOLTAGE AND BRAKE MOTORS
 void rest() {
   move(0, 0);
   brake();
 }
};