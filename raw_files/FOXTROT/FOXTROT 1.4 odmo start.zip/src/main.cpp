/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       VEX                                                       */
/*    Created:      Thu Sep 26 2019                                           */
/*    Description:  Competition Template                                      */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// ---- END VEXCODE CONFIGURED DEVICES ----


#include "GUI.cpp"

#include "vex.h"
#include "Vision_cal.h"
#include <iostream>
#include <sstream>
#include <thread>
#include <atomic>


using namespace vex;

vex::mutex m;

// A global instance of competition
competition Competition;

// define your global instances of motors and other devices here ssddsbbhj


void flywheel_pid() {
  while(true) {
    if (auton_flywheel.load()) {
     chassis_Set flywheel;
     double report_num = 0;
     double time_report = 50;
     double report_rate = 50; // in ms
     double current_velocity = flywheel_sped.velocity(velocityUnits::dps);
     double error;
     double kp = 1.0001; //0.000025
     double tbh_approx = 10; //9 for 15k tune and tinker 9.1
     double tbh_at_zero = 10; //tune as well 9.3
     double tbh = 0;
     double prev_error = 0;
     bool first_cross = true;

      while (auton_flywheel.load()) { // global var
       current_velocity = flywheel_sped.velocity(velocityUnits::dps);
       error = flywheel_velocity.load() - current_velocity; //flywheel veo is protected in case of race conditions ffhjssxdeed


       tbh = tbh + (error * kp); 
     
       if (tbh > 12) { //SET MAX VOLTAGE TO 12 AND LOWEST TO 0
         tbh = 12;
        } else if (tbh < 0) {
         tbh = 0;
        }


        if (signbit(error) != signbit(prev_error)) { // ZERO CROSSING CHECK s
         if (first_cross) {
           tbh = tbh_approx; // FIRST TIME SET TO APPROX VALUES
           first_cross = false;
          } else {
           tbh = 0.5 * (tbh + tbh_at_zero); // TAKE BACK HALF ALGO
           tbh_at_zero = tbh;
          }
        }

     /*
     std::cout << "error :" << error << "NEW BATCH" << std::endl; //endl starts new line COUT displays to monitor/TERMINAL hk
     std::cout << "rot :" << current_velocity << std::endl; // REMOVE WHEN IN COMP MODE
     std::cout << "tbh_at_zero :" << tbh_at_zero << std::endl; //DISPLAY STATS TO TERMINAL THROUGH CONTROLLER WIRE EVERY 7 MSEC
     std::cout << "sens_avg :" << kp << std::endl;
     */
     
     if (report_rate == time_report) { std::cout <<current_velocity << std::endl; time_report = 0; report_num += 1; }

     flywheel.fly_vol(tbh);
     prev_error = error;
     time_report += 1;
     wait(1, msec);
     //if (!Competition.isEnabled()) {
     //  auton_flywheel.store(false);
     //  std::cout << report_num << std::endl;
     //}
    }
  }
  this_thread::yield();
  }
  
}


void selectAuton() {
  GUI auton_pick;

  auton_pick.selectAuton();

}


void odom_start() {
  auto_chassis full_auto;
  odom_enabled.store(true);
  full_auto.odom();
  std::terminate();
}

/*---------------------------------------------------------------------------*/
/*                          Pre-Autonomous Functions                         */
/*                                                                           */
/*  You may want to perform some actions before the competition starts.      */
/*  Do them in the following function.  You must return from this function   */
/*  or the autonomous and usercontrol tasks will not be started.  This       */
/*  function is only called once after the V5 has been powered on and        */
/*  not every time that the robot is disabled.                               */
/*---------------------------------------------------------------------------*/

void pre_auton(void) {
  vexcodeInit(); // Initializing Robot Configuration. DO NOT REMOVE! dcc
  GUI gui;
  lTracking.setPosition(0, deg);
  IMU.calibrate();
  while(IMU.isCalibrating()){wait(10, msec);}  //Controller1.Screen.print("ready");
  //IMU.setRotation(0, rotationUnits::deg); aa
  

  gui.drawMainGUI();
  //test when time allowsss
}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              Autonomous Task                              */
/*                                                                           */
/*  This task is used to control your robot during the autonomous phase of   */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/


void autonomous(void) { //ADD IMAGES TO SD CARD SO WE CAN GET PICS ON THE BRAIN ss
  //USE COMP SWITCH TO TEST AUTON
  //Brain.Screen.released(selectAuton); shouldnt have to uncomment but just in case
  GUI auton_run;
  //flywheel.spin(fwd, 12, voltageUnits::volt);

  if (Competition.isCompetitionSwitch()) {
    auto_num = 1; //this overrides current gui selector! REMOVE DURING COMP. 3 = ss
  }

  if (auto_num == 1 || auto_num == 2) {
   //INITALIZE FLYWHEEL TBH
   auton_flywheel.store(true);
   flywheel_velocity.store(14600); //14350 PLZ tune/tinker 14500m  14700 e 14200 ssss
   thread thread1(flywheel_pid);
   //thread odom(odom_start);
   //DETACH FLYWHEEL TBH TO ITS OWN THREAD
   thread1.detach();
  }

  wait(2, sec);
  intake.spin(fwd, -12, voltageUnits::volt);

  

  //auton_run.runAUTO();

  // if (auto_num == 1 || auto_num == 2) { thread::interruptAll(); } //STOPS ALL RUNNING THREADS

  // ..........................................................................
  // Insert autonomous user code here.
  // ..........................................................................
}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              User Control Task                            */
/*                                                                           */
/*  This task is used to control your robot during the user control phase of */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/

void usercontrol(void) {
  
  auton_flywheel.store(true);
  //flywheel_velocity.store(13600); //14350 PLZ tune/tinker 14500m  14700 e 14200 yyyddbhddss
  vex::thread thread3(flywheel_pid);
  //DETACH FLYWHEEL TBH TO ITS OWN THREAD
  thread3.detach();
  
  
  dianostics info;
   
  // User control code here, inside the loop dd

  while (true) {

    // If L1 is held down secondary control map
    if (Controller1.ButtonL1.pressing()) {
      
      SecondaryControlMap(); // ENDGAME RELEASE
      PrimaryControlMap();
    } else {
      PrimaryControlMap(); // everything else vbn
      info.temps();

     
      if (Competition.isCompetitionSwitch()) {
       info.temps(); //tells temps of motors
       //info.flywheel_info(); // prints on controller the flywheel speed and angle of the bot rr
      }

    }
   wait(15, msec); // Sleep the task for a short amount of time to prevent wasted resources. hjbnmeeeeghddhjghnddmkdd
  }
}

//
// Main will set up the competition functions and callbacks.
//
int main() {
  // Set up callbacks for autonomous and driver control periods.
  Competition.autonomous(autonomous);
  Competition.drivercontrol(usercontrol);
  Brain.Screen.released(selectAuton);
  // Run the pre-autonomous function.
  pre_auton();

  // Prevent main from exiting with an infinite loop.
  while (true) {
   Brain.Screen.released(selectAuton);
   wait(15, msec);
  }
}
