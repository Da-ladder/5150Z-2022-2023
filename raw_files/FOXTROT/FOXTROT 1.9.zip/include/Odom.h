#pragma once


class auto_chassis {
  private:
   static double curen_x;
   static double curen_y;

  public:
   void odom();
   void trig_cal(double tar_x, double tar_y, bool backside, double speed);
};