// CONTROLLER CODE
#include "Objects.h"
#include "Chassis.h"
#include "vex.h"
 
using namespace vex;
 
// DEFINES A AREA WHERE CONTROLLER WILL NOT ACCEPT INPUT
int deadzone = 10;
double time_shot = 0;
bool transfer = true;
bool pressed_det = true;
bool prev_pres = false;
bool preva_pres = false;
bool intake_toggle_mag = false;
bool preva_pres_mag = false;
bool decrease_sped_prev_pres = false;
bool boop_change = true;
bool in_pressed_det = true;
bool decrease_sped_det = true;
bool in_prev_pres = false;
bool sped_prev_pres = false;
bool boop_prev_pres = false;
double driver_sped = 12800;
bool three_disk = false;
double count_disk = 0;
bool speed_change = false;
bool blocking = false;
bool transfer_angle = true;
double prev_driver_sped = 0;
bool transfer_sped = false;
bool transmission_speed = false;
double read_sped = 0;

// FUNCTION THAT ALLOWS FOR CONTROL OF FLYWHEEL

void SecondaryControlMap() {
  if (Controller1.ButtonY.pressing()){
    t_junction.set(true); // switches the t_junction to supply air to the endgame
  } else {
    //t_junction.set(false);
  }
}


// FUNCTION THAT ALLOWS FOR A ARCADE STYLE OF DRIVE
void PrimaryControlMap() {
  
  //current_cord[0].store(4); //THIS IS HOW YOU STORE VALUES IN ATOMIC ARRAYS
  
  int leftJoystickVal = 0, rightJoystickVal = 0;
 
  // ALLOWS FOR CONTROLS TO BE TUNED TO DRIVER'S PREFRENCE
  double sensitivity = 1;
  //double slowdown = 0.5;
  //double kp = 1.003;
  double turn = 0, power = 0;
  double lOutput = 0, rOutput = 0;
 
  // CREATES AN OBJECT
  chassis_Set controls;
 
  rightJoystickVal = Controller1.Axis3.value();
  leftJoystickVal = Controller1.Axis1.value();


  if (Controller1.ButtonL1.pressing() && !prev_pres) { pressed_det = !pressed_det; prev_pres = true; transfer_sped = true;} 
  else if (!Controller1.ButtonL1.pressing() && prev_pres) { prev_pres = false; }

  if (pressed_det && transfer_sped) { transfer_sped = false; driver_sped = prev_driver_sped; transfer = true; //16000
  } else if (!pressed_det && transfer_sped) { transfer_sped = false; flywheel_velocity.store(0); prev_driver_sped = driver_sped; driver_sped = 0;
  }

  if (transfer) { transfer = false; if ( flywheel_velocity.load() != driver_sped ) { flywheel_velocity.store(driver_sped); }}
  
  
  if (Controller1.ButtonA.pressing() && !in_prev_pres) { in_pressed_det = !in_pressed_det; in_prev_pres = true; transfer = true; driver_sped = driver_sped - 100; 
  Controller1.Screen.clearScreen();
  Controller1.Screen.setCursor(1, 1);
  Controller1.Screen.print(driver_sped);
  } 
  else if (!Controller1.ButtonA.pressing() && in_prev_pres) { in_prev_pres = false; }
  
  if (Controller1.ButtonY.pressing() && !decrease_sped_prev_pres) { decrease_sped_det = !decrease_sped_det; decrease_sped_prev_pres = true; transfer = true; driver_sped = driver_sped + 100;
  Controller1.Screen.clearScreen();
  Controller1.Screen.setCursor(1, 1);
  Controller1.Screen.print(driver_sped);
  } 
  else if (!Controller1.ButtonY.pressing() && decrease_sped_prev_pres) { decrease_sped_prev_pres = false; }

  /*
  if (in_pressed_det) {
   transmission_speed = false;
   driver_sped = 15750; //12k booper bad?? need to test //14500
  } else if (!in_pressed_det) {
   transmission_speed = false;
   driver_sped = 14000; //14875
  }
  */
  if (Controller1.ButtonLeft.pressing()) { color_sense.setLightPower(100, percent); 
  color_sense.setLight(ledState::on); }


  if (Controller1.ButtonB.pressing() && !sped_prev_pres) { speed_change = !speed_change; sped_prev_pres = true; } 
  else if (!Controller1.ButtonB.pressing() && sped_prev_pres) { sped_prev_pres = false; }

  if (Controller1.ButtonL2.pressing() && !boop_prev_pres) { boop_change = !boop_change; boop_prev_pres = true; transfer = true; transfer_angle = true; speed_change = false;}
  else if (!Controller1.ButtonL2.pressing() && boop_prev_pres) { boop_prev_pres = false; }

  if (!boop_change && transfer_angle) { mag_lift.set(false); feeder.set(true); transfer_angle = false; driver_sped = 12800; } //14k //DRIVER 13200 14300???
  else if (boop_change && transfer_angle) { mag_lift.set(true); feeder.set(false); transfer_angle = false; driver_sped = 12200; } //13200 // DRIVER 14050


  if (Controller1.ButtonR1.pressing()){ intake.spin(fwd, -12, voltageUnits::volt); }
  else if (Controller1.ButtonR2.pressing()) { if (!speed_change) {intake.spin(fwd, 12, voltageUnits::volt);} else if (speed_change) {intake.spin(fwd, 10.5, voltageUnits::volt);} }
  else { intake.spin(fwd, 0, voltageUnits::volt); }

  if (Controller1.ButtonLeft.pressing() && !preva_pres) { intake_toggle = !intake_toggle; preva_pres = true;
  } else if (!Controller1.ButtonLeft.pressing() && preva_pres) { preva_pres = false; }

  if (intake_toggle) { band_tension.set(true); } else if (!intake_toggle) { band_tension.set(false); }
 
  //if (rightJoystickVal <= 100) { turn = (rightJoystickVal * sensitivity) / 10.58; }//Sets power  
  turn = (leftJoystickVal * sensitivity) / 10.58;
  power = (rightJoystickVal * sensitivity) / 10.58;
 
  lOutput = -turn + power;
  rOutput = turn + power;
 
  // APPLIES POWER TO THE MOTOR FROM OBJECT
  controls.move(rOutput, lOutput);

 
  // CHECKS IF THE CONTROLS ARE MOVING IF NOT
  // SET MOTORS TO BRAKE
  if (Controller1.Axis3.value() < deadzone ||
      Controller1.Axis4.value() < deadzone ||
      Controller1.Axis2.value() < deadzone) {
    controls.brake();
   }
 }
