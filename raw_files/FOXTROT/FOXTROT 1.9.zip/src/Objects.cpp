#include "Objects.h"

void chassis_Set::reset() {
   leftMotorA.resetRotation();
   leftMotorB.resetRotation();
   rightMotorA.resetRotation();
   rightMotorB.resetRotation();
 }

// CREATES A METHOD TO APPLY POWER TO CHASSIS
void chassis_Set::move(double rPower, double lPower) {
  leftMotorA.spin(fwd, lPower, voltageUnits::volt);
  rightMotorA.spin(fwd, rPower, voltageUnits::volt);
  rightMotorB.spin(fwd, rPower, voltageUnits::volt);
  leftMotorB.spin(fwd, lPower, voltageUnits::volt);
  leftMotorC.spin(fwd, lPower, voltageUnits::volt);
  rightMotorC.spin(fwd, rPower, voltageUnits::volt);
}

// CREATES A METHOD TO BRAKE THE CHASSIS MOTORS
void chassis_Set::brake() {
  leftMotorA.setBrake(hold);
  rightMotorA.setBrake(hold);
  rightMotorB.setBrake(hold);
  leftMotorB.setBrake(hold);
  leftMotorC.setBrake(hold);
  rightMotorC.setBrake(hold);
}

// CREATES A METHOD TO BOTH APPLY ZERO VOLTAGE AND BRAKE MOTORS
void chassis_Set::rest() {
  move(0, 0);
  brake();
}