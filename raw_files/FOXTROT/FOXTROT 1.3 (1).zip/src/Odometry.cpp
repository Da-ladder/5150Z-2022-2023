// CONTROLLER CODE
#include "objects.cpp"
#include "vex.h"

using namespace vex;

double currentY = 0; //Robot's current yPos. Will be calculated every 20ms in a loop.
double currentX = 0; //Robot's current xPos. Will be calculated every 20ms in a loop.
double currentHdg = 0; //Robot's current heading. Will be calculated every 20ms in a loop.

//Odometry function. Place in parameters: double xPos, double yPos, double hdg
void Odometry () { //Input parameters are where we want the robot to be.
  //Zeroing.
  rTracking.resetPosition();
  lTracking.resetPosition();
  bTracking.resetPosition();
  IMU.calibrate();
  IMU.resetHeading();
  //Declarations
  double localY;
  double localX;
  double avgHdg;
  //double chgHdg;
  double prevHdg;

  double leftVal; //Left encoder's current value.
  double rightVal; //Right encoder's current value.
  double backVal; //Back encoder's current value.
 
  double wheelDiamL = 2.75; //Odometry wheel diameter. In inches. 2.752
  double wheelDiamR = 2.75; //Flex wheel odom wheel?
  double wheelDiamB = 2.75;
  
  double disTrackL = 2.75; //Distance of left odom wheel from tracking center. In inches.
  double disTrackR = 2.75; //Distance of Right odom wheel from tracking center. In inches.
  double disTrackBack = 5.5; //Distance of back odom wheel from tracking center. In inches.

  double moveLeft; //Distance left odom wheel moves in inches. Calculated using odom wheel diameter.
  double moveRight;
  double moveBack; 

  double arcRadY; //Radius of arc made by left/right odom wheels. In inches.
  double arcRadX; //Radius of arc made by back odom wheel. In inches.
  
  //Calculations.
  while (1) { //Controller1.ButtonL2.pressing()
    rightVal = rTracking.position(degrees);
    leftVal = lTracking.position(degrees);
    backVal = bTracking.position(degrees);

    moveRight = (wheelDiamR/2) * (rightVal * (M_PI/180));
    moveLeft = -1 * (wheelDiamL/2) * (leftVal * (M_PI/180));
    moveBack = (wheelDiamB/2) * (backVal * (M_PI/180));

    prevHdg = currentHdg;
    currentHdg = IMU.rotation(rotationUnits::deg);
    //currentHdg = IMU.orientation(yaw, degrees) * (M_PI/180); //* (M_PI/180); 
    //Function TBD. Also, remember to calibrate/zero heading.
    
    //currentHdg = (moveLeft - moveRight)/(disTrackL + disTrackR); //Calculates current/new heading of robot.
    //chgHdg = currentHdg - prevHdg;
    
    /*if (currentHdg * (180/M_PI) >= -1.5 && currentHdg * (180/M_PI) <= 1.5) {
      currentY = moveRight;
      currentX = moveBack;
    } */
    //else {
      //arcRadY = (moveRight/currentHdg) + disTrackR;
      //arcRadX = (moveBack/currentHdg) + disTrackBack;
      
      //avgHdg = prevHdg + (currentHdg/2);

      currentY = 2 * ((moveRight/currentHdg) + disTrackR) * (sin(currentHdg/2)); //4.75
      currentX = -2 * ((moveBack/currentHdg) + disTrackBack) * (sin(currentHdg/2)); //2
      
      //currentY = (sqrt(pow(localX, 2) + pow(localY, 2))) * (sin(atan((localY/localX) + (-avgHdg))));
      //currentX = (sqrt(pow(localX, 2) + pow(localY, 2))) * (cos(atan((localY/localX) + (-avgHdg))));
    //}

    //Makes changes to robot's position. CODE TO BE ADDED.
    //Declares relevant variables.
      
      //double vector;
      //vector = currentHdg + (90 - (tan(yPos/xPos))); //Vector from robot's current pos to destination.

    //Prints calculated robot position.

    Brain.Screen.setCursor(2, 1);
    Brain.Screen.print("X pos: ");
    Brain.Screen.print(currentX);
    Brain.Screen.setCursor(2, 25);
    Brain.Screen.print("Perp Wh: ");
    Brain.Screen.print(backVal);
    
    Brain.Screen.setCursor(3, 1);
    Brain.Screen.print("Y pos: ");
    Brain.Screen.print(currentY);
    
    Brain.Screen.setCursor(4, 1);
    Brain.Screen.print("Hdg(deg): ");
    Brain.Screen.print(currentHdg*(180/M_PI));

    Brain.Screen.setCursor(5, 1);
    Brain.Screen.print("IMU: ");
    Brain.Screen.print(IMU.orientation(yaw, degrees));
    /*
    Brain.Screen.setCursor(2, 1);
    Brain.Screen.print("Move(in): ");
    Brain.Screen.print(moveRight);
    
    Brain.Screen.setCursor(4, 1);
    Brain.Screen.print("IMU: ");
    Brain.Screen.print(IMU.orientation(yaw, degrees));
    
    Controller1.Screen.setCursor(1, 1);
    Controller1.Screen.print(IMU.orientation(yaw, degrees));
    */
    wait(5, msec);
  }
}

void move(double moveDis) {
  chassis_Set pursuit;
  while (currentY < (moveDis - 2)) {
    if (currentY < (moveDis - 2)) {
      pursuit.move(3, 3);
    } 
    else if (currentY < (moveDis)) {
      pursuit.move(1, 1);
    }
    else if (currentY > (moveDis + 0.1)) {
      pursuit.move(-1, -1);
    } 
    else {
      pursuit.move(0, 0);
    }
    wait(5, msec);
  }
}

void turn(double deg) {
  chassis_Set pursuitT;
  //while (currentHdg * (180/M_PI) < deg) {
    if (0 < deg) {
      pursuitT.move(2.25, -2.5);
    } 
    else if (0 > deg + 5) {
      //pursuit.brake();
      pursuitT.move(-2, 2);
    } 
    else {
      pursuitT.move(0, 0);
    } 
    //wait(3, msec);
  //}
}

  void purePursuit (double x, double y) {
    double vector;
    //double disTravel;
    while (1) {
      Odometry();
      vector = (currentHdg * (180/M_PI)) - (atan(y/x) * (180/M_PI));
      //disTravel = sqrt((pow((x - currentX), 2)) + (pow((y - currentY), 2)));
      Brain.Screen.clearScreen();
      Brain.Screen.setCursor(1, 1);
      Brain.Screen.print(vector);
      Brain.Screen.setCursor(2, 1);
      //Brain.Screen.print(disTravel);
      Brain.Screen.setCursor(3, 1);
      Brain.Screen.print(x);
      Brain.Screen.setCursor(4, 1);
      Brain.Screen.print(y);
      turn(vector);
      wait(3, msec);
    }
  }

void drawGUI () {
  int bH = 50;
  int bW = 100;
  //*******************************************************
  //Button 1
  int b1Y = 10;
  int b1X = 10;

  int b1EndY = b1Y + bH;
  int b1EndX = b1X + bW;

  Brain.Screen.drawRectangle(b1X, b1Y, bW, bH);
  Brain.Screen.printAt(60, 35, "Left-Side Shoot");
  //*******************************************************
  //Button 2
  int b2Y = 10;
  int b2X = 120;

  int b2EndY = b2Y + bH;
  int b2EndX = b2X + bW;

  Brain.Screen.drawRectangle(b2X, b2Y, bW, bH);
  Brain.Screen.printAt(170, 35, "Right-Side Shoot");
  //*******************************************************
  //Button 3
  int b3Y = 70;
  int b3X = 10;

  int b3EndY = b3Y + bH;
  int b3EndX = b3X + bW;

  Brain.Screen.drawRectangle(b3X, b3Y, bW, bH);
  Brain.Screen.printAt(60, 95, "Left-Side Roll");
  //*******************************************************
  //Button 4
  int b4Y = 70;
  int b4X = 120;

  int b4EndY = b4Y + bH;
  int b4EndX = b4X + bW;

  Brain.Screen.drawRectangle(b4X, b4Y, bW, bH);
  Brain.Screen.printAt(170, 95, "Right-Side Roll");
} 
void selectAuton () {
  bool selectingAuton = true;

  int x = Brain.Screen.xPosition();
  int y = Brain.Screen.yPosition();

  if ((x >= 10 && x <= 110)&&(y >= 10 && y <= 60)) {
    Brain.Screen.clearScreen();
    Brain.Screen.printAt(1, 1, "Left-Side Shoot");
  }
  else{}
} 