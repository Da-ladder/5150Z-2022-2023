#include "vex.h"
#include <iostream>
 
using namespace vex;
using namespace std;


struct chassis_Set {
 
 void reset() {
   leftMotorA.resetRotation();
   leftMotorB.resetRotation();
   leftMotorC.resetRotation();
   rightMotorA.resetRotation();
   rightMotorB.resetRotation();
   rightMotorC.resetRotation();
 }
 
 // CREATES A METHOD TO APPLY POWER TO CHASSIS
 void move(double rPower, double lPower) {
   leftMotorA.spin(fwd, -lPower, voltageUnits::volt);
   leftMotorB.spin(fwd, lPower, voltageUnits::volt);
   leftMotorC.spin(fwd, -lPower, voltageUnits::volt);
   rightMotorA.spin(fwd, -rPower, voltageUnits::volt);
   rightMotorB.spin(fwd, rPower, voltageUnits::volt);
   rightMotorC.spin(fwd, -rPower, voltageUnits::volt);
 }
 void launch(double speed) {
   flywheel.spin(fwd, speed, voltageUnits::volt);
   flywheel2.spin(fwd, speed, voltageUnits::volt);
 }
 void stop_launch(){
   flywheel.setBrake(hold);
   flywheel2.setBrake(hold);
 }
 void hopper(){
   hopper_feed.set(true);
 }
 
 // CREATES A METHOD TO BRAKE THE CHASSIS MOTORS
 void brake() {
   leftMotorA.setBrake(hold);
   leftMotorB.setBrake(hold);
   leftMotorC.setBrake(hold);
   rightMotorA.setBrake(hold);
   rightMotorB.setBrake(hold);
   rightMotorC.setBrake(hold);
 }
 
 // CREATES A METHOD TO BOTH APPLY ZERO VOLTAGE AND BRAKE MOTORS
 void rest() {
   move(0, 0);
   brake();
 }
};