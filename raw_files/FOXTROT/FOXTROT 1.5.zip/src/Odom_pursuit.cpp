#include "vex.h"
#include "Pid.cpp"
#include <math.h>
#include <cmath>
#include <atomic>
#include <iostream> 

using namespace vex;

//LOCAL VARIABLE DECLARATIONS WITH ATOMIC


class auto_chassis {
  private:
   std::atomic<double> current_x_y[2];
  public:
   void odom () {
     double X = 0; //X offset
     double Y = 0; //Y offset
     double tpr = 360;  //Degrees per single encoder rotation
     double SL = 2.405; //distance from tracking center to middle of left wheel 3.125 //2 = 100
     double SR = 2.405; //distance from tracking center to middle of right wheel 
     double Theta = 0;
     double currentR, currentL, currentB, DeltaL, DeltaR, DeltaB, DeltaTheta, SideChord, DeltaYSide, DeltaXSide, Inertial, OdomHeading, PreviousL, PreviousR, PreviousB;
     while (odom_enabled) {
       currentR = rtracking.position(degrees);
       currentL = lTracking.position(degrees);
       
       DeltaL = ((currentL - PreviousL) * 8.63938) / tpr;
       DeltaR = ((currentR - PreviousR) * 8.63938) / tpr;

       DeltaTheta = (DeltaR - DeltaL) / (SL + SR); //ANGLE IS IN RADS

        if(DeltaTheta == 0) {  //If there is no change in angle
         X += DeltaL * sin (Theta);
         Y += DeltaL * cos (Theta);
        //If there is a change in angle, it will calculate the changes in X,Y from chords of an arc/circle.
        } else {  //If the angle changes
         SideChord = 2 * ((DeltaL / DeltaTheta) + SL) * sin (DeltaTheta / 2);
         //BackChord = 2 * ((DeltaB / DeltaTheta) + SS) * sin (DeltaTheta / 2);
         DeltaYSide = SideChord * cos (Theta + (DeltaTheta / 2));
         DeltaXSide = SideChord * sin (Theta + (DeltaTheta / 2));
         //DeltaXBack = BackChord * sin (Theta + (DeltaTheta / 2));
         //DeltaYBack = -BackChord * cos (Theta + (DeltaTheta / 2));
         Theta += DeltaTheta;
         X += DeltaXSide;
         Y += DeltaYSide;
         Inertial = IMU.rotation(deg);
        }
       //Odom heading is converting the radian value of Theta into degrees
       OdomHeading = Theta * 57.295779513;

       //Converts values into newer values to allow for code to effectively work in next cycle
       PreviousL = currentL;
       PreviousR = currentR;
       //PreviousB = currentB;

       current_x_y[1].store(X);
       current_x_y[2].store(Y);
       glob_Theta.store(Theta);
       

       DeltaTheta = 0;
       wait(7, msec);
     }
   }

   void trig_cal (double tar_x, double tar_y) { // IN MAKE IT WORK STAGE --> MAKE IT RIGHT --> MAKE IT FAST
     IMU_PID travel;

     double cur_x = current_x_y[1].load();
     double cur_y = current_x_y[2].load();
     double turn_angle = 0;
     double travel_dis = 0;
     double trig_angle = 0;
     double trig_angle_deg = 0;

     double dis_x = tar_x - cur_x;
     double dis_y = tar_y - cur_y;

     if (dis_x == 0) {
       if (dis_y < 0) { turn_angle = -90; } else { turn_angle = 90; }
       travel_dis = abs(dis_y);
     }
     else {
       trig_angle = atan(dis_y / dis_x);
       travel_dis = sqrt(pow(dis_y, 2) + pow(dis_x, 2));
       trig_angle_deg = trig_angle * 57.295779513;

       if (dis_y > 0 && dis_x > 0) {
         turn_angle = trig_angle_deg;
       } else if (dis_y > 0 && dis_x < 0) {
         turn_angle = 180 + trig_angle_deg;
       } else if (dis_y < 0 && dis_x < 0) {
         turn_angle = -180 + trig_angle_deg;
       } else if (dis_y < 0 && dis_x > 0) {
         turn_angle = trig_angle_deg;
       } else { turn_angle = trig_angle_deg; }
      // EXCUTES THE RESULTS DIRECTLY
      travel.rep_turn(turn_angle, 3, 0.05, true);
      travel.test(travel_dis, 12);
     }
   }

  

};