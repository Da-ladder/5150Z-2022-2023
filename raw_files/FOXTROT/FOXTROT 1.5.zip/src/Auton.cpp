#include "vex.h"
#include "Odom_pursuit.cpp"
#include "flywheel_tbh.cpp"

using namespace vex;


struct auto_routes {
  chassis_Set movement;
  IMU_PID auton;

  void leftEasySideSixShot() { //should probs document this tbh
   //roll roller and turn toward disks
   movement.move(-3, -3);
   wait(0.2, sec);
   intake.spin(fwd, 12, voltageUnits::volt);
   wait(0.15, sec);
   intake.spin(fwd, 0, voltageUnits::volt);
   movement.move(5, 5);
   wait(0.2, sec);
   movement.move(0, 0);
   /*
   auton.turn(45, true, false, 2);
   wait(0.05, sec);
   auton.turn(44.25, true, false, 1);

   //knock over disks
   auton.test(15, 10);
   movement.move(12, 12);
   wait(0.28, sec);
   movement.move(0, 0);
   wait(0.05, sec);

   //INTAKE disks
   intake.spin(fwd, -12, voltageUnits::volt);
   movement.move(2, 2);
   wait(3, sec);
   movement.move(0, 0);
   auton.turn(-35.5, true, false, 2);
   intake.spin(fwd, 0, voltageUnits::volt);
   wait(0.05, sec);
   auton.turn(-35.5, true, false, 0.5);

   auton.rep_shot(3, 0, 2);
   */
   
  }


  void skills_route() {
    //skills auton = get 4 rollers, targeting 9 - 12 shots depending on time left
   movement.move(-3, -3);
   wait(0.2, sec);
   intake.spin(fwd, 12, voltageUnits::volt);
   wait(0.3, sec);
   intake.spin(fwd, 0, voltageUnits::volt);
   movement.move(5, 5);
   wait(0.95, sec);
   movement.move(0, 0);
   auton.turn(90, true, false, 2);
   wait(0.05, sec);
   auton.turn(90, true, false, 0.5);
   auton.test(-21, 12);

   movement.move(-3, -3);
   wait(0.4, sec);
   intake.spin(fwd, 12, voltageUnits::volt);
   wait(0.33, sec);
   intake.spin(fwd, 0, voltageUnits::volt);
   movement.move(5, 5);
   wait(0.5, sec);
   movement.move(0, 0);


   auton.test(24, 12);
   auton.turn(-138, true, false, 2);
   wait(0.05, sec);
   auton.turn(-138, true, false, 0.5);
   //auton.test(24, 12);
   
   auton.test(-114, 12);
   auton.turn(-90, true, false, 2);
   wait(0.05, sec);
   auton.turn(-90, true, false, 1);
   
   movement.move(-6, -6);
   wait(0.5, sec);
   intake.spin(fwd, 12, voltageUnits::volt);
   wait(0.33, sec);
   intake.spin(fwd, 0, voltageUnits::volt);
   movement.move(5, 5);
   wait(0.5, sec);
   movement.move(0, 0);

   auton.test(7, 12);
   auton.turn(-180, true, false, 2);
   wait(0.05, sec);
   auton.turn(-180, true, false, 1);
   auton.test(-13, 12);


   movement.move(-5, -5);
   wait(0.5, sec);
   intake.spin(fwd, 12, voltageUnits::volt);
   wait(0.33, sec);
   intake.spin(fwd, 0, voltageUnits::volt);
   movement.move(5, 5);
   wait(0.5, sec);
   movement.move(0, 0);

   auton.turn(-132, true, false, 2);
   wait(0.05, sec);
   auton.turn(-132, true, false, 1);
   //ENDGAME

   t_junction.set(true);


  }


  void rightHardSideRoller() { //do a quick auton roller for the right side
   auton.test(-20, 12);
   auton.turn(90, true, false, 2);
   movement.move(-4, -4);
   wait(0.6, sec);
   intake.spin(fwd, 12, voltageUnits::volt);
   wait(0.2, sec);
   intake.spin(fwd, 0, voltageUnits::volt);
   movement.move(5, 5);
   wait(0.2, sec);
   movement.move(0, 0);

  }


  void backUpDischarge() { //back up discharge is test code as of now
  auton.rep_shot(1, 1, 1);
   
  }


};



struct dianostics {
  void temps() {
    Brain.Screen.clearScreen();
    Controller1.Screen.clearScreen();
    Controller1.Screen.setCursor(1, 1);
    Controller1.Screen.print(IMU.orientation(yaw, degrees));
    
    Brain.Screen.setCursor(1,1);
    Brain.Screen.print(IMU.orientation(yaw, degrees));
    Brain.Screen.setCursor(2,1);
    Brain.Screen.print("left motor A TEMP: ");
    Brain.Screen.print(leftMotorA.temperature(temperatureUnits::celsius));
    Brain.Screen.setCursor(3,1);
    Brain.Screen.print("left motor B TEMP: ");
    Brain.Screen.print(leftMotorB.temperature(temperatureUnits::celsius));
    Brain.Screen.setCursor(4,1);
    Brain.Screen.print("right motor A TEMP: ");
    Brain.Screen.print(rightMotorA.temperature(temperatureUnits::celsius));
    Brain.Screen.setCursor(6,1);
    Brain.Screen.print("right motor B TEMP: ");
    Brain.Screen.print(rightMotorB.temperature(temperatureUnits::celsius));
    Brain.Screen.setCursor(5,1);
    Brain.Screen.print("Flywheel TEMP: ");
    Brain.Screen.print(flywheel.temperature(temperatureUnits::celsius));
    Brain.Screen.setCursor(6,1);
    Brain.Screen.print("Intake TEMP: ");
    Brain.Screen.print(intake.temperature(temperatureUnits::celsius));
    Brain.Screen.render();
  }

  void power_speed() {
    Brain.Screen.clearScreen();
    Brain.Screen.setCursor(1,1);
    Brain.Screen.print("left motor A Voltage (watts): ");
    Brain.Screen.print(leftMotorA.voltage());
    Brain.Screen.setCursor(2,1);
    Brain.Screen.print("left motor B Voltage (watts): ");
    Brain.Screen.print(leftMotorB.voltage());
    Brain.Screen.setCursor(3,1);
    Brain.Screen.print("right motor A Voltage (watts): ");
    Brain.Screen.print(rightMotorA.voltage());
    Brain.Screen.setCursor(4,1);
    Brain.Screen.print("right motor B Voltage (watts): ");
    Brain.Screen.print(rightMotorB.voltage());
    Brain.Screen.setCursor(5,1);
    Brain.Screen.print("left motor A SPEED (RPM 600 CAP): ");
    Brain.Screen.print(leftMotorA.velocity(velocityUnits::rpm));
    Brain.Screen.setCursor(6,1);
    Brain.Screen.print("left motor B SPEED (RPM 600 CAP): ");
    Brain.Screen.print(leftMotorB.velocity(velocityUnits::rpm));
    Brain.Screen.setCursor(7,1);
    Brain.Screen.print("right motor A SPEED (RPM 600 CAP): ");
    Brain.Screen.print(rightMotorA.velocity(velocityUnits::rpm));
    Brain.Screen.setCursor(8,1);
    Brain.Screen.print("right motor B SPEED (RPM 600 CAP): ");
    Brain.Screen.print(rightMotorB.velocity(velocityUnits::rpm));
    Brain.Screen.render();
  }

  void flywheel_info() {
    Controller1.Screen.clearScreen();
    Controller1.Screen.setCursor(2, 1);
    Controller1.Screen.print(IMU.orientation(yaw, degrees));
  }

};