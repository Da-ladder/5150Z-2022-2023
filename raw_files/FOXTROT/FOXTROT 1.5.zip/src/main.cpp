/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       VEX                                                       */
/*    Created:      Thu Sep 26 2019                                           */
/*    Description:  Competition Template                                      */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// ---- END VEXCODE CONFIGURED DEVICES ----


#include "GUI.cpp"

#include "vex.h"
#include "Vision_cal.h"

#include <thread>
#include <atomic>


using namespace vex;

competition Comp;

/*
class subness : public rotation { fddsssdd
  public:d
   void change_data() {
     datarate(10);
   }
};
*/

void flywheel_pid() {
  flywheel_ctrl fly;
  auton_flywheel.store(true);
  fly.flywheel_tbh();
  std::terminate();
}


void selectAuton() {
  GUI auton_pick;
  auton_pick.selectAuton();
}


void odom_start() {
  auto_chassis full_auto;
  odom_enabled.store(true);
  full_auto.odom();
  std::terminate();
}

/*---------------------------------------------------------------------------*/
/*                          Pre-Autonomous Functions                         */
/*                                                                           */
/*  You may want to perform some actions before the competition starts.      */
/*  Do them in the following function.  You must return from this function   */
/*  or the autonomous and usercontrol tasks will not be started.  This       */
/*  function is only called once after the V5 has been powered on and        */
/*  not every time that the robot is disabled.                               */
/*---------------------------------------------------------------------------*/

void pre_auton(void) {
  vexcodeInit(); // Initializing Robot Configuration. DO NOT REMOVE! ss
  GUI gui;
  lTracking.setPosition(0, deg);
  rtracking.setPosition(0, deg);
  IMU.calibrate();
  while(IMU.isCalibrating()){wait(10, msec);}  Controller1.Screen.print("ready");
  //IMU.setRotation(0, rotationUnits::deg); ggeedd
  

  gui.drawMainGUI();
  //test when time allowsses
}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              Autonomous Task                              */
/*                                                                           */
/*  This task is used to control your robot during the autonomous phase of   */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/


void autonomous(void) { //ADD IMAGES TO SD CARD SO WE CAN GET PICS ON THE BRAIN ss
  //USE COMP SWITCH TO TEST AUTON
  //Brain.Screen.released(selectAuton);
  GUI auton_run;

  //if (Comp.isCompetitionSwitch()) {
    auto_num = 4; //this overrides current gui selector! REMOVE DURING COMP. 3 = fghddtt
  //}

  if (auto_num == 1 || auto_num == 4) {
   //INITALIZE FLYWHEEL TBH
   auton_flywheel.store(true);
   flywheel_velocity.store(25300); //14350 PLZ tune/tinker 14500m  14700 e 14200 ffdghdghjs
   thread fly_ctrl(flywheel_pid);
   fly_ctrl.detach();
   wait(4, sec);
   auton_run.runAUTO();
   //fly_ctrl.interrupt();
   //thread odom(odom_start);
   //odom.detach();
  } else { auton_run.runAUTO(); }

  //wait(2, sec);
  //intake.spin(fwd, -12, voltageUnits::volt);

  

  

  // if (auto_num == 1 || auto_num == 2) { thread::interruptAll(); } //STOPS ALL RUNNING THREADS

  // ..........................................................................
  // Insert autonomous user code here.
  // ..........................................................................
}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              User Control Task                            */
/*                                                                           */
/*  This task is used to control your robot during the user control phase of */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/

void usercontrol(void) {
  
  auton_flywheel.store(true);
  //flywheel_velocity.store(13600); //14350 PLZ tune/tinker 14500m  14700 e 14200 thjfgh
  vex::thread thread3(flywheel_pid);
  //DETACH FLYWHEEL TBH TO ITS OWN THREAD
  thread3.detach(); //TWO threads are running at once here
  
  
  dianostics info;
   
  // User control code here, inside the loop dd

  while (true) {

    // If L1 is held down secondary control map
    if (Controller1.ButtonL1.pressing()) {
      //lTracking.setPosition(0, deg);
      //rtracking.setPosition(0, deg);
      
      SecondaryControlMap(); // ENDGAME RELEASE
      PrimaryControlMap();
    } else {
      PrimaryControlMap(); // everything else gh
      info.temps();

      /*
      Controller1.Screen.setCursor(1, 1);
      Controller1.Screen.print(lTracking.position(rotationUnits::deg));
      Controller1.Screen.setCursor(2, 1);
      Controller1.Screen.print(rtracking.position(rotationUnits::deg));
      wait(0.5, sec);
      Controller1.Screen.clearScreen();
      */
      
      


     
      if (Comp.isCompetitionSwitch()) {
       info.temps(); //tells temps of motors
       info.flywheel_info(); // prints on controller the flywheel speed and angle of the bot rr
      }

    }
   wait(15, msec); // Sleep the task for a short amount of time to prevent wasted resources. sddssssddeess
  }
}

//
// Main will set up the competition functions and callbacks.
//
int main() {
  // Set up callbacks for autonomous and driver control periods.
  Comp.autonomous(autonomous);
  Comp.drivercontrol(usercontrol);
  Brain.Screen.released(selectAuton);
  // Run the pre-autonomous function.
  pre_auton();

  // Prevent main from exiting with an infinite loop.
  while (true) {
   Brain.Screen.released(selectAuton);
   wait(15, msec);
  }
}
