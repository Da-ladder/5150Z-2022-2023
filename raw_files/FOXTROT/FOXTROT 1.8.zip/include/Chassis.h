#pragma once
// CONTROLLER CODE
#include "Objects.h"
#include "vex.h"

using namespace vex;
 
// DEFINES A AREA WHERE CONTROLLER WILL NOT ACCEPT INPUT
extern int deadzone;
extern double time_shot;
extern bool pressed_det;
extern bool prev_pres;
extern bool preva_pres;
extern bool intake_toggle_mag;
extern bool preva_pres_mag;
extern bool in_pressed_det;
extern bool in_prev_pres;
extern double driver_sped;

// FUNCTION THAT ALLOWS FOR CONTROL OF FLYWHEEL

void SecondaryControlMap();

// FUNCTION THAT ALLOWS FOR A ARCADE STYLE OF DRIVE
void PrimaryControlMap();