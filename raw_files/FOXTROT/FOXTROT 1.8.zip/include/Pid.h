#pragma once
#include "vex.h"
#include "Objects.h"
#include <math.h>
#include <cmath>
 
using namespace vex;

struct IMU_PID {  
  void roller_spin();
  void rep_shot(double disks, double start_delay, double delay);
  void rep_shot2(double shot1, double shot2, double shot3);
  void rep_turn(double degree, double target_reps, double delay, double error);
  void test(double setpoint, double targ_head, double max_voltage);
  void odom_pid(double setpoint, double targ_head, double max_voltage);
  void turn(double rotation, bool right_turn, bool lock_left, double errormarg);
  void turn_slow(double rotation, bool right_turn, bool lock_left, double errormarg);

};