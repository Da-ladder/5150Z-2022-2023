#include "Conversion.h"

double inchesToTicks(double inches) { //changing to odmo wheels
  double targetTicks;

  targetTicks = inches * 39.8; //37.2

  return targetTicks;
}

double ticksToInches(double ticks) {
  double targetinches;
  double wheelDiameter = 4;

  targetinches = (ticks / 360) * (wheelDiameter * M_PI); //Returns inches traveled by 4in diameter wheels

  return targetinches;
}