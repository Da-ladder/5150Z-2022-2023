#include "vex.h"
#include "Auton.h"

using namespace vex;

chassis_Set movement;
auto_chassis attempt;// = new auto_chassis();
IMU_PID auton;

void auto_routes::leftEasySideSixShot() { //should probs document this tbh
  Brain.Timer.reset();
  flywheel_velocity.store(19600);  

  //Roller
  movement.move(-2, -2);
  wait(0.3, sec);
  intake.spin(fwd, -12, voltageUnits::volt);
  wait(0.4, sec);
  intake.spin(fwd, 0, voltageUnits::volt);
  movement.move(5, 5);
  wait(0.15, sec);
  movement.move(0, 0);
  wait(0.25, sec);

  //Intake off centerline and shoot.
  intake.spin(fwd, -12, voltageUnits::volt);
  attempt.trig_cal(6.14, 4.78, false, 7);
  wait(0.1, sec);
  movement.move(-6, -6);
  wait(0.2, sec);
  auton.rep_turn(9.96, 2, 0.05, 1);
  wait(0.7, sec);
  auton.rep_shot(19600, 19600, 19600);
  wait(0.25, sec);
  flywheel_velocity.store(19600);

  //Turn and knock down 3 stack. Then shoot.
  attempt.trig_cal(19.1, -17.84, false, 6.3);

  //INTAKE disks
  intake.spin(fwd, -12, voltageUnits::volt);
  movement.move(1.7, 1.7);
  wait(2.4, sec);
  movement.move(0, 0);
  auton.rep_turn(36.5, 2, 0.05, 1);
  wait(0.5, sec);
  intake.spin(fwd, 0, voltageUnits::volt);
  wait(0.1, sec);
  auton.rep_shot(19800, 19800, 19800); //Shooting.


  Controller1.Screen.clearScreen();
  Controller1.Screen.setCursor(1, 1);
  Controller1.Screen.print(Brain.timer(sec));
  Controller1.Screen.print(IMU.rotation(deg));
}


void auto_routes::skills_route() {
  Brain.Timer.reset();
  booper.set(true);
  flywheel_velocity.store(14850);
  //skills auton = get 4 rollers, targeting 9 - 12 shots depending on time left

  //roller 1 -8.94
  
  movement.move(-2, -2);
  wait(0.2, sec);
  intake.spin(fwd, -12, voltageUnits::volt);
  wait(0.4, sec);
  intake.spin(fwd, 0, voltageUnits::volt);
  movement.move(5, 5);
  wait(0.1, sec);
  movement.move(0, 0);
  intake.spin(fwd, -12, voltageUnits::volt);
  wait(0.05, sec);
  attempt.trig_cal(10, 11.5, false, 12);
  wait(0.025, sec);
  auton.turn(-75, true, false, 4);
  wait(0.5, sec);
  intake.spin(fwd, 0, voltageUnits::volt);

  //roller 2
  movement.move(-3, -3);
  wait(0.2, sec);
  movement.move(-2, -2);
  wait(0.5, sec);
  intake.spin(fwd, -12, voltageUnits::volt);
  wait(0.75, sec);
  intake.spin(fwd, 0, voltageUnits::volt);
  movement.move(5, 5);
  wait(0.4, sec);
  intake.spin(fwd, -12, voltageUnits::volt);
  movement.move(0, 0);
  
  //VOLLEY 1
  //attempt.trig_cal(62.09, 16.13, false, 8);
  attempt.trig_cal(70.63, 20.86, false, 8);
  intake.spin(fwd, 0, voltageUnits::volt);
  wait(0.1, sec);
  auton.rep_turn(-3.3, 2, 0.05, 1);
  auton.rep_shot2(3, 0, 1);

  
  //VOLLEY 2
  booper.set(false);
  flywheel_velocity.store(14900);
  intake.spin(fwd, -12, voltageUnits::volt);
  attempt.trig_cal(50.67, 2.74, false, 7); //44.78, -0.59
  attempt.trig_cal(70.29, -21.58, false, 5.75); //65.72, -27.28
  wait(1, sec);
  auton.rep_turn(49, 2, 0.075, 1); //45
  //auton.rep_shot2(1, 1, 1);
  
    auton.rep_shot2(3, 0, 1);
    /*
  intake.spin(fwd, 12, voltageUnits::volt);
  wait(0.2, sec);
  intake.spin(fwd, -3, voltageUnits::volt);
  wait(0.1, sec);
  intake.spin(fwd, 9, voltageUnits::volt);
  wait(1.5, sec);
  */
  //intake.spin(fwd, 0, voltageUnits::volt);
  //wait(0.1, sec);
  //intake.spin(fwd, 12, voltageUnits::volt);
  //wait(1.25, sec);
  
  
  flywheel_velocity.store(15075);
  intake.spin(fwd, 0, voltageUnits::volt);
  
  //Volley 3
  booper.set(true);
  attempt.trig_cal(93.69, -46.24, false, 10); //test |86.25, -50.7
  wait(0.1, sec);
  intake.spin(fwd, -12, voltageUnits::volt);
  movement.move(2.5, 2.5);
  wait(2, sec);
  movement.move(0, 0);
  attempt.trig_cal(112.59, -28.08, false, 10); //106.59, -43.51
  auton.rep_turn(93.84, 2, 0.05, 1); //84.27
  auton.rep_shot2(3, 0, 1);

  //MATCH LOADING
  attempt.trig_cal(113.88, -50.87, true, 9);
  wait(2, sec);
  intake.spin(fwd, -12, voltageUnits::volt);
  auton.test(25, 91.62, 5);
  wait(1.75, sec);
  auton.rep_shot2(3, 0, 1);
  attempt.trig_cal(113.88, -50.87, true, 9);
  wait(2, sec);
  intake.spin(fwd, -12, voltageUnits::volt);
  auton.test(25, 91.62, 5);
  wait(1.75, sec);
  auton.rep_shot2(3, 0, 1);

  
  //INTAKE 3 LINE STACK
  attempt.trig_cal(100.62, -58.11, false, 12); //97.22, -67.97
  intake.spin(fwd, -12, voltageUnits::volt);
  wait(0.1, sec);
  movement.move(2, 2);
  wait(2, sec);
  movement.move(0, 0);
  wait(1, sec);
  intake.spin(fwd, 0, voltageUnits::volt);
  
  //attempt.trig_cal(95.24, -79.70, true, 6);
  wait(0.05, sec);
  attempt.trig_cal(116.17, -74.7, true, 6);

  //roller 3
  //auton.turn(180, true, false, 3); //163
  movement.move(-1.7, -1.7);
  wait(0.4, sec);
  intake.spin(fwd, -12, voltageUnits::volt);
  wait(0.4, sec);
  intake.spin(fwd, 0, voltageUnits::volt);
  movement.move(5, 5);
  wait(0.5, sec);
  intake.spin(fwd, 0, voltageUnits::volt);
  movement.move(0, 0);
  
  //attempt.trig_cal(113.5, -70.57, false, 6);
  wait(0.1, sec);
  
  attempt.trig_cal(108.93, -92.05, true, 6);

  //roller 4
  //auton.turn(90, true, false, 3);
  movement.move(-1.75, -1.75);
  wait(0.5, sec);
  intake.spin(fwd, -12, voltageUnits::volt);
  wait(0.4, sec);
  intake.spin(fwd, 0, voltageUnits::volt);
  movement.move(5, 5);
  wait(0.4, sec);
  intake.spin(fwd, 0, voltageUnits::volt);
  movement.move(0, 0);

  /*
  //Volley 4
  booper.set(true);
  attempt.trig_cal(56.91, -92.31, false, 8);
  //auton.rep_turn(-175.98, 2, 0.05, 1);
  auton.rep_shot2(1, 1, 1);

  //Volley 5
  booper.set(false);
  flywheel_velocity.store(15200);
  intake.spin(fwd, -12, voltageUnits::volt);
  attempt.trig_cal(68.87, -76.44, false, 7);
  attempt.trig_cal(50.51, -53.45, false, 5.75);
  wait(1, sec);
  auton.rep_turn(226.92, 2, 0.05, 1);
  auton.rep_shot2(3, 0, 1);
  */
  
  /*
  //Volley 6
  attempt.trig_cal(27.23, -35.76, false, 12);
  intake.spin(fwd, -12, voltageUnits::volt);
  wait(0.1, sec);
  movement.move(2, 2);
  wait(2.3, sec);
  intake.spin(fwd, 0, voltageUnits::volt);
  auton.rep_turn(-81.72, 2, 0.05, 1);
  auton.rep_shot2(3, 0, 1);
  */

  //attempt.trig_cal(6.29, 2.93, true, 12);
  //auton.rep_turn(-36.6, 2, 0.05, 3);


  Controller1.Screen.clearScreen();
  Controller1.Screen.setCursor(1, 1);
  Controller1.Screen.print(Brain.timer(sec));





}


void auto_routes::rightHardSideRoller() { //do a quick auton roller for the right side
  //Set flywheel speed for first shot.
  flywheel_velocity.store(20000);
  //Roller
  attempt.trig_cal(-13, 0, true, 12);
  auton.turn(-90, false, false, 4);
  movement.move(-2, -2);
  wait(0.23, sec);
  intake.spin(fwd, -12, voltageUnits::volt);
  wait(0.4, sec);
  movement.move(5, 5);
  intake.spin(fwd, 0, voltageUnits::volt);
  wait(0.2, sec);
  movement.move(0, 0);
  intake.spin(fwd, -12, voltageUnits::volt);

  attempt.trig_cal(0.03, -17.29, false, 10); //-2.4, -17.43
  auton.rep_turn(-114.8, 2, 0.05, 1);
  wait(0.7, sec);
  auton.rep_shot(20000, 20000, 1);
  flywheel_velocity.store(20000);

  intake.spin(fwd, -12, voltageUnits::volt);
  /*
  attempt.trig_cal(-2.72, -29.22, false, 7); //-3, -26.83

  movement.move(-8, -8);
  wait(0.3, sec);
  movement.move(0, 0);
  */
  //attempt.trig_cal(15.83, -36.28, false, 9);
  attempt.trig_cal(23.84, -44.49, false, 8);
  wait(0.05, sec);
  auton.rep_turn(-134.6, 2, 0.05, 1);
  wait(0.8, sec);
  auton.rep_shot(20000, 20000, 1);
  

}


void auto_routes::backUpDischarge() { //back up discharge is test code as of nowssedgdejk
  Brain.Timer.reset();
  flywheel_velocity.store(15000);

  /*
  //Roller
  movement.move(-2, -2);
  wait(0.3, sec);
  intake.spin(fwd, -12, voltageUnits::volt);
  wait(0.5, sec);
  intake.spin(fwd, 0, voltageUnits::volt);
  movement.move(5, 5);
  wait(0.15, sec);
  movement.move(0, 0);
  wait(0.25, sec);

  //Turn and knock down 3 stack. Then shoot.
  attempt.trig_cal(19.1, -17.84, false, 7.5);

  //INTAKE disks
  intake.spin(fwd, -12, voltageUnits::volt);
  movement.move(1.7, 1.7);
  wait(2.4, sec);
  movement.move(0, 0);
  auton.rep_turn(34, 2, 0.05, 1);
  //wait(1.2, sec);
  //mag_lift.set(true);
  intake.spin(fwd, 0, voltageUnits::volt);
  wait(0.1, sec);
  auton.rep_shot(25000, 25000, 1); //Shooting.

  //Turn and intake 3 line.
  intake.spin(fwd, -12, voltageUnits::volt);
  attempt.trig_cal(1, 1, false, 7);

  //shoot
  auton.rep_turn(34, 2, 0.05, 1);
  auton.rep_shot(25000, 25000, 1); 

  //go to roller
  attempt.trig_cal(1, 1, false, 7);
  auton.turn(-90, false, false, 4);
  movement.move(-2, -2);
  wait(0.3, sec);
  intake.spin(fwd, -12, voltageUnits::volt);
  wait(0.5, sec);
  intake.spin(fwd, 0, voltageUnits::volt);
  movement.move(5, 5);
  wait(0.15, sec);
  movement.move(0, 0);
  wait(0.25, sec);
  */




  
  flywheel_velocity.store(17100);
  wait(5, sec);
  auton.rep_shot(17100, 16600, 16600);
  flywheel_velocity.store(0);
  
  
  //movement.move(-2.5,2.5);
  /*
  flywheel_velocity.store(25000);
  wait(6, sec);
  auton.rep_shot(25000, 25000, 1);
  */
  
  /*
  flywheel_velocity.store(16450);
  mag_lift.set(true);
  booper.set(false);
  wait(4, sec);
  auton.rep_shot(1, 1, 1);
  */
  //booper.set(false);
  //wait(4, sec);
  //auton.rep_shot(3, 1, 1);
  //auton.turn(90, true, false, 0.2);
  //wait(0.05, sec);
  //auton.test(5, 0, 12);
  
  //auton.rep_turn(6, 2, 0.05, 1);
  
  //wait(2, sec);
  //auton.test(48, 12);
  //attempt.trig_cal(20, -20, false, 12);
  //attempt.trig_cal(0, 0, false);
  Controller1.Screen.clearScreen();
  Controller1.Screen.setCursor(1, 1);
  Controller1.Screen.print(Brain.timer(sec));
  Controller1.Screen.print(IMU.rotation(deg));
}



void dianostics::temps() {
  Brain.Screen.clearScreen();
  Controller1.Screen.clearScreen();
  Controller1.Screen.setCursor(1, 1);
  Controller1.Screen.print(IMU.rotation(degrees));
  
  Brain.Screen.setCursor(1,1);
  Brain.Screen.print(IMU.orientation(yaw, degrees));
  Brain.Screen.setCursor(2,1);
  Brain.Screen.print("left motor A TEMP: ");
  Brain.Screen.print(leftMotorA.temperature(temperatureUnits::celsius));
  Brain.Screen.setCursor(3,1);
  Brain.Screen.print("left motor B TEMP: ");
  Brain.Screen.print(leftMotorB.temperature(temperatureUnits::celsius));
  Brain.Screen.setCursor(4,1);
  Brain.Screen.print("right motor A TEMP: ");
  Brain.Screen.print(rightMotorA.temperature(temperatureUnits::celsius));
  Brain.Screen.setCursor(6,1);
  Brain.Screen.print("right motor B TEMP: ");
  Brain.Screen.print(rightMotorB.temperature(temperatureUnits::celsius));
  Brain.Screen.setCursor(5,1);
  Brain.Screen.print("Flywheel TEMP: ");
  Brain.Screen.print(flywheel.temperature(temperatureUnits::celsius));
  Brain.Screen.setCursor(6,1);
  Brain.Screen.print("Intake TEMP: ");
  Brain.Screen.print(intake.temperature(temperatureUnits::celsius));
  Brain.Screen.render();
}

void dianostics::power_speed() {
  Brain.Screen.clearScreen();
  Brain.Screen.setCursor(1,1);
  Brain.Screen.print("left motor A Voltage (watts): ");
  Brain.Screen.print(leftMotorA.voltage());
  Brain.Screen.setCursor(2,1);
  Brain.Screen.print("left motor B Voltage (watts): ");
  Brain.Screen.print(leftMotorB.voltage());
  Brain.Screen.setCursor(3,1);
  Brain.Screen.print("right motor A Voltage (watts): ");
  Brain.Screen.print(rightMotorA.voltage());
  Brain.Screen.setCursor(4,1);
  Brain.Screen.print("right motor B Voltage (watts): ");
  Brain.Screen.print(rightMotorB.voltage());
  Brain.Screen.setCursor(5,1);
  Brain.Screen.print("left motor A SPEED (RPM 600 CAP): ");
  Brain.Screen.print(leftMotorA.velocity(velocityUnits::rpm));
  Brain.Screen.setCursor(6,1);
  Brain.Screen.print("left motor B SPEED (RPM 600 CAP): ");
  Brain.Screen.print(leftMotorB.velocity(velocityUnits::rpm));
  Brain.Screen.setCursor(7,1);
  Brain.Screen.print("right motor A SPEED (RPM 600 CAP): ");
  Brain.Screen.print(rightMotorA.velocity(velocityUnits::rpm));
  Brain.Screen.setCursor(8,1);
  Brain.Screen.print("right motor B SPEED (RPM 600 CAP): ");
  Brain.Screen.print(rightMotorB.velocity(velocityUnits::rpm));
  Brain.Screen.render();
}

void dianostics::flywheel_info() {
  Controller1.Screen.clearScreen();
  Controller1.Screen.setCursor(2, 1);
  Controller1.Screen.print(IMU.rotation(deg));
}