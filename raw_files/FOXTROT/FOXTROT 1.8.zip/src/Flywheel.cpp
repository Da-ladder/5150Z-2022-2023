#include "Flywheel.h"

void flywheel_ctrl::flywheel_tbh() {
  flywheel.setBrake(coast);
  double prev_target = 0;
  double current_target = 0;
  double sustain_power = 0; //change to 1
  double report_num = 0;
  double time_report = 3;
  double report_rate = 3; // in ms
  double current_velocity = flywheel_sped.velocity(velocityUnits::dps);
  double error;
  double kp = .0055; //0.000025 WAY TOO HIGH 0.025
  double tbh_approx = 8; //9 for 15k tune and tinker 9.1
  double tbh_at_zero = 0; //tune as well 9.3
  double tbh = 0;
  double prev_error = 0;
  bool first_cross = true;
    

  while (true) {
    current_target = flywheel_velocity.load();
    current_velocity = flywheel_sped.velocity(velocityUnits::dps);
    
    if (current_target != prev_target) { sustain_power = 0.00054 * current_target + 0.75; } //0.9
      
    error = current_target - current_velocity;

    if(comp.isAutonomous()) {
      if (std::fabs(error) < 100) {
        driver_Ready.store(true);
      } else if (driver_Ready.load()) { driver_Ready.store(false); }
    }

    tbh = sustain_power + (error * kp);
    
    if (tbh > 12) { //SET MAX VOLTAGE TO 12 AND LOWEST TO 0
      tbh = 12;
    } else if (tbh < sustain_power) {
      tbh = sustain_power;
    }

    /*
    if (std::signbit(error) != std::signbit(prev_error)) { // ZERO CROSSING CHECK s
      if (first_cross) {
        tbh = tbh_approx; // FIRST TIME SET TO APPROX VALUES
        first_cross = false;
      } else {
        tbh = 0.5 * (tbh + tbh_at_zero); // TAKE BACK HALF ALGO
        tbh_at_zero = tbh;
      }
    }
    */

    /*
    std::cout << "error :" << error << "NEW BATCH" << std::endl; //endl starts new line COUT displays to monitor/TERMINAL hk
    std::cout << "rot :" << current_velocity << std::endl; // REMOVE WHEN IN COMP MODE
    std::cout << "tbh_at_zero :" << tbh_at_zero << std::endl; //DISPLAY STATS TO TERMINAL THROUGH CONTROLLER WIRE EVERY 7 MSEC
    std::cout << "sens_avg :" << kp << std::endl;
    */
    
    if (report_rate == time_report) { std::cout << current_velocity << std::endl; time_report = 0; report_num += 1; } //current_velocity
    if (current_target == 0) { tbh = 0; /*if(comp.isDriverControl()) {Controller1.rumble("."); } */}
    
    flywheel.spin(fwd, tbh, voltageUnits::volt);

    prev_error = error;
    prev_target = current_target;
    time_report += 1;
    wait(5, msec);
  }
}