#include "vex.h"
#include "Pid.cpp"
#include "Tbh.cpp"

using namespace vex;


struct auto_routes {
  chassis_Set movement;
  IMU_PID auton;

  void leftEasySideSixShot() {
   //SPIN ROLLER
   movement.move(6,6);
   intake.spin(fwd, -12, voltageUnits::volt);
   wait(0.25, sec);
   intake.spin(fwd, 0, voltageUnits::volt);
   movement.move(-5,-5);
   wait(0.25, sec);
   movement.move(0,0);
   //END OF SPIN ROLLER

   auton.test(-6, 4.5);
   auton.rep_turn(45, 2, 0.05, true);
   auton.test(-24.5, 10); //24.3
   movement.move(-4, -4);
   intake.spin(fwd, -12, voltageUnits::volt);
   wait(0.3, sec);
   movement.move(0, 0);
   auton.test(4, 12);
   //intake.spin(fwd, 0, voltageUnits::volt);


   //turn to target --> edit during comp
   wait(0.5, sec);
   auton.rep_turn(153, 3, 0.05, true); //151
   Controller1.Screen.clearScreen();
   Controller1.Screen.setCursor(1, 1);
   Controller1.Screen.print("targeting");
   Controller1.Screen.print(IMU.orientation(yaw, degrees));


   auton.rep_shot(3, 0.5, 1.5); //0.4


   /*
   auton.rep_turn(70, 4, 0.05, true);
   movement.move(-8, -8);
   wait(0.2, sec);
   auton.rep_turn(50, 4, 0.05, true);
   auton.test(-35, 6.5);

   auton.rep_turn(126, 4, 0.05, true);

   auton.rep_shot(3, 0, 0.35);
   */
   
   auton_flywheel = false;
  }


  void skills_route() {
    //skills auton = get 4 rollers then pos to release endgame
    chassis_Set move;
    
    //INSERT ROLLER 1 CODE
    
    color_sense.setLightPower(75);
    movement.move(5,5);
    intake.spin(fwd, -8, voltageUnits::volt);
    wait(0.5, sec);
    while (color_sense.hue() < 100) {
     movement.move(3,3);
     intake.spin(fwd, -7, voltageUnits::volt);
     wait(5, msec);
   }
    intake.spin(fwd, 0, voltageUnits::volt);
    movement.move(0,0);
    
    //roller uno
    auton.test(-10, 12);
    intake.spin(fwd, -12, voltageUnits::volt);
    auton.rep_turn(-90, 4, 0.05, true);
    auton.test(-9, 12);
    wait(0.2, sec);
    auton.turn(0, true);
    auton.rep_turn(90, 4, 0.05, true);
    auton.test(14, 12);
    //INSERT ROLLER 2 CODE
    movement.move(5,5);
    intake.spin(fwd, -7.5, voltageUnits::volt);
    wait(0.75, sec);
    while (color_sense.hue() < 100) {
     movement.move(3,3);
     intake.spin(fwd, -7, voltageUnits::volt);
     wait(5, msec);
   }
    intake.spin(fwd, 0, voltageUnits::volt);
    movement.move(0,0);
    auton.test(-24, 12);
    auton.rep_turn(167, 4, 0.05, true);
    auton.test(65, 12);

    move.move(-6, 6);
    wait(0.15, sec);
    move.move(0,0);




    //roller dos
    

    /*
    wait(0.2, sec);
    auton.test(-15, 12);
    wait(0.2, sec);
    auton.rep_turn(40, 6, 0.05, true);
    

    
    wait(0.2, sec);
    auton.test(137.5, 12);
    auton.rep_turn(-90, 4, 0.05, true);
    wait(0.2, sec);
    auton.test(12, 12);
    //INSERT ROLLER 3 CODE WIP

    //roller tres
    wait(0.2, sec);
    auton.test(-18, 12);
    auton.rep_turn(-160, 1, 0.05, true);
    auton.rep_turn(-170, 1, 0.05, true);
    auton.rep_turn(-175, 4, 0.05, true);
    auton.test(12, 12);
    //INSERT ROLLER 4 CODE WIP
    */
    
  }


  void rightHardSideRoller() {
   movement.move(10, 10);
   wait(0.4,sec);
   movement.move(0, 0);

   auton.rep_turn(90, 3, 0.05, true);
   
   intake.spin(fwd, -12, voltageUnits::volt);
   movement.move(6, 6);
   wait(0.45,sec);
   movement.move(0, 0);
   intake.spin(fwd, 0, voltageUnits::volt);
   
  }


  void backUpDischarge() {
   /*
   movement.move(-10, -10);
   wait(1.05, sec);
   movement.move(0, 0);
   intake.spinFor(fwd, 4, rotationUnits::rev);
   */
   //auton.rep_turn(20, 2, 0.05, true);
   //auton.test(-20, 12); //120
   //wait(0.5, sec);
   //Controller1.Screen.print(IMU.orientation(yaw, degrees));
   //auton.turn(40, true);
   //auton.turn(90, true);
   intake.spin(fwd, -12, voltageUnits::volt);
   auton.rep_shot(3, 5, 1.5); 
  }


};



struct dianostics {
  void temps() {
    Brain.Screen.clearScreen();
    Controller1.Screen.clearScreen();
    Controller1.Screen.setCursor(1, 1);
    Controller1.Screen.print(IMU.orientation(yaw, degrees));
    
    Brain.Screen.setCursor(1,1);
    Brain.Screen.print(IMU.orientation(yaw, degrees));
    Brain.Screen.setCursor(2,1);
    Brain.Screen.print("left motor A TEMP: ");
    Brain.Screen.print(leftMotorA.temperature(temperatureUnits::celsius));
    Brain.Screen.setCursor(3,1);
    Brain.Screen.print("left motor B TEMP: ");
    Brain.Screen.print(leftMotorB.temperature(temperatureUnits::celsius));
    Brain.Screen.setCursor(4,1);
    Brain.Screen.print("right motor A TEMP: ");
    Brain.Screen.print(rightMotorA.temperature(temperatureUnits::celsius));
    Brain.Screen.setCursor(5,1);
    Brain.Screen.print("right motor B TEMP: ");
    Brain.Screen.print(rightMotorB.temperature(temperatureUnits::celsius));
    Brain.Screen.setCursor(6,1);
    Brain.Screen.print("Flywheel TEMP: ");
    Brain.Screen.print(flywheel.temperature(temperatureUnits::celsius));
    Brain.Screen.print("   Flywheel2 TEMP: ");
    Brain.Screen.print(flywheel2.temperature(temperatureUnits::celsius));
  }

  void power_speed() {
    Brain.Screen.clearScreen();
    Brain.Screen.setCursor(1,1);
    Brain.Screen.print("left motor A Voltage (watts): ");
    Brain.Screen.print(leftMotorA.voltage());
    Brain.Screen.setCursor(2,1);
    Brain.Screen.print("left motor B Voltage (watts): ");
    Brain.Screen.print(leftMotorB.voltage());
    Brain.Screen.setCursor(3,1);
    Brain.Screen.print("right motor A Voltage (watts): ");
    Brain.Screen.print(rightMotorA.voltage());
    Brain.Screen.setCursor(4,1);
    Brain.Screen.print("right motor B Voltage (watts): ");
    Brain.Screen.print(rightMotorB.voltage());
    Brain.Screen.setCursor(5,1);
    Brain.Screen.print("left motor A SPEED (RPM 600 CAP): ");
    Brain.Screen.print(leftMotorA.velocity(velocityUnits::rpm));
    Brain.Screen.setCursor(6,1);
    Brain.Screen.print("left motor B SPEED (RPM 600 CAP): ");
    Brain.Screen.print(leftMotorB.velocity(velocityUnits::rpm));
    Brain.Screen.setCursor(7,1);
    Brain.Screen.print("right motor A SPEED (RPM 600 CAP): ");
    Brain.Screen.print(rightMotorA.velocity(velocityUnits::rpm));
    Brain.Screen.setCursor(8,1);
    Brain.Screen.print("right motor B SPEED (RPM 600 CAP): ");
    Brain.Screen.print(rightMotorB.velocity(velocityUnits::rpm));
  }

  void flywheel_cal() {
    Controller1.Screen.clearScreen();
    Controller1.Screen.setCursor(1, 1);
    Controller1.Screen.print(flywheel_sped.velocity(velocityUnits::dps));
    Controller1.Screen.setCursor(2, 1);
    Controller1.Screen.print(IMU.orientation(yaw, degrees));
  }

};