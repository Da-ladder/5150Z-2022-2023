// CONTROLLER CODE
#include "objects.cpp"
#include "vex.h"
 
using namespace vex;
 
// DEFINES A AREA WHERE CONTROLLER WILL NOT ACCEPT INPUT
int deadzone = 10;
double time_shot = 0;

// FUNCTION THAT ALLOWS FOR CONTROL OF FLYWHEEL

void intake_back() {
  if (intake.voltage() > 5) {
   intake.spin(fwd, 0, voltageUnits::volt);
  } else {
   intake.spin(fwd, 12, voltageUnits::volt);
  }
}

void intake_fwd() {
  
  if (intake.voltage() < -5) {
   intake.spin(fwd, 0, voltageUnits::volt);
   intake_toggle = false;
  } else {
   intake.spin(fwd, -12, voltageUnits::volt);
   intake_toggle = true;
  }
}

void flywheel_toggle() {
  //chassis_Set controls;
  if (flywheel2.voltage() > 2) {
    fly_tog = false;
  } else {
    fly_tog = true;
  }

  /*
  if (flywheel2.voltage() > 4) {
   flywheel.spin(fwd, 0, voltageUnits::volt);
   flywheel2.spin(fwd, 0, voltageUnits::volt);
  } else {
   flywheel.spin(fwd, 12, voltageUnits::volt); //8.5 for both
   flywheel2.spin(fwd, 12, voltageUnits::volt);
  }
  */
}

void SecondaryControlMap() {
  double sensitivity = 1;
  double rOutput = 0, lOutput = 0;
  double power = 0, turn = 0;
  double leftJoystickVal = 0;
  double rightJoystickVal = 0;
  chassis_Set controls;

  if (Controller1.ButtonY.pressing()){
    t_junction.set(true); // switches the t_junction to supply air to the endgame 
  } else {
    t_junction.set(false);
  }

  leftJoystickVal = Controller1.Axis3.value();
  rightJoystickVal = Controller1.Axis1.value();
  power = (leftJoystickVal * sensitivity) / 10.58;
  turn = (rightJoystickVal * sensitivity) / 10.58;

  rOutput = -turn;
  lOutput = turn;

  controls.move(rOutput, lOutput);

     if (Controller1.Axis3.value() < deadzone ||
       Controller1.Axis4.value() < deadzone ||
       Controller1.Axis2.value() < deadzone) {
     controls.stop_launch();
   }
}
// FUNCTION THAT ALLOWS FOR A ARCADE STYLE OF DRIVE
void PrimaryControlMap() {
  int leftJoystickVal = 0, rightJoystickVal = 0;
 
  // ALLOWS FOR CONTROLS TO BE TUNED TO DRIVER'S PREFRENCE
  double sensitivity = 1;
  double turn = 0, power = 0;
  double lOutput = 0, rOutput = 0;
 
  // CREATES AN OBJECT
  chassis_Set controls;
  hopper_feed.set(false);
 
  rightJoystickVal = Controller1.Axis3.value();
  leftJoystickVal = Controller1.Axis1.value();

  Controller1.ButtonL1.pressed(flywheel_toggle);
  Controller1.ButtonA.pressed(intake_fwd);

  if (fly_tog){
   flywheel.spin(fwd, 8.15, voltageUnits::volt); //8.5 for both 9.5 for long range
   flywheel2.spin(fwd, 8.15, voltageUnits::volt);
  } else if (!fly_tog) {
   flywheel.spin(fwd, 0, voltageUnits::volt); //8.5 for both
   flywheel2.spin(fwd, 0, voltageUnits::volt);
  }

  

  if (Controller1.ButtonL2.pressing()) {
    hopper_feed.set(true);
  } else {
    hopper_feed.set(false);
  }

  if (Controller1.ButtonR1.pressing()){ intake.spin(fwd, -12, voltageUnits::volt); }
  else if (Controller1.ButtonR2.pressing()) { intake.spin(fwd, 12, voltageUnits::volt); }
  else if (intake_toggle) { intake.spin(fwd, -12, voltageUnits::volt); }
  else {intake.spin(fwd, 0, voltageUnits::volt); }
 
  turn = (leftJoystickVal * sensitivity) / 10.58; //Sets power 
  power = (rightJoystickVal * sensitivity) / 10.58;
 
  lOutput = turn + power;
  rOutput = -turn + power;
 
  // APPLIES POWER TO THE MOTOR FROM OBJECT
  controls.move(rOutput, lOutput);

 
  // CHECKS IF THE CONTROLS ARE MOVING IF NOT
  // SET MOTORS TO BRAKE
  if (Controller1.Axis3.value() < deadzone ||
      Controller1.Axis4.value() < deadzone ||
      Controller1.Axis2.value() < deadzone) {
    controls.brake();
   }
 }
