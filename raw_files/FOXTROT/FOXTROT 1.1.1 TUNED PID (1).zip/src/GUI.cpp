#include "Auton.cpp"
#include "vex.h"

using namespace vex;



struct GUI {

  

  int bH = 100;
  int bW = 225;

  // BOX 1
  int b1Y = 10; // y pos of box
  int b1X = 10; // x pos of box
  int b1EndY = b1Y + bH; // end y pos of box
  int b1EndX = b1X + bW; // end x pos of box

  // BOX 2
  int b2Y = 10;
  int b2X = 245;
  int b2EndY = b2Y + bH;
  int b2EndX = b2X + bW;

  // BOX 3
  int b3Y = 120;
  int b3X = 10;
  int b3EndY = b3Y + bH;
  int b3EndX = b3X + bW;

  // BOX 4
  int b4Y = 120;
  int b4X = 245;
  int b4EndY = b4Y + bH;
  int b4EndX = b4X + bW;


  void drawMainGUI () {
   
   /*-------------------Button 1-------------------*/
   Brain.Screen.drawRectangle(b1X, b1Y, bW, bH, 240);
   Brain.Screen.printAt(60, 60, "leftEasySideSixShot");

   /*-------------------Button 2-------------------*/
   Brain.Screen.drawRectangle(b2X, b2Y, bW, bH, 120);
   Brain.Screen.printAt(270, 60, "rightHardSideRoller");

   /*-------------------Button 3-------------------*/
   Brain.Screen.drawRectangle(b3X, b3Y, bW, bH, 30);
   Brain.Screen.printAt(60, 170, "Skills");

   /*-------------------Button 4-------------------*/
   Brain.Screen.drawRectangle(b4X, b4Y, bW, bH, 200);
   Brain.Screen.printAt(270, 170, "backUpDischarge");

  } 

  void selectAuton () {
   //bool selectingAuton = true; not in use currently
   

   int x = Brain.Screen.xPosition();
   int y = Brain.Screen.yPosition();

    if ((x >= b4X && x <= b4EndX)&&(y >= b4Y && y <= b4EndY)&&confirm) {
     Brain.Screen.setCursor(1, 1);
     Brain.Screen.clearScreen();
     Brain.Screen.print("Setting up...");
     wait(1, sec);
     lTracking.setPosition(0, deg);
     IMU.calibrate();
     while(IMU.isCalibrating()){wait(10, msec);}
     Brain.Screen.clearScreen();
     Brain.Screen.setCursor(1, 1);
     Brain.Screen.print("ready");
    }

    if (!confirm) {
      if ((x >= b1X && x <= b1EndX)&&(y >= b1Y && y <= b1EndY)) {
       //Brain.Screen.clearScreen();
       Brain.Screen.setCursor(8, 1);
       Brain.Screen.print("leftEasySideSixShot");
       auto_num = 1;
     }else if ((x >= b2X && x <= b2EndX)&&(y >= b2Y && y <= b2EndY)) {
       //Brain.Screen.clearScreen();
       Brain.Screen.setCursor(8, 1);
       Brain.Screen.print("rightHardSideRoller");
       auto_num = 2;
     } else if ((x >= b3X && x <= b3EndX)&&(y >= b3Y && y <= b3EndY)) {
       //Brain.Screen.clearScreen();
       Brain.Screen.setCursor(8, 1);
       Brain.Screen.print("Skills");
       auto_num = 3;
     } else if ((x >= b4X && x <= b4EndX)&&(y >= b4Y && y <= b4EndY)) {
       //Brain.Screen.clearScreen();
       Brain.Screen.setCursor(8, 1);
       Brain.Screen.print("backUpDischarge");
       auto_num = 4;
     }
     Brain.Screen.clearScreen();
     Brain.Screen.drawRectangle(b4X, b4Y, bW, bH, 200);
     Brain.Screen.printAt(270, 170, "Confirm/Calibrate?");
     confirm = true;
     
    }
    
  }

  void runAUTO () {
    auto_routes routes;

    if (auto_num == 1) {
      routes.leftEasySideSixShot();
    } else if (auto_num == 2) {
      routes.rightHardSideRoller();
    } else if (auto_num == 3) {
      routes.skills_route();
    } else if (auto_num == 4) {
      routes.backUpDischarge();
    }
  }


};

