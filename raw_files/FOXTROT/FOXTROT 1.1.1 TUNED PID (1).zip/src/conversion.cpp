// CONVERSION FILE NOT IN USE FOR PID
#include "vex.h"

using namespace vex;

double inchesToTicks(double inches) { //changing to odmo wheels
 double targetTicks;
 
 targetTicks = inches * 38.5; //37.2
 
 return targetTicks;
}

double ticksToInches(double ticks) {
 double targetinches;
 double wheelDiameter = 4;
 
 targetinches = (ticks / 360) * (wheelDiameter * M_PI); //Returns inches traveled by 4in diameter wheels
 
 return targetinches;
}