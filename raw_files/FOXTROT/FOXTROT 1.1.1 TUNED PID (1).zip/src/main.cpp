/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       VEX                                                       */
/*    Created:      Thu Sep 26 2019                                           */
/*    Description:  Competition Template                                      */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// ---- END VEXCODE CONFIGURED DEVICES ----


#include "GUI.cpp"

#include "vex.h"
#include "Vision_cal.h"
#include <iostream>
#include <sstream>
#include <thread>

using namespace vex;

vex::mutex m;

// A global instance of competition
competition Competition;

// define your global instances of motors and other devices here dssddxxwwsg
double current_velocity = flywheel_sped.velocity(velocityUnits::dps);
double error;
double kp = 0.000026; //0.000025
double tbh_approx = 6; //9 for 15k tune and tinker 9.1
double tbh_at_zero = 8; //tune as well 9.3
double tbh = 0;
double prev_error = 0;
double test_var = 0;
bool first_cross = true;

/* // UNDERSTAND AND WORK WITH CLASSES IN FUTURE UPDATES ss
class aPass { //mutex SHOULD lock entire class
    public:
        static double get() {
            m.lock();
            return aPass_;
            m.unlock();
        }

        static void set(const double setThis) {
            m.lock();
            aPass_ = setThis;
            m.unlock();
        }
    private:
        static double aPass_;
}; */


void flywheel_pid() { 
  chassis_Set flywheel;

  while (auton_flywheel) { // global var
   current_velocity = flywheel_sped.velocity(velocityUnits::dps);
   error = flywheel_velocity - current_velocity; //flywheel veo is global var
   
   Brain.Screen.setCursor(1, 1);
   Brain.Screen.clearScreen();


   tbh = tbh + (error * kp); 
     
   if (tbh > 12) { //SET MAX VOLTAGE TO 12 AND LOWEST TO 0
     tbh = 12;
   } else if (tbh < 0) {
     tbh = 0;
   }


   if (signbit(error) != signbit(prev_error)) { // ZERO CROSSING CHECK s
     if (first_cross) {
         tbh = tbh_approx; // FIRST TIME SET TO APPROX VALUES
         first_cross = false;
       } else {
         tbh = 0.5 * (tbh + tbh_at_zero); // TAKE BACK HALF ALGO
         tbh_at_zero = tbh;
       }
   }

   
   std::cout << "error :" << error << "NEW BATCH" << std::endl; //endl starts new line COUT displays to monitor/TERMINAL
   std::cout << "rot :" << current_velocity << std::endl; // REMOVE WHEN IN COMP MODE
   std::cout << "tbh_at_zero :" << tbh_at_zero << std::endl; //DISPLAY STATS TO TERMINAL THROUGH CONTROLLER WIRE EVERY 7 MSEC
   std::cout << "sens_avg :" << kp << std::endl;

   flywheel.fly_vol(tbh);
   prev_error = error;

   wait(1, msec);
  }
  //flywheel.fly_vol(0);
  this_thread::sleep_for(40);
}



void selectAuton() {
  GUI auton_pick;

  auton_pick.selectAuton();

}



/*---------------------------------------------------------------------------*/
/*                          Pre-Autonomous Functions                         */
/*                                                                           */
/*  You may want to perform some actions before the competition starts.      */
/*  Do them in the following function.  You must return from this function   */
/*  or the autonomous and usercontrol tasks will not be started.  This       */
/*  function is only called once after the V5 has been powered on and        */
/*  not every time that the robot is disabled.                               */
/*---------------------------------------------------------------------------*/

void pre_auton(void) {
  vexcodeInit(); // Initializing Robot Configuration. DO NOT REMOVE! ss
  // static aPass vars_set;
  GUI auton_pick;
  lTracking.setPosition(0, deg);
  IMU.calibrate();
  while(IMU.isCalibrating()){wait(10, msec);}  Controller1.Screen.print("ready");
  
  auton_pick.drawMainGUI();
  Brain.Screen.pressed(selectAuton);

  // All activities that occur before the competition starts
  // Example: clearing encoders, setting servo positions, ...
}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              Autonomous Task                              */
/*                                                                           */
/*  This task is used to control your robot during the autonomous phase of   */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/


void autonomous(void) { //ADD IMAGES TO SD CARD SO WE CAN GET PICS ON THE BRAIN ww
  //USE COMP SWITCH TO TEST AUTON
  Brain.Screen.pressed(selectAuton);
  chassis_Set flywheel;
  GUI auton_run;
  auton_flywheel = true;

  //INITALIZE FLYWHEEL TBH ss
  
  
  flywheel_velocity = 14640; //14350 PLZ tune/tinker 14500m  14700 e 14200 vbndssffssvbnss
  vex::thread thread1(flywheel_pid);
  thread1.detach();
  Controller1.Screen.print("detached");
  
  
  
  
    
  
  

  
  
  //DETACH FLYWHEEL TBH TO ITS OWN THREAD
  auto_num = 1;
  //wait(5, sec);

  auton_run.runAUTO();
  //wait(1, sec);
  //Controller1.Screen.print(IMU.orientation(yaw, degrees)); 
  //thread1.interrupt();
  //flywheel.fly_vol(0);



  //LEAVE BLANK FOR NOW
  // ..........................................................................
  // Insert autonomous user code here.
  // ..........................................................................
}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              User Control Task                            */
/*                                                                           */
/*  This task is used to control your robot during the user control phase of */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/

void usercontrol(void) {
  auton_flywheel = false;
  
  // User control code here, inside the loop

  while (true) {
    Brain.Screen.pressed(selectAuton);
    // If L1 is held down secondary control map
    if (Controller1.ButtonL1.pressing()) {
      SecondaryControlMap();

    } else  
      PrimaryControlMap(); // Primary Control Map = full chassis control + intake //FLAG bnmvbfgvbnhdfg
      Brain.Screen.clearScreen();
      Controller1.Screen.clearScreen();
      Controller1.Screen.setCursor(1, 1);
      //Controller1.Screen.print(IMU.orientation(yaw, degrees));
      Controller1.Screen.print(IMU.rotation(rotationUnits::deg));
      Brain.Screen.setCursor(6,1);
      Brain.Screen.print("Flywheel TEMP: ");
      //Brain.Screen.print(flywheel.temperature(temperatureUnits::celsius));
      Brain.Screen.print(leftMotorA.temperature(temperatureUnits::celsius));
      Brain.Screen.print("   Flywheel2 TEMP: ");
      //Brain.Screen.print(flywheel2.temperature(temperatureUnits::celsius));
      Brain.Screen.print(rightMotorA.temperature(temperatureUnits::celsius));


    wait(15, msec); // Sleep the task for a short amount of time to
                    // prevent wasted resources.
  }
}

//
// Main will set up the competition functions and callbacks.
//
int main() {
  // Set up callbacks for autonomous and driver control periods.
  Competition.autonomous(autonomous);
  Competition.drivercontrol(usercontrol);
  Brain.Screen.pressed(selectAuton);

  // Run the pre-autonomous function.
  pre_auton();

  //USE COMP SWITCH

  // Prevent main from exiting with an infinite loop.
  while (true) {
   wait(20, msec);
  }
}
