/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       VEX                                                       */
/*    Created:      Thu Sep 26 2019                                           */
/*    Description:  Competition Template                                      */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "Pid.cpp"
#include "vex.h"
#include <iostream>
#include <sstream>

using namespace vex;

// A global instance of competition
competition Competition;

// define your global instances of motors and other devices here

/*---------------------------------------------------------------------------*/
/*                          Pre-Autonomous Functions                         */
/*                                                                           */
/*  You may want to perform some actions before the competition starts.      */
/*  Do them in the following function.  You must return from this function   */
/*  or the autonomous and usercontrol tasks will not be started.  This       */
/*  function is only called once after the V5 has been powered on and        */
/*  not every time that the robot is disabled.                               */
/*---------------------------------------------------------------------------*/

void pre_auton(void) {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();
  IMU.calibrate();
  IMU.setHeading(0, deg); // HOTFIX fix later
  t_junction.set(false); //set to true or false depending on how we link them
  drawGUI();
  Brain.Screen.pressed(selectAuton);
  // All activities that occur before the competition starts
  // Example: clearing encoders, setting servo positions, ...
}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              Autonomous Task                              */
/*                                                                           */
/*  This task is used to control your robot during the autonomous phase of   */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/

void autonomous(void) {
  //USE COMP SWITCH TO TEST AUTON
  
  //IMU_PID auton;
  //chassis_Set flywheel;
  //if (button.pressing()) {
    //Brain.Screen.print("Right side auton enabledl");
    //Brain.Screen.print("There is NONE");
    // RIGHT SIDE AUTON
    /*
    flywheel.move(-10, -10);
    wait(1, sec);
    flywheel.move(0, 0);
    intake.spin(fwd, 12, voltageUnits::volt);
    wait(2, sec);
    intake.spin(fwd, 0, voltageUnits::volt);
    flywheel.move(10, 10);
    wait(1, sec);
    flywheel.move(0, 0);
    wait(1, sec);
    */ 

    /*
    //ROLLER AUTON
    flywheel.move(5, 5);
    wait(0.9, sec);
    flywheel.move(-10, 10);
    wait(0.4, sec);
    flywheel.move(5,5); //4
    intake.spin(fwd, -12, voltageUnits::volt);
    wait(0.95, sec);
    flywheel.move(0,0);
    intake.spin(fwd, 0, voltageUnits::volt);
    flywheel.move(-5, -5);
    wait(0.4, sec);
    flywheel.move(0, 0);
   */
    

     //SKILLS AUTON
   //GET DISKS INTO HIGH GOAL 2 = 10 points cal as needed
   

   


   

    //input right side code here
  //} else {
    /*
   flywheel.launch(12); //change this to change range of flywheel 11.6
   wait(1.1, sec); 
   hopper_feed.set(true);
   wait(0.5, sec);
   flywheel.launch(0); //
   hopper_feed.set(false);
   wait(0.5, sec);
   flywheel.launch(12); //change this to change range of flywheel 11.45
   wait(0.55, sec); 
   hopper_feed.set(true);
   wait(0.5, sec);
   flywheel.launch(0);
   hopper_feed.set(false);
   flywheel.move(5, 5);
   wait(0.3, sec);
   flywheel.move(-10, 10);
   wait(0.5, sec);
   flywheel.move(-9, -8); // -7 -9
   wait(0.15, sec);
   flywheel.move(0, 0);
   wait(3, sec);
   t_junction.set(true);
   */

   //GET DISKS INTO HIGH GOAL 2 = 10 points cal as needed
   /*
   flywheel.launch(12); //change this to change range of flywheel 11.6
   wait(4, sec); 
   hopper_feed.set(true);
   wait(0.5, sec);
    //flywheel.launch(0);
   hopper_feed.set(false);
   wait(0.5, sec);
   intake.spinFor(fwd, -2, rotationUnits::rev);
   flywheel.launch(12); //change this to change range of flywheel 11.45
   wait(1, sec); 
   hopper_feed.set(true);
   wait(0.5, sec);
   flywheel.launch(0);
   hopper_feed.set(false);
   */
   /*

    //ROLL ROLLERS = 10 points
   flywheel.move(4, 4);
    wait(0.3, sec);
   flywheel.move(6, -6); // -6 before
   wait(0.95, sec);
   flywheel.move(0, 0);
   flywheel.move(6, 2);
   wait(0.8, sec); // 0.6 before
   flywheel.move(10.4, 6);
   intake.spin(fwd, -12, voltageUnits::volt);
   wait(1.1, sec);
   flywheel.move(0, 0);
   intake.spin(fwd, 0, voltageUnits::volt);
   */

   /*

   // roller ONLY AUTON
   flywheel.move(4, 4);
   intake.spin(fwd, -12, voltageUnits::volt);
   wait(0.2, sec);
   flywheel.move(-4, -4);
   intake.spin(fwd, 0, voltageUnits::volt);
   wait(0.2, sec);
   flywheel.move(0, 0);
   */ //FKAH
   

  
   /* //AUTON BACK UP AND discharge disks = 2 points
   flywheel.move(-10, -10);
   wait(1.05, sec);
   flywheel.move(0, 0);
   intake.spinFor(fwd, 4, rotationUnits::rev);
   */ //FLAG
  }

  //LEAVE BLANK FOR NOW
  // ..........................................................................
  // Insert autonomous user code here.
  // ..........................................................................
//}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              User Control Task                            */
/*                                                                           */
/*  This task is used to control your robot during the user control phase of */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/

void usercontrol(void) {
  // User control code here, inside the loop
  while (1) {
    
    // If L1 is held down secondary control map
    if (Controller1.ButtonL1.pressing()) {
      Brain.Screen.clearScreen();
      //IMU.calibrate();
      //Odometry();
      
      SecondaryControlMap(); //controls flywheel mech/endgame/side to side movement.
      // R1 is debug code
    } 
    //else if (Controller1.ButtonL2.pressing()) {
      
      
      /*if (Controller1.ButtonA.pressing()) {
        IMU.setHeading(0, degrees);
        rTracking.setPosition(0, degrees);
        bTracking.setPosition(0, degrees);
      }
      */
    //}
    else if (Controller1.ButtonR1.pressing()) { 
      //I've commented the code for sensor data output. This way we can read temps easier.
      /*
      Brain.Screen.clearScreen();
      Brain.Screen.setCursor(5,1);
      Brain.Screen.print(IMU.angle());
      Brain.Screen.setCursor(1,1);
      Brain.Screen.print("left motor A: ");
      Brain.Screen.print(leftMotorA.rotation(rotationUnits::raw));
      Brain.Screen.setCursor(2,1);
      Brain.Screen.print("left motor B: ");
      Brain.Screen.print(leftMotorB.rotation(rotationUnits::raw));
      Brain.Screen.setCursor(3,1);
      Brain.Screen.print("right motor A: ");
      Brain.Screen.print(rightMotorA.rotation(rotationUnits::raw));
      Brain.Screen.setCursor(4,1);
      Brain.Screen.print("right motor B: ");
      Brain.Screen.print(rightMotorB.rotation(rotationUnits::raw));
      Brain.Screen.setCursor(6,1);
      Brain.Screen.print("Left Encoder: ");
      Brain.Screen.print(Leftencoder.position(degrees));
      Brain.Screen.setCursor(7,1);
      Brain.Screen.print("Right Encoder: ");
      Brain.Screen.print(Rightencoder.position(degrees));
      Brain.Screen.setCursor(8,1);
      */
      //Motor temps.
      Brain.Screen.print("left motor A TEMP: ");
      Brain.Screen.print(leftMotorA.temperature(temperatureUnits::celsius));
      Brain.Screen.setCursor(9,1);
      Brain.Screen.print("left motor B TEMP: ");
      Brain.Screen.print(leftMotorB.temperature(temperatureUnits::celsius));
      Brain.Screen.setCursor(10,1);
      Brain.Screen.print("right motor A TEMP: ");
      Brain.Screen.print(rightMotorA.temperature(temperatureUnits::celsius));
      Brain.Screen.setCursor(11,1);
      Brain.Screen.print("right motor B TEMP: ");
      Brain.Screen.print(rightMotorB.temperature(temperatureUnits::celsius));
      Brain.Screen.setCursor(12,1);
      Brain.Screen.print("Flywheel TEMP: ");
      Brain.Screen.print(flywheel.temperature(temperatureUnits::celsius));
      Brain.Screen.print("   Flywheel2 TEMP: ");
      Brain.Screen.print(flywheel2.temperature(temperatureUnits::celsius));
      // Above code is for debug use ONLY. Remove during finalization
    } 
    /*
    else if (Controller1.ButtonR2.pressing()) {
      Brain.Screen.clearScreen();
      Brain.Screen.setCursor(1,1);
      Brain.Screen.print("left motor A Voltage (watts): ");
      Brain.Screen.print(leftMotorA.voltage());
      Brain.Screen.setCursor(2,1);
      Brain.Screen.print("left motor B Voltage (watts): ");
      Brain.Screen.print(leftMotorB.voltage());
      Brain.Screen.setCursor(3,1);
      Brain.Screen.print("right motor A Voltage (watts): ");
      Brain.Screen.print(rightMotorA.voltage());
      Brain.Screen.setCursor(4,1);
      Brain.Screen.print("right motor B Voltage (watts): ");
      Brain.Screen.print(rightMotorB.voltage());
      Brain.Screen.setCursor(5,1);
      Brain.Screen.print("left motor A SPEED (RPM 600 CAP): ");
      Brain.Screen.print(leftMotorA.velocity(velocityUnits::rpm));
      Brain.Screen.setCursor(6,1);
      Brain.Screen.print("left motor B SPEED (RPM 600 CAP): ");
      Brain.Screen.print(leftMotorB.velocity(velocityUnits::rpm));
      Brain.Screen.setCursor(7,1);
      Brain.Screen.print("right motor A SPEED (RPM 600 CAP): ");
      Brain.Screen.print(rightMotorA.velocity(velocityUnits::rpm));
      Brain.Screen.setCursor(8,1);
      Brain.Screen.print("right motor B SPEED (RPM 600 CAP): ");
      Brain.Screen.print(rightMotorB.velocity(velocityUnits::rpm));
      Brain.Screen.setCursor(9,1);
      Brain.Screen.print("Flywheel SPEED (ACTUAL RPM): ");
      Brain.Screen.print(flywheel.velocity(velocityUnits::rpm) * 6);
      Brain.Screen.setCursor(10,1);
      Brain.Screen.print("Flywheel SPEED (ACTUAL RPM): ");
      Brain.Screen.print(flywheel2.velocity(velocityUnits::rpm) * 6);
      Brain.Screen.setCursor(11,1);
      Brain.Screen.print(ultrason.distance(inches));



    } */ 
    else 
      PrimaryControlMap(); // Primary Control Map = full chassis control + intake
    // This is the main execution loop for the user control program.
    // Each time through the loop your program should update motor + servo
    // values based on feedback from the joysticks.

    // ........................................................................
    // Insert user code here. This is where you use the joystick values to
    // update your motors, etc.
    // ........................................................................

    wait(20, msec); // Sleep the task for a short amount of time to
                    // prevent wasted resources.
  }
}

//
// Main will set up the competition functions and callbacks.
//
int main() {
  // Set up callbacks for autonomous and driver control periods.
  Competition.autonomous(autonomous);
  Competition.drivercontrol(usercontrol);


  // Run the pre-autonomous function.
  pre_auton();
  //autonomous();

  // Prevent main from exiting with an infinite loop.
  while (true) {

    wait(20, msec);
  }
}
