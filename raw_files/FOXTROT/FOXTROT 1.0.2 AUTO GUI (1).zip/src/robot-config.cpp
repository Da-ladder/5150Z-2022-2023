#include "vex.h"

using namespace vex;

// A global instance of brain used for printing to the V5 brain screen
brain Brain;

// CONTROLLER DEFINTION
controller Controller1 = controller(primary);

// CHASSIS MOTOR DEFINITIONS A = front B = Back
motor leftMotorA = motor(PORT12, ratio6_1, false); //blue cartridge
motor leftMotorB = motor(PORT11, ratio6_1, false); //blue cartridge
motor rightMotorA = motor(PORT18, ratio6_1, true); //blue cartridge
motor rightMotorB = motor(PORT20, ratio6_1, true); //blue cartridge

//FLYWHEEL DEFINITION
motor flywheel = motor(PORT17, ratio6_1, true); //blue cartridge
motor flywheel2 = motor(PORT15, ratio6_1, true); //blue cartridge

//INTAKE DEFINITION
motor intake1 = motor(PORT6, ratio18_1, false); //red cartridge
motor intake2 = motor(PORT7, ratio18_1, true);

// PNEUMATICS DEFINITION
digital_out grappling_hook = digital_out(Brain.ThreeWirePort.A);
digital_out hopper_feed = digital_out(Brain.ThreeWirePort.B);
digital_out t_junction = digital_out(Brain.ThreeWirePort.C);

// IMU DEFINTION
inertial IMU = inertial(PORT10);

// ULTRASONIC/BUMPER SENSOR DEFINITIONS
sonar ultrason = sonar(Brain.ThreeWirePort.G); //G is output H is input
bumper button = bumper(Brain.ThreeWirePort.A);

// TRACKING WHEEL DEFINITIONS
rotation lTracking = rotation(PORT9, true); //tracking is not in use currently.
rotation rTracking = rotation(PORT8, true); 
rotation bTracking = rotation(PORT22, true);

encoder Leftencoder = encoder(Brain.ThreeWirePort.G);
encoder Rightencoder = encoder(Brain.ThreeWirePort.E);
encoder Backencoder = encoder(Brain.ThreeWirePort.F);

// MOTOR GROUPS
motor_group leftDrive(leftMotorA, leftMotorB);
motor_group rightDrive(rightMotorA, rightMotorB);
motor_group intake(intake1, intake2);

// DRIVE BASE
smartdrive chassis = smartdrive(leftDrive, rightDrive, IMU, 319.19, 320, 293, mm, 0.42857142857142855);
/**
 * Used to initialize code/tasks/devices added using tools in VEXcode Pro.
 *
 * This should be called at the start of your int main function.
 */
void vexcodeInit(void) {
  // Nothing to initialize
}