// CONTROLLER CODE
#include "objects.cpp"
#include "vex.h"

using namespace vex;

double currentY = 0; //Robot's current yPos. Will be calculated every 20ms in a loop.
double currentX = 0; //Robot's current xPos. Will be calculated every 20ms in a loop.
double currentHdg = 0; //Robot's current heading. Will be calculated every 20ms in a loop.

//Odometry function. Place in parameters: double xPos, double yPos, double hdg
void Odometry () { //Input parameters are where we want the robot to be.
  //Zeroing.
  rTracking.resetPosition();
  lTracking.resetPosition();
  //IMU.resetHeading();
  //Declarations
  
 
  double leftVal; //Left encoder's current value.
  double rightVal; //Right encoder's current value.
  //double backVal; //Back encoder's current value.
 
  double wheelDiam = 2.753; //Odometry wheel diameter. In inches. 2.752
  double wheelDiamB = 2.75; //Flex wheel odom wheel?
  
  double disTrackL = 1.7; //Distance of left odom wheel from tracking center. In inches.
  double disTrackR = 2.2; //Distance of Right odom wheel from tracking center. In inches.
  //double disTrackBack = 4; //Distance of back odom wheel from tracking center. In inches.

  double moveLeft; //Distance left odom wheel moves in inches. Calculated using odom wheel diameter.
  double moveRight;
  //double moveBack; 

  double arcRadY; //Radius of arc made by left/right odom wheels. In inches.
  double arcRadX; //Radius of arc made by back odom wheel. In inches.
  
  //Calculations.
  while (Controller1.ButtonL2.pressing()) { //Controller1.ButtonL2.pressing()
    rightVal = rTracking.position(degrees);
    leftVal = lTracking.position(degrees);

    moveRight = (wheelDiam * ((rTracking.position(degrees)) * (M_PI/180))) / 2;
    moveLeft = wheelDiamB * (lTracking.position(degrees) * (M_PI/180));

    //currentHdg = IMU.orientation(yaw, degrees); //* (M_PI/180); 
    //Function TBD. Also, remember to calibrate/zero heading.
    
    currentHdg = (moveLeft - moveRight)/(disTrackL + disTrackR); //Calculates current/new heading of robot.
    
    //arcRadY = (moveRight/currentHdg) + disTrackR;
    //arcRadX = (moveBack/currentHdg) + disTrackBack;
    
    //currentY = ((2 * (sin(currentHdg/2)) * ((moveRight/currentHdg) + disTrackR)) + 4.75)/2; //4.75
    //currentX = ((2 * (sin(currentHdg/2)) * ((moveBack/currentHdg) + disTrackBack)) + 2)/2; //2

    //Makes changes to robot's position. CODE TO BE ADDED.
    //Declares relevant variables.
      
      //double vector;
      //vector = currentHdg + (90 - (tan(yPos/xPos))); //Vector from robot's current pos to destination.

    //Prints calculated robot position.
    /* Brain.Screen.setCursor(2, 1);
    Brain.Screen.print("X pos: ");
    Brain.Screen.print(currentX);
    
    Brain.Screen.setCursor(3, 1);
    Brain.Screen.print("Y pos: ");
    Brain.Screen.print(currentY);
    */
    Brain.Screen.setCursor(3, 1);
    Brain.Screen.print("Hdg(deg): ");
    Brain.Screen.print(currentHdg);
    
    Brain.Screen.setCursor(2, 1);
    Brain.Screen.print("Move(in): ");
    Brain.Screen.print(moveRight);

    Brain.Screen.setCursor(4, 1);
    Brain.Screen.print("IMU: ");
    Brain.Screen.print(IMU.orientation(yaw, degrees));
    
    Controller1.Screen.setCursor(1, 1);
    Controller1.Screen.print(IMU.orientation(yaw, degrees));
    
    chassis_Set pursuit;
    double move = 15;
    if (moveRight < (move)) {
      pursuit.move(5, 5);
    } 
    else if (moveRight > (move + 0.3)) {
      pursuit.move(-3, -3);
    } 
    else {
      pursuit.move(0, 0);
    } /* 
    if (currentHdg < 80) {
      pursuit.move(-3.9, 3.9);
    } 
    else if (currentHdg > 82) {
      pursuit.move(2, -2);
    } 
    else {
      pursuit.move(0, 0);
    } */
    wait(3, msec);
  }
}

void purePursuit () {
  //Declarations.
  
  /*
  double xOrg, yOrg;
  xOrg = currentX;
  yOrg = currentY; */
  
  while (currentY < 10) {
    Odometry();
    //pursuit.move(5, 5);
  }
}

void drawGUI () {
  int bH = 50;
  int bW = 100;
  //*******************************************************
  //Button 1
  int b1Y = 10;
  int b1X = 10;

  int b1EndY = b1Y + bH;
  int b1EndX = b1X + bW;

  Brain.Screen.drawRectangle(b1X, b1Y, bW, bH);
  Brain.Screen.printAt(60, 35, "Left-Side Shoot");
  //*******************************************************
  //Button 2
  int b2Y = 10;
  int b2X = 120;

  int b2EndY = b2Y + bH;
  int b2EndX = b2X + bW;

  Brain.Screen.drawRectangle(b2X, b2Y, bW, bH);
  Brain.Screen.printAt(170, 35, "Right-Side Shoot");
  //*******************************************************
  //Button 3
  int b3Y = 70;
  int b3X = 10;

  int b3EndY = b3Y + bH;
  int b3EndX = b3X + bW;

  Brain.Screen.drawRectangle(b3X, b3Y, bW, bH);
  Brain.Screen.printAt(60, 95, "Left-Side Roll");
  //*******************************************************
  //Button 4
  int b4Y = 70;
  int b4X = 120;

  int b4EndY = b4Y + bH;
  int b4EndX = b4X + bW;

  Brain.Screen.drawRectangle(b4X, b4Y, bW, bH);
  Brain.Screen.printAt(170, 95, "Right-Side Roll");
} 
void selectAuton () {
  bool selectingAuton = true;

  int x = Brain.Screen.xPosition();
  int y = Brain.Screen.yPosition();

  if ((x >= 10 && x <= 110)&&(y >= 10 && y <= 60)) {
    Brain.Screen.clearScreen();
    Brain.Screen.printAt(1, 1, "Left-Side Shoot");
  }
  else{}
} 