using namespace vex;

extern brain Brain;

// VEXcode devices
extern smartdrive chassis;
extern controller Controller1;

extern motor_group leftDrive;
extern motor_group rightDrive;

extern motor leftMotorA;
extern motor leftMotorB;
extern motor rightMotorA;
extern motor rightMotorB;
extern motor flywheel;
extern motor flywheel2;
extern motor_group intake;
extern motor roller;

extern digital_out hopper_feed; //hopper_feed refers to indexer.
extern digital_out grappling_hook;
extern digital_out t_junction;


extern inertial IMU;
extern sonar ultrason;
extern bumper button;

extern rotation lTracking;
extern rotation rTracking;
extern rotation bTracking;
extern encoder Leftencoder;
extern encoder Rightencoder;
extern encoder Backencoder;

extern double inchesToTicks(double inches);
extern double ticksToInches(double ticks);

extern void chassisControlTank();
extern void PrimaryControlMap();
extern void SecondaryControlMap();
extern void purePursuit();
extern void Odometry();
extern void drawGUI();
extern void selectAuton();
extern int b1X, b1Y, b1EndX, b1EndY, b2X, b2Y, b2EndX, b2EndY, b3X, b3Y, b3EndX, b3EndY, b4X, b4Y, b4EndX, b4EndY;

/**
 * Used to initialize code/tasks/devices added using tools in VEXcode Pro.
 *
 * This should be called at the start of your int main function.
 */
void vexcodeInit(void);
