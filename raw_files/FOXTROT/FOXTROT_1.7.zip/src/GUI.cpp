#include "GUI.h"
#include "vex.h"

using namespace vex;

void GUI::drawMainGUI() {
  
  /*-------------------Button 1-------------------*/
  Brain.Screen.drawRectangle(b1X, b1Y, bW, bH, 240);
  Brain.Screen.printAt(60, 60, "leftEasySideSixShot");

  /*-------------------Button 2-------------------*/
  Brain.Screen.drawRectangle(b2X, b2Y, bW, bH, 120);
  Brain.Screen.printAt(270, 60, "rightHardSideRoller");

  /*-------------------Button 3-------------------*/
  Brain.Screen.drawRectangle(b3X, b3Y, bW, bH, 30);
  Brain.Screen.printAt(60, 170, "Skills");

  /*-------------------Button 4-------------------*/
  Brain.Screen.drawRectangle(b4X, b4Y, bW, bH, 200);
  Brain.Screen.printAt(270, 170, "TESTING");

} 

void GUI::selectAuton() {
  //bool selectingAuton = true; not in use currently
  
  int x = Brain.Screen.xPosition();
  int y = Brain.Screen.yPosition();

  if ((x >= b4X && x <= b4EndX)&&(y >= b4Y && y <= b4EndY)&&confirm) {
    Brain.Screen.setCursor(1, 1);
    Brain.Screen.clearScreen();
    Brain.Screen.print("Setting up...");
    wait(1, sec);
    lTracking.setPosition(0, deg);
    IMU.calibrate();
    while(IMU.isCalibrating()){wait(10, msec);}
    Brain.Screen.clearScreen();
    Brain.Screen.setCursor(1, 1);
    Brain.Screen.print("ready");
  }

  if (!confirm) {
    if ((x >= b1X && x <= b1EndX)&&(y >= b1Y && y <= b1EndY)) {
      //Brain.Screen.clearScreen();
      Brain.Screen.setCursor(8, 1);
      Brain.Screen.print("leftEasySideSixShot");
      auto_num = 1;
    }else if ((x >= b2X && x <= b2EndX)&&(y >= b2Y && y <= b2EndY)) {
      //Brain.Screen.clearScreen();
      Brain.Screen.setCursor(8, 1);
      Brain.Screen.print("rightHardSideRoller");
      auto_num = 2;
    } else if ((x >= b3X && x <= b3EndX)&&(y >= b3Y && y <= b3EndY)) {
      //Brain.Screen.clearScreen();
      Brain.Screen.setCursor(8, 1);
      Brain.Screen.print("Skills");
      auto_num = 3;
    } else if ((x >= b4X && x <= b4EndX)&&(y >= b4Y && y <= b4EndY)) {
      //Brain.Screen.clearScreen();
      Brain.Screen.setCursor(8, 1);
      Brain.Screen.print("backUpDischarge");
      auto_num = 4;
    }
    Brain.Screen.clearScreen();
    Brain.Screen.drawRectangle(b4X, b4Y, bW, bH, 200);
    Brain.Screen.printAt(270, 170, "Confirm/Calibrate?");
    confirm = true;
    
  }
  
}

void GUI::runAUTO() {
  auto_routes routes;

  if (auto_num == 1) {
    routes.leftEasySideSixShot();
  } else if (auto_num == 2) {
    routes.rightHardSideRoller();
  } else if (auto_num == 3) {
    routes.skills_route();
  } else if (auto_num == 4) {
    routes.backUpDischarge();
  } else {
    Brain.Screen.print("WARNING: NO AUTON SELECTED");
  }
}




