#pragma once
#include "vex.h"
#include <iostream>
 
using namespace vex;
using namespace std;


struct chassis_Set {
 void reset();
 
 // CREATES A METHOD TO APPLY POWER TO CHASSIS
 void move(double rPower, double lPower);
 
 // CREATES A METHOD TO BRAKE THE CHASSIS MOTORS
 void brake();
 
 // CREATES A METHOD TO BOTH APPLY ZERO VOLTAGE AND BRAKE MOTORS
 void rest();
};