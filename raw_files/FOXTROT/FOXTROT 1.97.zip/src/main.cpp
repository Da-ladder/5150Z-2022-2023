/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       VEX                                                       */
/*    Created:      Thu Sep 26 2019                                           */
/*    Description:  Competition Template                                      */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// ---- END VEXCODE CONFIGURED DEVICES ----


#include "GUI.h"

#include "vex.h"

#include <thread>
#include <atomic>


using namespace vex;

competition Comp;

class subness : public rotation {
  public:
   void change_data(double ms) {
    datarate(10);
   }
};

void flywheel_pid() {
  flywheel_ctrl fly;
  auton_flywheel.store(true);
  fly.flywheel_tbh();
  std::terminate();
}

void selectAuton() {
  GUI auton_pick;
  auton_pick.selectAuton();
}


void odom_start() {
  auto_chassis full_auto;
  odom_enabled.store(true);
  full_auto.odom();
  std::terminate();
}


void test() {
  double sped = 0;
  double end_vol = 12.5;
  double cur_vol = 0;
  //double delay = 10;
  double increment = 0.5;
  while (end_vol != cur_vol) {
    flywheel.spin(fwd, cur_vol, voltageUnits::volt);
    wait(5, sec);
    sped = flywheel.velocity(velocityUnits::dps);
    std::cout << sped << std::endl;
    wait(1, sec);
    cur_vol += increment;
  }
  std::cout << "end" << std::endl;
}
/*---------------------------------------------------------------------------*/
/*                          Pre-Autonomous Functions                         */
/*                                                                           */
/*  You may want to perform some actions before the competition starts.      */
/*  Do them in the following function.  You must return from this function   */
/*  or the autonomous and usercontrol tasks will not be started.  This       */
/*  function is only called once after the V5 has been powered on and        */
/*  not every time that the robot is disabled.                               */
/*---------------------------------------------------------------------------*/

void pre_auton(void) {
  color_sense.setLightPower(100, percent); 
  color_sense.setLight(ledState::on);

  dianostics info;
  vexcodeInit(); // Initializing Robot Configuration. DO NOT REMOVE!  dfghjk
  info.temps();
  IMU.calibrate();
  lTracking.setPosition(0, deg);
  rtracking.setPosition(0, deg);
  wait(1, sec);
  thread fly_ctrl(flywheel_pid);
  fly_ctrl.detach();
  thread odom(odom_start);
  odom.detach();
  GUI gui;
  

  //gui.drawMainGUI();
  //test when time vb
}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              Autonomous Task                              */
/*                                                                           */
/*  This task is used to control your robot during the autonomous phase of   */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/


void autonomous(void) { //ADD IMAGES TO SD CARD SO WE CAN GET PICS ON THE BRAIN ddd
  //USE COMP SWITCH TO TEST dd
  //Brain.Screen.released(selectAuton);
  GUI auton_run;
  

  //if (Comp.isCompetitionSwitch()) {eeeddd
   auto_num = 4; //this overrides current gui selector! REMOVE DURING ddddd
  //dd
  //IMU.calibrate();
  //while(IMU.isCalibrating()){wait(10, msec);}  Controller1.Screen.print("ready");  cfghjk
  //wait(1, sec);vghj.

  if (auto_num == 4 || auto_num == 2 || auto_num == 3 || auto_num == 1) {
   //INITALIZE FLYWHEEL TBH
   //flywheel.spin(fwd, 10, voltageUnits::volt);
   //flywheel_velocity.store(17100); //14350
   //wait(100, sec);
   auton_run.runAUTO();
  } else { auton_run.runAUTO(); }
  //test(); f

  //wait(2, sec);
  //intake.spin(fwd, -12, voltageUnits::volt); sss

  

  
  // ..........................................................................
  // Insert autonomous user code here.
  // ..........................................................................
}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              User Control Task                            */
/*                                                                           */
/*  This task is used to control your robot during the user control phase of */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/

void usercontrol(void) {
  //color_sense.setLightPower(100, percent); 
  //color_sense.setLight(ledState::on);

  dianostics info;

   
  // User control code here, inside the loop dddnmdd

  while (true) {

    // If L1 is held down secondary control map
    if (Controller1.ButtonL1.pressing()) {
      //lTracking.setPosition(0, deg);
      //rtracking.setPosition(0, deg);
      
      SecondaryControlMap(); // ENDGAME RELEASE
      PrimaryControlMap();
    } else {
      PrimaryControlMap(); // everything else ghddssdd sd
      

      /*
      Controller1.Screen.setCursor(1, 1);
      Controller1.Screen.print(lTracking.position(rotationUnits::deg));
      Controller1.Screen.setCursor(2, 1);
      Controller1.Screen.print(rtracking.position(rotationUnits::deg));
      wait(0.5, sec);
      Controller1.Screen.clearScreen();
      */
      
      


     /* 
      if (Comp.isCompetitionSwitch()) {
       info.temps(); //tells temps of motors
       info.flywheel_info(); // prints on controller the flywheel speed and angle of the bot rrddwssw
      }
     */

    }
   wait(15, msec); // Sleep the task for a short amount of time to prevent wasted resources. sddssssddeess
  }
}

//
// Main will set up the competition functions and callbacks.
//
int main() {
  // Set up callbacks for autonomous and driver control periods.
  Comp.autonomous(autonomous);
  Comp.drivercontrol(usercontrol);
  Brain.Screen.released(selectAuton);
  // Run the pre-autonomous function.
  pre_auton();

  // Prevent main from exiting with an infinite loop.
  while (true) {
   Brain.Screen.released(selectAuton);
   wait(15, msec);
  }
}
