#include "vex.h"
#include "Auton.h"

using namespace vex;

chassis_Set movement;
auto_chassis attempt;// = new auto_chassis();
IMU_PID auton;

void auto_routes::leftEasySideSixShot() { //should probs document this tbh
  Brain.Timer.reset();

  flywheel_velocity.store(15800); //14700
  
  //Roller
  intake.spin(fwd, -12, voltageUnits::volt);
  movement.move(-3.8, -3.8);
  wait(0.2, sec);
  intake.spin(fwd, 0, voltageUnits::volt);

  //swearve towards 3 stack
  auton.test(9, 0, 12); //5
  intake.spin(fwd, -12, voltageUnits::volt);

  
  movement.move(1.3, 12); //27
  wait(0.3, sec);
  movement.move(1, 1);
  wait(0.13, sec);
  movement.move(0, 0);
  wait(0.2, sec);

  attempt.trig_cal(14.09, -4.24, true, 12);
  //turn to shoot
  auton.rep_turn(17, 2, 0.05, 1);
  //wait timer was here before
  intake.spin(fwd, 0, voltageUnits::volt);
  auton.rep_shot(15800, 15800, 1);
  
  flywheel_velocity.store(15930);
  
  intake.spin(fwd, -12, voltageUnits::volt);
  attempt.trig_cal(29.52, -27.10, false, 4);
  auton.rep_turn(32.66, 2, 0.05, 1);
  wait(0.3, sec);
  intake.spin(fwd, 0, voltageUnits::volt);
  auton.rep_shot(15930, 15930, 1);

  //get booma disks
  
  attempt.trig_cal(5.15, -35.17, true,12); //-43
  intake.spin(fwd, -12, voltageUnits::volt);
  auton.rep_turn(-12, 2, 0.05, 1);
  auton.test(35, -2, 5, 0.09);
  


  

  

  Controller1.Screen.clearScreen();
  Controller1.Screen.setCursor(1, 1);
  Controller1.Screen.print(Brain.timer(sec));
  Controller1.Screen.print(IMU.rotation(deg));
  
  
}


void auto_routes::skills_route() {
  Brain.Timer.reset();

  mag_lift.set(false); feeder.set(true);
  flywheel_velocity.store(12440);
  //skills auton = get 4 rollers, targeting 9 - 12 shots depending on time left

  //roller 1 -8.94
  movement.move(-3.5, -3.5);
  wait(0.2, sec);
  intake.spin(fwd, -12, voltageUnits::volt);
  wait(0.5, sec);
  intake.spin(fwd, 0, voltageUnits::volt);
  movement.move(5, 5);
  wait(0.1, sec);
  movement.move(0, 0);
  intake.spin(fwd, -12, voltageUnits::volt);
  wait(0.05, sec);
  attempt.trig_cal(10, 11.5, false, 12);
  wait(0.025, sec);
  auton.turn(-75, true, false, 4);
  wait(0.5, sec);
  intake.spin(fwd, 0, voltageUnits::volt);

  //roller 2
  movement.move(-3.5, -3.5);
  wait(0.4, sec);
  intake.spin(fwd, -12, voltageUnits::volt);
  wait(0.53, sec);
  movement.move(5, 5);
  wait(0.4, sec);
  //intake.spin(fwd, -12, voltageUnits::volt);
  movement.move(0, 0);
  
  //VOLLEY 1
  attempt.trig_cal(67.63, 20.86, false, 8);
  intake.spin(fwd, 0, voltageUnits::volt);
  auton.rep_turn(-19, 1, 0.05, 10);
  wait(0.05, sec);
  auton.rep_turn(0, 2, 0.05, 1); //-3.3 -2
  auton.rep_shot(12440, 12440, 12440);

  
  //VOLLEY 2
  mag_lift.set(true); feeder.set(false);
  flywheel_velocity.store(12890); //13140
  intake.spin(fwd, -12, voltageUnits::volt);
  attempt.trig_cal(50.67, 2.74, false, 7); //44.78, -0.59
  attempt.trig_cal(70.29, -21.58, false, 5.75); //65.72, -27.28
  auton.rep_turn(49, 2, 0.075, 1); //45
  wait(1.7, sec);
  
  auton.rep_shot(13340, 13340, 13340);
  
  
  flywheel_velocity.store(12980); //14080
  intake.spin(fwd, 0, voltageUnits::volt);
  
  //Volley 3
  mag_lift.set(false); feeder.set(true);
  attempt.trig_cal(93.69, -46.24, false, 10); //test 93.69, -46.24 -48.54
  wait(0.1, sec);
  intake.spin(fwd, -12, voltageUnits::volt);
  movement.move(2.5, 2.5);
  wait(2, sec);
  movement.move(0, 0);
  attempt.trig_cal(108.2, -31.37, false, 7.7); //106.59, -43.51 -28.8
  auton.rep_turn(93.84, 2, 0.05, 1); //84.27
  auton.rep_shot(13880, 13880, 13340); //NEW
  

  
  //INTAKE 3 LINE STACK
  attempt.trig_cal(98.5, -59.8, false, 5.6); //8.7
  movement.move(6.9, 6.9); //6.75 works barely
  wait(0.2, sec);
  movement.move(0, 0);
  intake.spin(fwd, -12, voltageUnits::volt);
  wait(0.1, sec);
  movement.move(2.1, 2.1);
  wait(2.4, sec);
  movement.move(0, 0);
  

  wait(0.08, sec);
  attempt.trig_cal(112.58, -82.4, true, 7); //-79.5
  intake.spin(fwd, 0, voltageUnits::volt);

  //roller 3
  intake.spin(fwd, 0, voltageUnits::volt);
  auton.rep_turn(-180, 1, 0.05, 4); //BRUTE FORCE METHOAD
  movement.move(-6, -6);
  wait(0.2, sec); //BRUTE FORCE = 0.2 sec
  movement.move(-3.5, -3.5);
  wait(0.1, sec); //slow = 0.3 sec
  intake.spin(fwd, -12, voltageUnits::volt);
  wait(0.45, sec); //.56
  movement.move(7, 7); //7 both
  wait(0.5, sec);
  intake.spin(fwd, 0, voltageUnits::volt);
  movement.move(0, 0);

  wait(0.1, sec);
  
  attempt.trig_cal(104.53, -94.8, true, 6);

  //roller 4
  auton.rep_turn(90, 1, 0.05, 4); //???
  flywheel_velocity.store(12550);
  movement.move(-3.5, -3.5);
  wait(0.2, sec);
  intake.spin(fwd, -12, voltageUnits::volt);
  wait(0.6, sec);
  intake.spin(fwd, 0, voltageUnits::volt);
  movement.move(9, 9);
  wait(0.45, sec);
  intake.spin(fwd, 0, voltageUnits::volt);
  movement.move(0, 0);

  //Volley 6
  attempt.trig_cal(53, -94.24,  false, 10);
  auton.rep_turn(-180, 2, 0.05, 1);
  auton.rep_shot(12950, 13450, 12450);
  intake.spin(fwd, -12, voltageUnits::volt);
  mag_lift.set(true); feeder.set(false);

  //INTAKE 3 UNSTACKED
  flywheel_velocity.store(11500);
  attempt.trig_cal(65.32, -72.96,  false, 10);

  //SHOOT 3 UNSTACKED
  attempt.trig_cal(44.58, -48.46,  false, 5.75);
  auton.rep_turn(230, 2, 0.05, 1); //126
  wait(1.1, sec);
  auton.rep_shot(12500, 13500, 13450);

  
  
  //Endgame
  attempt.trig_cal(99.75, -89.45, true, 10); //107.45, -83.07
  auton.turn(134.54, true, false, 3);
  t_junction.set(true); //ENDGAME ACTIVE
  


  Controller1.Screen.clearScreen();
  Controller1.Screen.setCursor(1, 1);
  Controller1.Screen.print(Brain.timer(sec));





}


void auto_routes::rightHardSideRoller() { //do a quick auton roller for the right side
  Brain.Timer.reset();
  //Set flywheel speed for first shot.
  

  
  flywheel_velocity.store(16050);

  intake.spin(fwd, -12, voltageUnits::volt);
  auton.test(18.2, 0, 10, 0);
  movement.move(0, 0);
  wait(0.3, sec);
  
  attempt.trig_cal(15.39, 0.28, true, 12);
  
  auton.rep_turn(28.3, 2, 0.05, 1);
  wait(0.3, sec);
  auton.rep_shot(16050, 16850, 1);
  flywheel_velocity.store(14500);

  //roller
  attempt.trig_cal(11.7, -10.52, true, 12);
  
  
  //
  movement.move(12, -12);
  wait(0.13, sec);
  movement.move(0, 0);
  //

  
  //auton.turn(41, false, false, 4);
  intake.spin(fwd, -12, voltageUnits::volt);
  movement.move(-4, -4);
  wait(0.32, sec);
  intake.spin(fwd, 0, voltageUnits::volt);
  movement.move(12, 12);
  wait(0.27, sec);
  movement.move(0, 0);
  
  intake.spin(fwd, -12, voltageUnits::volt);
  
  //intake 3 unstacked
  attempt.trig_cal(12.09, 39.89, false, 10); //12.09, 38.89
  auton.rep_turn(-0.72, 2, 0.05, 1);
  auton.rep_shot(14900, 15200, 1);
  
  
  
  
  //intake boomarang
  intake.spin(fwd, -12, voltageUnits::volt);
  auton.rep_turn(-155.00, 2, 0.05, 1);
  auton.test(45, -159.46, 12, 0);
  
  


  Controller1.Screen.clearScreen();
  Controller1.Screen.setCursor(1, 1);
  Controller1.Screen.print(Brain.timer(sec));
  

}


void auto_routes::backUpDischarge() { //back up discharge is test code as of dddssj
  
  Brain.Timer.reset();
  /*
  //Set flywheel speed for first shot.
  flywheel_velocity.store(13750);
  //Roller
  attempt.trig_cal(-12, 0, true, 9);
  auton.turn(-90, false, false, 4);
  movement.move(-3.5, -3.5);
  wait(0.18, sec);
  intake.spin(fwd, -12, voltageUnits::volt);
  wait(0.27, sec);
  intake.spin(fwd, 0, voltageUnits::volt);
  movement.move(5, 5);
  wait(0.2, sec);
  movement.move(0, 0);
  
  intake.spin(fwd, -12, voltageUnits::volt);

  attempt.trig_cal(-1.62, -12.97, false, 10); //-2.4, -17.43
  auton.rep_turn(-113.84, 2, 0.05, 1); //-113
  wait(1.1, sec); //1.4

  //SHOT
  intake.spin(fwd, 12, voltageUnits::volt); //11
  wait(0.18, sec);
  intake.spin(fwd, -10, voltageUnits::volt);
  flywheel_velocity.store(13900);
  wait(0.9, sec);
  intake.spin(fwd, 0, voltageUnits::volt);


  intake.spin(fwd, 12, voltageUnits::volt); //11
  wait(0.18, sec);
  intake.spin(fwd, -10, voltageUnits::volt);

  wait(0.2, sec); //THIS IS A ADDED DELAY
  flywheel_velocity.store(14200);
  wait(0.7, sec);
  intake.spin(fwd, 0, voltageUnits::volt);
  wait(0.2, sec); 
  

  intake.spin(fwd, 11, voltageUnits::volt);
  wait(0.3, sec);
  intake.spin(fwd, 0, voltageUnits::volt);
  //END SHOT

  
  //ROLLER
  intake.spin(fwd, 12, voltageUnits::volt);

  //UNLINK
  attempt.trig_cal(65.43, -87.74, false, 10); //91.43, -84.94
  auton.rep_turn(177, 2, 0.05, 5);

  movement.move(-3, -3);
  wait(0.5, sec);
  intake.spin(fwd, -12, voltageUnits::volt);
  wait(0.34, sec);
  intake.spin(fwd, 0, voltageUnits::volt);
  movement.move(5, 5);
  wait(0.15, sec);
  movement.move(0, 0);
  */
  
  


  flywheel_velocity.store(14350); //15850
  wait(5, sec);
  //auton.rep_shot(15400, 15600, 1); //15700, 16200
  //flywheel_velocity.store(0); 
  auton.rep_shot(15200, 14550, 1);
  flywheel_velocity.store(0);
  
  
  
  
  
  //movement.move(-2.5,2.5);
  /*
  flywheel_velocity.store(25000);
  wait(6, sec);
  auton.rep_shot(25000, 25000, 1);
  */
  
  /*
  flywheel_velocity.store(16450);
  mag_lift.set(true);
  booper.set(false);
  wait(4, sec);
  auton.rep_shot(1, 1, 1);
  */
  //booper.set(false);
  //wait(4, sec);
  //auton.rep_shot(3, 1, 1);
  //auton.turn(90, true, false, 0.2);
  //wait(0.05, sec);
  //auton.test(5, 0, 12);
  
  //auton.rep_turn(6, 2, 0.05, 1);
  
  //wait(2, sec);
  //auton.test(48, 12);
  //attempt.trig_cal(20, -20, false, 12);
  //attempt.trig_cal(0, 0, false);
  Controller1.Screen.clearScreen();
  Controller1.Screen.setCursor(1, 1);
  Controller1.Screen.print(Brain.timer(sec));
}



void dianostics::temps() {
  Brain.Screen.clearScreen();
  Controller1.Screen.clearScreen();
  Controller1.Screen.setCursor(1, 1);
  Controller1.Screen.print(IMU.rotation(degrees));
  
  Brain.Screen.setCursor(1,1);
  Brain.Screen.print(IMU.orientation(yaw, degrees));
  Brain.Screen.setCursor(2,1);
  Brain.Screen.print("left motor A TEMP: ");
  Brain.Screen.print(leftMotorA.temperature(temperatureUnits::celsius));
  Brain.Screen.setCursor(3,1);
  Brain.Screen.print("left motor B TEMP: ");
  Brain.Screen.print(leftMotorB.temperature(temperatureUnits::celsius));
  Brain.Screen.setCursor(4,1);
  Brain.Screen.print("right motor A TEMP: ");
  Brain.Screen.print(rightMotorA.temperature(temperatureUnits::celsius));
  Brain.Screen.setCursor(6,1);
  Brain.Screen.print("right motor B TEMP: ");
  Brain.Screen.print(rightMotorB.temperature(temperatureUnits::celsius));
  Brain.Screen.setCursor(5,1);
  Brain.Screen.print("Flywheel TEMP: ");
  Brain.Screen.print(flywheel.temperature(temperatureUnits::celsius));
  Brain.Screen.setCursor(6,1);
  Brain.Screen.print("Intake TEMP: ");
  Brain.Screen.print(intake.temperature(temperatureUnits::celsius));
  Brain.Screen.render();
}

void dianostics::power_speed() {
  Brain.Screen.clearScreen();
  Brain.Screen.setCursor(1,1);
  Brain.Screen.print("left motor A Voltage (watts): ");
  Brain.Screen.print(leftMotorA.voltage());
  Brain.Screen.setCursor(2,1);
  Brain.Screen.print("left motor B Voltage (watts): ");
  Brain.Screen.print(leftMotorB.voltage());
  Brain.Screen.setCursor(3,1);
  Brain.Screen.print("right motor A Voltage (watts): ");
  Brain.Screen.print(rightMotorA.voltage());
  Brain.Screen.setCursor(4,1);
  Brain.Screen.print("right motor B Voltage (watts): ");
  Brain.Screen.print(rightMotorB.voltage());
  Brain.Screen.setCursor(5,1);
  Brain.Screen.print("left motor A SPEED (RPM 600 CAP): ");
  Brain.Screen.print(leftMotorA.velocity(velocityUnits::rpm));
  Brain.Screen.setCursor(6,1);
  Brain.Screen.print("left motor B SPEED (RPM 600 CAP): ");
  Brain.Screen.print(leftMotorB.velocity(velocityUnits::rpm));
  Brain.Screen.setCursor(7,1);
  Brain.Screen.print("right motor A SPEED (RPM 600 CAP): ");
  Brain.Screen.print(rightMotorA.velocity(velocityUnits::rpm));
  Brain.Screen.setCursor(8,1);
  Brain.Screen.print("right motor B SPEED (RPM 600 CAP): ");
  Brain.Screen.print(rightMotorB.velocity(velocityUnits::rpm));
  Brain.Screen.render();
}

void dianostics::flywheel_info() {
  Controller1.Screen.clearScreen();
  Controller1.Screen.setCursor(2, 1);
  Controller1.Screen.print(IMU.rotation(deg));
}