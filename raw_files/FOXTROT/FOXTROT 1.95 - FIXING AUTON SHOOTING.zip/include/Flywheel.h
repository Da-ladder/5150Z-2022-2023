#pragma once
#include "vex.h"
#include <iostream>
#include <sstream>
#include <cmath>

using namespace vex;



struct flywheel_ctrl {
  competition comp;
  void flywheel_tbh ();

};
