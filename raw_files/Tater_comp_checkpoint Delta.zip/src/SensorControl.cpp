#include "vex.h"

using namespace vex;

double inchesToTicks(double inches) {
 double targetTicks;
 
 targetTicks = inches * (700/12.57);
 
 return targetTicks;
}

double ticksToInches(double ticks) {
 double targetinches;
 double wheelDiameter = 4;
 
 targetinches = (ticks / 360) * (wheelDiameter * M_PI); //Returns inches traveled by 4in diameter wheels
 
 return targetinches;
}