#include "vex.h"
#include <iostream>
 
using namespace vex;
using namespace std;


struct chassis_Set {
 
 void reset() {
   leftMotorA.resetRotation();
   leftMotorB.resetRotation();
   rightMotorA.resetRotation();
   rightMotorB.resetRotation();
 }
 
 // CREATES A METHOD TO APPLY POWER TO CHASSIS
 void move(double rPower, double lPower) {
   leftMotorA.spin(fwd, lPower, voltageUnits::volt);
   leftMotorB.spin(fwd, lPower, voltageUnits::volt);
   rightMotorA.spin(fwd, rPower, voltageUnits::volt);
   rightMotorB.spin(fwd, rPower, voltageUnits::volt);
 }
 void launch(double speed) {
   flywheel.spin(fwd, speed, voltageUnits::volt);
   flywheel2.spin(fwd, speed, voltageUnits::volt);
 }
 void stop_launch(){
   flywheel.setBrake(hold);
   flywheel2.setBrake(hold);
 }
 
 // CREATES A METHOD TO BRAKE THE CHASSIS MOTORS
 void brake() {
   leftMotorA.setBrake(hold);
   leftMotorB.setBrake(hold);
   rightMotorA.setBrake(hold);
   rightMotorB.setBrake(hold);
 }
 
 // CREATES A METHOD TO BOTH APPLY ZERO VOLTAGE AND BRAKE MOTORS
 void rest() {
   move(0, 0);
   brake();
 }
 
 void driveFor(double distance, double percent = 100) {
 
   // ALLOWS FOR CHASSIS CONTROL
 
   chassis.setDriveVelocity(percent, pct);
 
   chassis.driveFor(fwd, distance, inches);
 }
 
 void turnFor(double degs) {
 
   // ALLOWS FOR CONTROL OF LIFT or turning of robot. do some testing
 
   chassis.setTurnVelocity(5, pct);
 
   chassis.turnFor(degs, deg);
 }
};


struct PID {

 void Move(float setPoint, double maxVoltage = 12) { //FLAG May not travel the correct distance but PID correction is in progress
 
   // STARTS TIMER
   timer Timer;
 
   // CONSTRUCTS OBJECT
   chassis_Set PIDcontrol;
 
   // CHECKS THE ANGLE BEFORE MOVING TO CORRECT FOR
   // AFTERWARDS
   double enterAngle = IMU.rotation();

   double lEnterVal = (leftMotorA.rotation(rotationUnits::raw) +
                       leftMotorB.rotation(rotationUnits::raw)) /
                      2;
   double rEnterVal = (rightMotorA.rotation(rotationUnits::raw) +
                       rightMotorB.rotation(rotationUnits::raw)) /
                      2;
 
   // UPDATES TIME VARIABLE
   double prevTime = Timer.time();
 
   //****************************//
   //  INSTATNTIATION VARIABLES  //
   //****************************//
 
   double errorMargin = 1; // FLAG
   double intergralCap = 20;
   double acceleration = 0.07;
 
   double Kd = 0.1, Kp = 0.1, Ki = 0.1; //Change vars FLAG
 
   //********************//
   //  WHILE LOOP SETUP  //
   //********************//
 
   // SLEW VRAIBALES
   double volCap = 0, volCapMax = 12;
 
   // ERROR VARIABLES
   double error = 0, prevError = 0;
 
   // PID VARIABLES
   double integral = 0, derivative = 0;
 
   // OUTPUT VARIBALES
   double output = 0, lOutput = 0, rOutput = 0;
 
   // MISC VARIABLES
   double angleCorrection = 0, encoderAvg = 0, Dt = 0;
 
   int sign = 1;
 
   // USES THE CONVERSION FUNCTION TO COVERT
   // SETPOINT FROM INCHES TO ENCODER TICKS
   setPoint = inchesToTicks(setPoint);
 
   // CALCULATES ERROR USING ENCODER AVG
   // AS ZERO TO MAKE WHILE LOOP TRUE
   error = setPoint - (encoderAvg - encoderAvg);
 
   //**************//
   //  WHILE LOOP  //
   //**************//
 
   // RUNS THE WHILE LOOP WHITHIN A GIVEN
   // LIMIT
   while (fabs(error) > errorMargin) {
 
     //****************//
     //  ERROR UPDATE  //
     //****************//
 
     double lEncoderVal = leftMotorA.value() - lEnterVal, //used to be mid left motor. UNSURE OF IMPACTS. FLAG
            rEncoderVal = rightMotorA.value() - rEnterVal; //used to be mid right motor. UNSURE OF IMPACTS. FLAG
 
     // CALCULATES THE AVERAGE POS OF TRACKING WHEELS
     encoderAvg = (lEncoderVal + rEncoderVal / 2);
 
     // CALCULATES ERROR / UPDATES ERROR
     error = setPoint - encoderAvg;
 
     //*********************************//
     //  CALCULATIONS OF PID VARIABELS  //
     //*********************************//
 
     // CALCULATES THE DT USING THE TIME FUNCTION
     // THE START IS AT THE TOP OF METHOD
     // PREVTIME UPDATE IS AT BOTTOM OF METHOD
     Dt = (Timer.time() - prevTime) / 1000;
 
     // CALCULATES INTERGRAL USING ERROR, DT, AND INTEGRAL
     // ADDS INTERGRAL EVERYTIME SO INCREASES
     // exponentially
     integral += error * Dt;
 
     // CACLULATES DERIVATIVE USING ERROR
     derivative = (error - prevError) / Dt;
 
     // UPDATES ERROR, TO PREVERROR
     prevError = error;
 
     // PERVENTS ERROR FROM GETTING TOO LARGER
     // BEFORE CLOSE ENOUGH TO TARGET
     if (error > intergralCap) {
       integral = 0;
     }
 
     // CALCULATING OUTPUT USING CONSTANTS,
     // AND VARIBALES
     output = error * Kp + integral * Ki + derivative * Kd;
 
     // FIND IF OUTPUT IS POS OR NEG
     // TO KEEP THE OUTPUT THE SAME
     // THROUGH THE NEXT OPERATIONS
     sign = fabs(output) / output;
 
     // SLEW RATE
     if (fabs(output) > volCapMax) {
       // PREVENTS THE VOLATGE FROM
       // GOING PAST 12 MAX
       output = volCapMax * sign;
     }
 
     // ADDS ACCELERATION EVERYTIME
     // OVER EVERY RUN
     volCap += acceleration * sign;
 
     // IF THE SLEW SURPASSES 12
     // SET VOLTAGE TO 12
     if (fabs(volCap) > fabs(volCapMax)) {
       volCap = volCapMax * sign;
     }
 
     if (fabs(output) > fabs(volCap)) {
       output = volCap;
     }
 
     //**************************//
     //  OUPUT/ANGLE CORRECTION  //
     //**************************//
 
     if (fabs(angleCorrection) > enterAngle) {
       // UPDATES MACHINE STATE TO BE DESIRABLE
       lOutput = angleCorrection + output;
       rOutput = angleCorrection - output;
 
       // CHECKS FOR VOLTAGE GREATER THAN 12
       if (fabs(lOutput) > volCapMax) {
         lOutput = volCap;
       }
 
       // CHECKS FOR VOLTAGE GREATER THAN 12
       if (fabs(rOutput) > volCapMax) {
         rOutput = volCapMax;
       }
 
       PIDcontrol.move(rOutput, lOutput);
     }
 
     // IF NO CORRECTION NEEDED SET TO NORMAL
     // OUTPUT
     else {
       PIDcontrol.move(output, output);
     }
 
     std::cout << output << std::endl;
 
     // CHECKS FOR THE DIFFRNCE IN ANGLE SINCE MOVEMENT
     // UPDATES THE VARIABLE
     angleCorrection = enterAngle - IMU.rotation();
 
     // UPDATES THE CLOCK
     prevTime = Timer.time();
 
     // ALLOWS FOR VARIABLES TO ITERATE
     wait(15, msec);
   }
   // PREVENTS THE MOTORS FROM SLIDING
   // AFTER RESTING, OR MOVING
   PIDcontrol.brake();
 
   // DESTRUCTS OBJECT
   PIDcontrol.~chassis_Set();
 }
};
