#include "vex.h"
 
using namespace vex;
 
struct Odometery { //Odometry can not be remade without tracking wheels in place.
 
 double odom_Start(bool isAuton) {
 
   // PHYSICAL CONSTANTS
   double Rl = 0, Rs = 0;
 
   // TRACKING VARIABLES
   double x = 0, y = 0, theta = 0;
 
   // DELTA VARIBALES
   double deltaX = 0, deltaY = 0, backX = 0, backY = 0;
 
   // UNKOWNS
   double alpha = 0, hyp = 0, backHyp = 0;
 
   while (isAuton == true) {
 
     int lEnterVal = lTracking.position(deg);
 
     double lEncoderVal = ticksToInches(lTracking.position(deg) - lEnterVal);
     double sEncoderVal = ticksToInches(sTracking.position(deg) - lEnterVal);
 
     alpha = IMU.angle(); // ALPHA is the heading of the robot
 
     hyp = 2 * (lEncoderVal / alpha + Rl * lEncoderVal) * sin(alpha / 2);
     backHyp = 2 * (sEncoderVal / alpha + Rs * sEncoderVal) * sin(alpha / 2);
 
     theta = alpha / 2;
 
     deltaX = hyp * cos(theta + alpha / 2); //change of x cord
     deltaY = hyp * sin(theta + alpha / 2); //change of y cord
 
     backX = backHyp * sin(theta + alpha / 2);
     backY = backHyp * cos(theta + alpha / 2);
 
     theta += alpha;
     x += deltaX + backX;
     y += deltaY + backY;
 
     Brain.Screen.clearScreen();
 
     Brain.Screen.print("X: ");
     Brain.Screen.print(x);
     Brain.Screen.print("Y: ");
     Brain.Screen.print(y);
   }
   return 0;
 }
};
