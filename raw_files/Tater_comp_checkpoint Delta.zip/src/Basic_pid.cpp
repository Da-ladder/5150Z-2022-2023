#include "objects.cpp"
#include "vex.h"

using namespace vex;

 chassis_Set PIDcontrol; //calls the chassis set structure pid control
 
 void basic(double setPoint) { //setPoint is the distance you want to travel in inches //THIS FUNCTION DOES NOT WORK AS INTENTED
   timer Timer;
   double error = 6;
   double integral = 0;
   double derivative = 0;
   double integralBound = 20;
   double prevTime = 0, prevError = 0;
   double kp = 1.19, ki = .01, kd = .5; //Tinker with settings
   double errorMargin = 1;
   double output = 0;
   // enterVal takes the average postion of all motors in degress
   double enterVal = ((leftMotorA.position(deg) + leftMotorB.position(deg) +
                       rightMotorA.position(deg)) +
                      (rightMotorB.position(deg))) /
                     4;
 
   setPoint = inchesToTicks(setPoint);
 
   while (fabs(error) > errorMargin) { //Takes the absolute value of error and compares it to the error margin
 
     double sensorVal = (((leftMotorA.position(deg) + leftMotorB.position(deg) +
                           rightMotorA.position(deg)) +
                          (rightMotorB.position(deg))) /
                         4) -
                        enterVal;
 
     std::cout << "Sensor Value: " << sensorVal << std::endl; //STD is standard workspace
 
     error = setPoint - sensorVal;
 
     integral += error;
 
     if (error > integralBound || error == 0) {
       integral = 0;
     }
  
     // derivative = (error - prevError) / Timer - prevTime;
 
     derivative = error - prevError;
 
     output = error * kp + integral * ki + derivative * kd;
 
     int sign = fabs(output) / output;
 
     if (fabs(output) > 12) {
       output = 12 * sign;
     }
 
     std::cout << "Output :" << output << std::endl;
     std::cout << "Error :" << error << std::endl;
 
     PIDcontrol.move(output, output);
 
     prevError = error;
     prevTime = Timer;
 
     wait(15, msec);
   }
   PIDcontrol.rest();
 }
 
 void calculate(double target, double maxVoltage = 12) {
 
   timer Timer;
 
   // UPDATE VALUES
   // sensorReset();
 
   // MACHINE STATE WHEN ENTERING FUNCTION, MACHINE STATE AFTER
   double enterAngle = IMU.rotation();
 
   // CONVERSION FROM INCHES TO ENCODER TICKS
   target = ticksToInches(target);
 
   double output = 0, Dt = 0, encoderAvrg = 0;
   double prevError = 0, prevTime = Timer.time();
 
   // SLEW COMPONENTS
   double volCapMax = 12, volCap = 0;
 
   // SLEW TUNABLE
   double acceleration = .07;
 
   // PID COMPONENTS
   double error = 0, integral = 0, derivetive = 0;
 
   // CONSTATNTS
   double Kp = .11, Ki = 0.009, Kd = .007;
 
   // BOUNDS
   double errorMargin = 5, integralBound = 20;
 
   // CORECTION VARIABLES
   double targetAngle = 0, correctionOutput = 0;
 
   int sign = 1;
   // CALCULATES ERROR FOR FUNCTION TO RUN
   error = target - encoderAvrg;
 
   while (fabs(error) > errorMargin) {
 
     // AVERAGE BETWEEN ENCODER VALUES
     encoderAvrg = (leftMotorA.rotation(rotationUnits::raw) +
                    leftMotorB.rotation(rotationUnits::raw) +
                    rightMotorA.rotation(rotationUnits::raw)) +
                   (rightMotorB.rotation(rotationUnits::raw)) /
                       4;
 
     // FINDS THE DIFFRENCE BETWEEN THE TARGET AND ROBOT
     error = target - encoderAvrg;
 
     // CALCULATES DELTA TIME IN MSEC
     Dt = (Timer.time() - prevTime) / 1000;
 
     // FINDS  INTEGRAL WITH CONSTANT MULTIPLIER, AND ERROR
     integral += error * Dt;
 
     // FINDS DRVITIVE USING ERROR, AND PREVIOUS
     // DIVIDES BY TIME
     derivetive = (error - prevError) / Dt;
 
     // UPDATES THE PREVIOUS ERROR
     prevError = error;
 
     if (error > integralBound) {
       integral = 0;
     }
 
     // CALCULATES THE VOLTS TO BE SENT TO THE MOTORS
     output = error * Kp + integral * Ki + derivetive * Kd;
 
     // FINDS IF POS OR NEG
     sign = fabs(output) / output;

     if (fabs(output) > maxVoltage) {
       output = maxVoltage * sign;
     }
 
     // Slew rate
     if (fabs(output) > volCapMax)
       output = volCapMax * sign;
 
     volCap += acceleration * sign;
     if (fabs(volCap) > fabs(volCapMax)) {
       volCap = volCapMax * sign;
     }
 
     if (fabs(output) > fabs(volCap)) {
       output = volCap;
     }
 
     // DIFFRENCE IN MACHINE STATE
     correctionOutput = targetAngle - (enterAngle - IMU.rotation());
 
     // CHECKS MACHINE STATE
     if (fabs(enterAngle - IMU.rotation()) > targetAngle) {
 
       // UPDATES MACHINE STATE TO BE DESIRABLE
       PIDcontrol.move(output + correctionOutput, output - correctionOutput);
     }
 
     // IF MACHINE STATE DESIRABLE CONTINUE PID
     else {
       PIDcontrol.move(output, output);
     }
 
     // DEBUGGING
     std::cout << "power: " << output << std::endl;
     std::cout << "error: " << error << std::endl;
 
     // UPDATES PREVIOUS TIME
     prevTime = Timer.time();
 
     // ALLOWS FOR UDATES TO VALUES
     wait(15, msec);
   }
 
   // STOPS THE ROBOT PREVENTS FURTHER MOVEMENT
   PIDcontrol.rest();
 }