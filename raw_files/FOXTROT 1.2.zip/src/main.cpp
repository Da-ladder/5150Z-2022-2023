/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       VEX                                                       */
/*    Created:      Thu Sep 26 2019                                           */
/*    Description:  Competition Template                                      */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// ---- END VEXCODE CONFIGURED DEVICES ----


#include "GUI.cpp"

#include "vex.h"
#include "Vision_cal.h"
#include <iostream>
#include <sstream>
#include <thread>
#include <atomic>


using namespace vex;

vex::mutex m;

// A global instance of competition
competition Competition;

// define your global instances of motors and other devices here dssddxxwwsg


void flywheel_pid() {
  if (auton_flywheel) {
   chassis_Set flywheel;
   double current_velocity = flywheel_sped.velocity(velocityUnits::dps);
   double error;
   double kp = 0.000026; //0.000025
   double tbh_approx = 6; //9 for 15k tune and tinker 9.1
   double tbh_at_zero = 8; //tune as well 9.3
   double tbh = 0;
   double prev_error = 0;
   bool first_cross = true;

    while (auton_flywheel) { // global var
     current_velocity = flywheel_sped.velocity(velocityUnits::dps);
     error = flywheel_velocity.load() - current_velocity; //flywheel veo is protected in case of race conditions
   
     Brain.Screen.setCursor(1, 1);
     Brain.Screen.clearScreen();


     tbh = tbh + (error * kp); 
     
     if (tbh > 12) { //SET MAX VOLTAGE TO 12 AND LOWEST TO 0
       tbh = 12;
      } else if (tbh < 0) {
       tbh = 0;
      }


      if (signbit(error) != signbit(prev_error)) { // ZERO CROSSING CHECK s
       if (first_cross) {
         tbh = tbh_approx; // FIRST TIME SET TO APPROX VALUES
         first_cross = false;
        } else {
         tbh = 0.5 * (tbh + tbh_at_zero); // TAKE BACK HALF ALGO
         tbh_at_zero = tbh;
        }
      }

     /*
     std::cout << "error :" << error << "NEW BATCH" << std::endl; //endl starts new line COUT displays to monitor/TERMINAL
     std::cout << "rot :" << current_velocity << std::endl; // REMOVE WHEN IN COMP MODE
     std::cout << "tbh_at_zero :" << tbh_at_zero << std::endl; //DISPLAY STATS TO TERMINAL THROUGH CONTROLLER WIRE EVERY 7 MSEC
     std::cout << "sens_avg :" << kp << std::endl;
     */

     flywheel.fly_vol(tbh);
     prev_error = error;

     wait(1, msec);
    }
   flywheel.fly_vol(0);
  }
  this_thread::sleep_for(100);
}



void selectAuton() {
  GUI auton_pick;

  auton_pick.selectAuton();

}



/*---------------------------------------------------------------------------*/
/*                          Pre-Autonomous Functions                         */
/*                                                                           */
/*  You may want to perform some actions before the competition starts.      */
/*  Do them in the following function.  You must return from this function   */
/*  or the autonomous and usercontrol tasks will not be started.  This       */
/*  function is only called once after the V5 has been powered on and        */
/*  not every time that the robot is disabled.                               */
/*---------------------------------------------------------------------------*/

void pre_auton(void) {
  vexcodeInit(); // Initializing Robot Configuration. DO NOT REMOVE!
  lTracking.setPosition(0, deg);
  IMU.calibrate();
  while(IMU.isCalibrating()){wait(10, msec);}  //Controller1.Screen.print("ready");

  //atomic testing
  std::atomic<double> task1_variable(0);
  task1_variable.store(2);
  Controller1.Screen.print(task1_variable.load());
  //test when time allows
}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              Autonomous Task                              */
/*                                                                           */
/*  This task is used to control your robot during the autonomous phase of   */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/


void autonomous(void) { //ADD IMAGES TO SD CARD SO WE CAN GET PICS ON THE BRAIN ss
  //USE COMP SWITCH TO TEST AUTON
  //Brain.Screen.released(selectAuton); shouldnt have to uncomment but just in case
  GUI auton_run;
  auto_num = 3; //this overrides current gui selector! REMOVE DURING COMP

  if (auto_num == 1 || auto_num == 2) {
   //INITALIZE FLYWHEEL TBH
   auton_flywheel = true;
   flywheel_velocity.store(14500); //14350 PLZ tune/tinker 14500m  14700 e 14200 xcvbncvbn
   vex::thread thread1(flywheel_pid);
   //DETACH FLYWHEEL TBH TO ITS OWN THREAD
   thread1.detach();
  }

  auton_run.runAUTO();

  if (auto_num == 1 || auto_num == 2) { thread::interruptAll(); } //STOPS ALL RUNNING THREADS

  // ..........................................................................
  // Insert autonomous user code here.
  // ..........................................................................
}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              User Control Task                            */
/*                                                                           */
/*  This task is used to control your robot during the user control phase of */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/

void usercontrol(void) {
  auton_flywheel = false;
  // dianostics info;
  
  // User control code here, inside the loop

  while (true) {
    Brain.Screen.released(selectAuton);
    // If L1 is held down secondary control map
    if (Controller1.ButtonL1.pressing()) {
      SecondaryControlMap(); // ENDGAME RELEASE
    } else {
      PrimaryControlMap(); // everything else
      
      /* //BELOW IS DIANOSTIC CODE ENABLE WHEN NECESSARY
      info.temps(); // prints on brain the temp sense info
      info.flywheel_info(); // prints on controller the flywheel speed and angle of the bot
      */
    }
   wait(15, msec); // Sleep the task for a short amount of time to prevent wasted resources.
  }
}

//
// Main will set up the competition functions and callbacks.
//
int main() {
  // Set up callbacks for autonomous and driver control periods.
  Competition.autonomous(autonomous);
  Competition.drivercontrol(usercontrol);
  Brain.Screen.released(selectAuton);

  // Run the pre-autonomous function.
  pre_auton();

  // Prevent main from exiting with an infinite loop.
  while (true) {
   wait(20, msec);
  }
}
