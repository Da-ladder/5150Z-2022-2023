#include "vex.h"
#include "objects.cpp"
#include <math.h>
#include <cmath>
 
using namespace vex;

//Function directly below is temp

struct IMU_PID {
  

  void roller_spin() {
   chassis_Set movement;
   double timeout = 0;
   double vol = -5;
   double kp = 1.1;

    movement.move(2, 2);
    while (color_sense.hue() < 100) {
     vol = vol * kp;
     intake.spin(fwd, vol, voltageUnits::volt);
     timeout += 1;
     if (timeout == 95) { break; } // Break breaks out of the while loop i.e timeout function
     wait(45, msec); // No point in setting lower refresh rate is 20ms rn
    }
    intake.spin(fwd, 0, voltageUnits::volt);
    movement.move(0,0);
  }

  void rep_shot(double disks, double start_delay, double delay) {
    wait(start_delay, sec);

    double current_disks = 0;

    while (current_disks != disks){
     hopper_feed.set(true);
     wait(0.05, sec); //0.05 before
     hopper_feed.set(false);
     current_disks += 1;
     wait(delay, sec);
   }
   
  }

  void rep_turn(double degree, double target_reps, double delay, bool right_turn) { //rebiuld may not require this function
   IMU_PID auton;
   double current_rep = 0;
   while (current_rep != target_reps){
     auton.turn(degree, true, false, 0.5);
     current_rep += 1;
     wait(delay, sec);
   }

  }

  void test(double setpoint, double max_voltage) { // The distance to be traveled by the robot is given in inches

   chassis_Set PIDcontrol; //Renames the entire structure of chassis_Set as PIDcontrol

   PIDcontrol.reset(); //resets the internal encoders inside of the motors of the chassis

   lTracking.setPosition(0, deg); //RESETS the tracking wheel
   // KNOWN WORKING VALUES: kP = 0.01, kI = 0.000025, kD = 0.0009 // kD needs to be fine tuned for more presision
 
   // Variables for correcting the distance traveled by the robot //START OF FOWARDS PID
   double kP = 0.015, kI = 0.00015, kD = 0.00; //slow rn /0.0008
   double rot_kp = 2; //1.25
   double stable_heading = IMU.rotation(rotationUnits::deg);
   double rot_sense = IMU.rotation(rotationUnits::deg);
   double rot_error = stable_heading - rot_sense;
   double sens_avg = lTracking.position(rotationUnits::deg);
   double integral = 0;
   double derivative = 0;
   double prevError = 0;
   double out2 = 0;
   double right_pwr = 0;
   double left_pwr = 0;
   double correction_pwr = 0;
   double errorMargin = 20; // Gives robot some space for errors and uncontrollable precision 3 degs is around  
   setpoint = inchesToTicks(setpoint);
   double dis_error = setpoint - sens_avg; // Sets the error first so the while loop can be triggered
   double correct_num = 0;
   bool first_cross = true;

   while ((fabs(dis_error) > errorMargin) && (correct_num < 5)) {
     double sens_avg = lTracking.position(rotationUnits::deg);
     dis_error = setpoint - sens_avg;
     integral += dis_error;
     
     if ((dis_error == 0 || (signbit(setpoint) != signbit(dis_error))) && first_cross) { integral = 0; first_cross = false;} 
     else if (fabs(dis_error) > 360) { integral = 0; } 

     derivative = dis_error - prevError;
     prevError = dis_error;
     
     out2 = ((dis_error * kP) + (integral * kI) + (derivative * kD));



     if (out2 > max_voltage)       { out2 = max_voltage; } 
     else if (out2 < -max_voltage) { out2 = -max_voltage; }
     //END OF FOWARDS PID. START OF CORRECTION PID
     
     rot_sense = IMU.rotation(rotationUnits::deg);
     rot_error = stable_heading - rot_sense;

     derivative = rot_error - prevError;
     prevError = rot_error;
     correction_pwr = (rot_error * rot_kp);


     //APPLY POWER TO CHASSISS
     right_pwr = out2 - correction_pwr;
     left_pwr = out2 + correction_pwr;

     if (right_pwr > max_voltage)       { right_pwr = max_voltage; } 
     else if (right_pwr < -max_voltage) { right_pwr = -max_voltage; }

     if (left_pwr > max_voltage)       { left_pwr = max_voltage; } 
     else if (left_pwr < -max_voltage) { left_pwr = -max_voltage; }

     PIDcontrol.move(right_pwr, left_pwr); //corrections are IN PLACE
     //PIDcontrol.move(out2, out2);

     if (fabs(dis_error) < errorMargin) {
       correct_num += 1;
     }


     wait(10, msec);
     Brain.Screen.clearScreen();
     
     std::cout << "dis_error :" << dis_error << "NEW BATCH" << std::endl; //endl starts new line COUT displays to monitor/TERMINAL
     std::cout << "derivative :" << derivative << std::endl; // REMOVE WHEN IN COMP MODE
     std::cout << "integral :" << integral << std::endl; //DISPLAY STATS TO TERMINAL THROUGH CONTROLLER WIRE EVERY 7 MSEC
     std::cout << "sens_avg :" << sens_avg << std::endl;
     std::cout << "output :" << out2 << std::endl;
     
    }
    PIDcontrol.rest(); // Sets the motors to brake
    /*
    wait(1, sec);
    Controller1.Screen.clearScreen();
    Controller1.Screen.print(setpoint);
    Controller1.Screen.print(lTracking.position(rotationUnits::deg));
    */
  }


  
  void turn(double rotation, bool right_turn, bool lock_left, double errormarg) { // right turn bool is not used

   chassis_Set PIDcontrol; //PREV Values = kP = 1.8, kI = 0.0065, kD = 6.5 kp may need to be set higher for more presion add ki

   //double brain_line = 0; kP = 0.3, kI = 0.015, kD = 0.1;

   double kP = 0.3, kI = 0.013, kD = 0.1; // Variables which tune the output of the robot VALUE TOO HIGH WILL CAUSE UNCONTROLLED MOVEMENT TOO LOW NO MOVEMENT  FLAG //HOW DOES USING ONLY kP work???
   double sens_avg = IMU.rotation(rotationUnits::deg); // Average encoder values of the chassis motors
   double integral = 0;
   double derivative = 0;
   double prevError = 0;
   double output = 0;
   double errorMargin = errormarg; // Gives robot some space for errors and uncontrollable precision  // was 5 before FLAG
   double rot_error = rotation - sens_avg;
   bool control = false;
   bool first_cross = true;

   while (fabs(rot_error) > errorMargin) { 
     sens_avg = IMU.rotation(rotationUnits::deg);
     rot_error = rotation - sens_avg;
     integral += rot_error;

     if (rot_error == 0 || (rot_error > rotation && first_cross)) { integral = 0; control = true; first_cross = false; } 
     else if (abs(rot_error) > 15) { integral = 0; }

     derivative = rot_error - prevError;
     prevError = rot_error;
     
     output = ((rot_error * kP) + (integral * kI) + (derivative * kD));

     if (output > 9)       { output = 9; } 
     else if (output < -9) { output = -9; }

     if (lock_left) {
       leftMotorA.setBrake(hold);
       leftMotorB.setBrake(hold);
       PIDcontrol.move(-output, 0);
     } else {
       PIDcontrol.move(-output, output);
     }

     
     
     
     std::cout << "rot_error :" << rot_error << "NEW BATCH" << std::endl; //endl starts new line COUT displays to monitor/TERMINAL
     std::cout << "derivative :" << derivative << std::endl; // REMOVE WHEN IN COMP MODE
     std::cout << "integral :" << integral << std::endl; //DISPLAY STATS TO TERMINAL THROUGH CONTROLLER WIRE EVERY 7 MSEC
     std::cout << "sens_avg :" << sens_avg << std::endl;
     std::cout << "output:" << output << std::endl;

     wait(5, msec);
   }
   PIDcontrol.move(0, 0);
   PIDcontrol.brake();
   Controller1.Screen.print("done");
   Controller1.Screen.print(IMU.rotation(rotationUnits::deg));
  }

};