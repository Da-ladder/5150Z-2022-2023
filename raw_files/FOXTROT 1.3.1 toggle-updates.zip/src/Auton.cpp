#include "vex.h"
#include "Pid.cpp"
#include "Tbh.cpp"

using namespace vex;


struct auto_routes {
  chassis_Set movement;
  IMU_PID auton;

  void leftEasySideSixShot() { //should probs document this tbh

   //SPIN ROLLER (NORMAL SET UP)
   movement.move(6,6);
   intake.spin(fwd, -12, voltageUnits::volt);
   wait(0.25, sec);
   intake.spin(fwd, 0, voltageUnits::volt);
   movement.move(-5,-5);
   wait(0.25, sec);
   movement.move(0,0);
   //END OF SPIN ROLLER

   auton.test(-5, 8);
   auton.rep_turn(45, 2, 0.05, true);
   auton.test(-24.5, 12); //24.3
   movement.move(-4, -4);
   wait(0.03, sec);
   movement.move(0, 0);
   auton.test(4, 12);
   //intake.spin(fwd, 0, voltageUnits::volt);


   //turn to target --> edit during comp
   wait(0.5, sec);
   auton.turn(148.5, true, true, 0.5);
   auton.test(10, 11);

   auton.turn(148.5, true, true, 0.5);
   wait(0.05, sec);
   auton.turn(148.5, true, true, 0.2);

   auton.rep_shot(3, 0.0, 1.0);

   //auton_flywheel.store(false);
  }


  void skills_route() {
    //skills auton = get 4 rollers, targeting 9 - 12 shots depending on time left 
    
    color_sense.integrationTime(50); //normal opt sense sends back info every 100 ms so oc??? also less accurate with faster time. oc for better accuracy. more oc = unstable
    color_sense.setLightPower(100);
    color_sense.setLight(vex::ledState::on);

    // ROLLER 1
    
    movement.move(4,4);
    intake.spin(fwd, -8, voltageUnits::volt);
    wait(0.4, sec);
    intake.spin(fwd, 0, voltageUnits::volt);
    movement.move(0,0);
    
    auton.roller_spin();
    // End of roller 1

    // Back up and intake a disk before getting roller
    auton.test(-16, 11);
    intake.spin(fwd, 12, voltageUnits::volt);
    auton.rep_turn(-90, 3, 0.05, true);
    intake.spin(fwd, -12, voltageUnits::volt);
    auton.test(-9, 12);
    wait(0.2, sec);
    // Turns towards roller and move towards it
    auton.rep_turn(90, 3, 0.05, true);
    auton.test(21, 12); //should set to be as close to the roller as possible

    // ROLLER 2
    movement.move(4,4);
    intake.spin(fwd, -8, voltageUnits::volt);
    wait(0.4, sec);
    intake.spin(fwd, 0, voltageUnits::volt);
    movement.move(0,0);
    auton.roller_spin();
    // End of roller 2

    /*
    
    // Moves away from the roller and shoots in the high goal
    auton.test(-7, 12); // Might need adjustment 
    auton.rep_turn(180, 2, 0.05, true);
    movement.fly_vol(8.2);
    wait(0.1, sec);
    auton.test(55, 12); //57
    intake.spin(fwd, -12, voltageUnits::volt);
    auton.rep_turn(179, 2, 0.05, true);
    movement.fly_vol(8.5);
    auton.rep_shot(3, 0, 1); // 3 shots in 0.7 sec increments
    auton.rep_turn(178.5, 2, 0.05, true);

    //UNTESTED CODE BELOW (grab 3 unstacked disk and shoot from boomarang corner)
    auton.test(-33.1, 9);
    auton.turn(44.5, true, false, 0.5); //42.5
    wait(0.05, sec);
    auton.turn(44.5, true, false, 0.2);
    wait(0.05, sec);
    auton.turn(44.5, true, false, 0.2);
    wait(0.05, sec);
    auton.turn(44.5, true, false, 0.2);
    movement.fly_vol(8.4);
    auton.test(-62, 4.5); //7.4
    auton.rep_turn(138, 2, 0.05, true);
    movement.fly_vol(8.6);
    auton.rep_shot(3, 0, 1); // 3 shots 1 in sec increments
    // End of 3 shot from boomarang corner

    // Turns to grab 3 stack disk
    
    
    intake.spin(fwd, -6, voltageUnits::volt);
    movement.fly_vol(8.36);
    auton.rep_turn(50, 2, 0.05, true); //53
    auton.test(-29.4, 12);
    auton.test(4, 12);
    intake.spin(fwd, -12, voltageUnits::volt);
    auton.test(-12, 6);
    auton.rep_turn(100, 2, 0.05, true);
    auton.test(16, 12);
    auton.rep_turn(103, 2, 0.05, true);
    movement.fly_vol(8.5);
    auton.rep_shot(3, 0, 1); // 3 shots 1 in sec increments
    
    // End of 3 shot of stacked disks
    
    
    // Turns and moves towards the third roller 
    auton.rep_turn(80, 2, 0.05, true);
    auton.test(-60, 12);
    auton.test(6, 12);
    auton.rep_turn(180, 2, 0.05, true);
    auton.test(12, 12); //should be as close to the roller as possible

    // ROLLER 3
    movement.move(5,5);
    intake.spin(fwd, -8, voltageUnits::volt);
    wait(0.5, sec);
    intake.spin(fwd, 0, voltageUnits::volt);
    movement.move(0,0);
    auton.roller_spin();
    // END OF ROLLER 3

    auton.test(-9, 12);
    auton.rep_turn(-90, 2, 0.05, true);
    auton.test(17, 12); //probs go fowards more

    // ROLLER 4
    movement.move(5,5);
    intake.spin(fwd, -8, voltageUnits::volt);
    wait(0.5, sec);
    intake.spin(fwd, 0, voltageUnits::volt);
    movement.move(0,0);
    auton.roller_spin();
    // END OF ROLLER 4
    */
    auton.test(-13, 12); //probs go fowards more as this releases endgame
    auton.rep_turn(45, 3, 0.05, true);
    
    t_junction.set(true); //release endgame
    

  }


  void rightHardSideRoller() { //do a quick auton roller for the right side
   auton.test(14, 12);
   auton.rep_turn(90, 3, 0.05, true);

   intake.spin(fwd, -12, voltageUnits::volt);
   movement.move(6, 6);
   wait(0.45,sec);
   movement.move(0, 0);
   intake.spin(fwd, 0, voltageUnits::volt);

   auton.test(-3, 12);
   /*
   auton.rep_turn(42, 3, 0.05, true);
   intake.spin(fwd, -12, voltageUnits::volt);
   auton.test(-28, 12);
   auton.rep_turn(222, 3, 0.05, true);
   auton.test(45, 12);



   auton.turn(-45, true, true, 0.5);
   //auton.test(10, 11);

   auton.turn(-45, true, true, 0.5);
   wait(0.05, sec);
   auton.turn(-45, true, true, 0.2);

   auton.rep_shot(3, 0.0, 1.0);
   */



  }


  void backUpDischarge() { //back up discharge is test code as of now
   //auton.rep_turn(20, 2, 0.05, true);
   auton.test(-50, 12); //120
   //wait(0.5, sec);
   //Controller1.Screen.print(IMU.orientation(yaw, degrees));
   //auton.turn(40, true);
   //auton.turn(90, true);
   //intake.spin(fwd, -12, voltageUnits::volt);
   //auton.rep_shot(3, 5, 1.5); 
  }


};



struct dianostics {
  void temps() {
    Brain.Screen.clearScreen();
    Controller1.Screen.clearScreen();
    Controller1.Screen.setCursor(1, 1);
    Controller1.Screen.print(IMU.orientation(yaw, degrees));
    
    Brain.Screen.setCursor(1,1);
    Brain.Screen.print(IMU.orientation(yaw, degrees));
    Brain.Screen.setCursor(2,1);
    Brain.Screen.print("left motor A TEMP: ");
    Brain.Screen.print(leftMotorA.temperature(temperatureUnits::celsius));
    Brain.Screen.setCursor(3,1);
    Brain.Screen.print("left motor B TEMP: ");
    Brain.Screen.print(leftMotorB.temperature(temperatureUnits::celsius));
    Brain.Screen.setCursor(4,1);
    Brain.Screen.print("right motor A TEMP: ");
    Brain.Screen.print(rightMotorA.temperature(temperatureUnits::celsius));
    Brain.Screen.setCursor(5,1);
    Brain.Screen.print("right motor B TEMP: ");
    Brain.Screen.print(rightMotorB.temperature(temperatureUnits::celsius));
    Brain.Screen.setCursor(6,1);
    Brain.Screen.print("Flywheel TEMP: ");
    Brain.Screen.print(flywheel.temperature(temperatureUnits::celsius));
    Brain.Screen.print("   Flywheel2 TEMP: ");
    Brain.Screen.print(flywheel2.temperature(temperatureUnits::celsius));
  }

  void power_speed() {
    Brain.Screen.clearScreen();
    Brain.Screen.setCursor(1,1);
    Brain.Screen.print("left motor A Voltage (watts): ");
    Brain.Screen.print(leftMotorA.voltage());
    Brain.Screen.setCursor(2,1);
    Brain.Screen.print("left motor B Voltage (watts): ");
    Brain.Screen.print(leftMotorB.voltage());
    Brain.Screen.setCursor(3,1);
    Brain.Screen.print("right motor A Voltage (watts): ");
    Brain.Screen.print(rightMotorA.voltage());
    Brain.Screen.setCursor(4,1);
    Brain.Screen.print("right motor B Voltage (watts): ");
    Brain.Screen.print(rightMotorB.voltage());
    Brain.Screen.setCursor(5,1);
    Brain.Screen.print("left motor A SPEED (RPM 600 CAP): ");
    Brain.Screen.print(leftMotorA.velocity(velocityUnits::rpm));
    Brain.Screen.setCursor(6,1);
    Brain.Screen.print("left motor B SPEED (RPM 600 CAP): ");
    Brain.Screen.print(leftMotorB.velocity(velocityUnits::rpm));
    Brain.Screen.setCursor(7,1);
    Brain.Screen.print("right motor A SPEED (RPM 600 CAP): ");
    Brain.Screen.print(rightMotorA.velocity(velocityUnits::rpm));
    Brain.Screen.setCursor(8,1);
    Brain.Screen.print("right motor B SPEED (RPM 600 CAP): ");
    Brain.Screen.print(rightMotorB.velocity(velocityUnits::rpm));
  }

  void flywheel_info() {
    Controller1.Screen.clearScreen();
    Controller1.Screen.setCursor(1, 1);
    Controller1.Screen.print(flywheel_sped.velocity(velocityUnits::dps));
    Controller1.Screen.setCursor(2, 1);
    Controller1.Screen.print(IMU.orientation(yaw, degrees));
  }

};