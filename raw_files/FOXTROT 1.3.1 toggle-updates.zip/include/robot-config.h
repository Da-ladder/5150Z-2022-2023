using namespace vex;
#include <atomic>

extern brain Brain;

// VEXcode devices
extern smartdrive chassis;
extern controller Controller1;

extern motor_group leftDrive;
extern motor_group rightDrive;

extern motor leftMotorA;
extern motor leftMotorB;
extern motor rightMotorA;
extern motor rightMotorB;
extern motor flywheel;
extern motor flywheel2;
extern motor_group intake;
extern motor roller;

extern digital_out hopper_feed;
extern digital_out t_junction;


extern inertial IMU;
extern optical color_sense;

extern rotation lTracking;
extern rotation flywheel_sped;

extern double inchesToTicks(double inches);
extern double ticksToInches(double ticks);

extern void chassisControlTank();
extern void PrimaryControlMap();
extern void SecondaryControlMap();



// EXTERN GLOBAL VARIABLES
extern std::atomic<bool> auton_flywheel;
extern std::atomic<double> flywheel_velocity;
extern double auto_num;
extern bool confirm;
extern bool intake_toggle;
extern bool fly_tog;


/**
 * Used to initialize code/tasks/devices added using tools in VEXcode Pro.
 *
 * This should be called at the start of your int main function.
 */
void vexcodeInit(void);
