// CONTROLLER CODE
#include "objects.cpp"
#include "vex.h"
 using namespace vex;

//Odometry fucntion.
void Odometry (double xPos, double yPos, double hdg) { //Input parameters are where we want the robot to be.
  //Declarations
  double startY = 0.0; //Robot's starting yPos.
  double startX = 0.0; //Robot's starting xPos.
  double startHdg = 0.0; //Robot's starting heading/orientation.
 
  double currentY; //Robot's current yPos. Will be calculated every 20ms in a loop.
  double currentX; //Robot's current xPos. Will be calculated every 20ms in a loop.
  double currentHdg; //Robot's current heading. Will be calculated every 20ms in a loop.
 
  double leftVal; //Left encoder's current value.
  double rightVal; //Right encoder's current value.
  double backVal; //Back encoder's current value.
 
  int wheelDiam = 4; //Odometry wheel diameter.
  double disTrackL = 7.250; //Distance of left odom wheel from tracking center. In inches.
  double disTrackR = 7.250; //Distance of Right odom wheel from tracking center. In inches.
  double disTrackBack = 7.500; //Distance of back odom wheel from tracking center. In inches.

  double moveLeft; //Distance left odom wheel moves in inches. Calculated using odom wheel diameter.
  double moveRight;
  double moveBack; 

  double arcRadY; //Radius of arc made by left/right odom wheels. In inches.
  double arcRadX; //Radius of arc made by back odom wheel. In inches.
  
  //Calculations.
  while (1) {
    leftVal = Leftencoder.position(degrees); //Are degrees doubles?
    rightVal = Rightencoder.position(degrees);
    backVal = Backencoder.position(degrees);

    moveLeft = wheelDiam * (leftVal * (M_PI/180));
    moveRight = wheelDiam * (rightVal * (M_PI/180));
    moveBack = wheelDiam * (backVal * (M_PI/180));

    currentHdg = (moveLeft - moveRight)/(disTrackL + disTrackR); //Calculates current/new heading of robot.
    
    arcRadY = (moveRight/currentHdg) + disTrackR;
    arcRadX = (moveBack/currentHdg) + disTrackBack;
    
    currentY = 2 * (sin(currentHdg/2)) * arcRadY;
    currentX = 2 * (sin(currentHdg/2)) * arcRadX;

    //Makes changes to robot's position. CODE TO BE ADDED.

    //Prints calculated robot position.
    Controller1.Screen.setCursor(2, 1);
    Controller1.Screen.print("X pos: ");
    Controller1.Screen.print(currentX);
    
    Controller1.Screen.setCursor(3, 1);
    Controller1.Screen.print("Y pos: ");
    Controller1.Screen.print(currentY);
    
    Controller1.Screen.setCursor(3, 1);
    Controller1.Screen.print("Hdg: ");
    Controller1.Screen.print(currentHdg * (180/M_PI));
    
    wait(20, msec);
  }
}