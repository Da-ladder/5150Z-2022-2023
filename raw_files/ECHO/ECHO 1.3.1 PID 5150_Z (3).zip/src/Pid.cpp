#include "vex.h"
#include "objects.cpp"
 
using namespace vex;

struct IMU_PID {

  void test(double setpoint) { // The distance to be traveled by the robot is given in inches

  chassis_Set PIDcontrol; //Renames the entire structure of chassis_Set as PIDcontrol

  PIDcontrol.reset(); //resets the internal encoders inside of the motors of the chassis

  // Variables for correcting heading / direction the robot is facing
  double Heading_error_margin = 3; //should be positive number
  //double target_heading = IMU.angle(); // The heading the robot will aim for through the duration of the PID. not sure if we are using this
  double heading = IMU.angle();
  double lowerlimit = heading - Heading_error_margin;
  if (lowerlimit < Heading_error_margin) { Brain.Screen.print("Lower limit heading reached... proceeding"); } // HOTFIX diagnostic use
  double upperlimit = heading + Heading_error_margin;
  if (upperlimit >= 360) { Brain.Screen.print("Upper limit heading reached... proceeding"); } // HOTFIX diagnostic use
  //double Heading_correction_output = 0; // Not sure if we are using this or not

  // Variables for correcting the distance traveled by the robot
  double kP = 0.1, kI = 0.05, kD = 0.005; // Variables which tune the output of the robot
  double sens_avg = (leftMotorA.rotation(rotationUnits::raw) + // Average encoder values of the chassis motors
                    leftMotorB.rotation(rotationUnits::raw) + 
                    rightMotorA.rotation(rotationUnits::raw)+
                    rightMotorB.rotation(rotationUnits::raw)) /
                    4;
  double integral = 0;
  double derivative = 0;
  double prevError = 0;
  double output = 0;
  double errorMargin = 5; // Gives robot some space for errors and uncontrollable precision 
  setpoint = inchesToTicks(setpoint);
  double dis_error = setpoint - sens_avg; // Sets the error firt so the while loop can be triggered
    

  while (fabs(dis_error) > errorMargin) {
      double sens_avg = (leftMotorA.rotation(rotationUnits::raw) + // Average encoder values of the chassis motors
                    leftMotorB.rotation(rotationUnits::raw) + 
                    rightMotorA.rotation(rotationUnits::raw)+
                    rightMotorB.rotation(rotationUnits::raw)) /
                    4;
    dis_error = setpoint - sens_avg;
    integral += dis_error;
    // NOT SURE IF BELOW CODE WORKS PLZ TEST or is it even needed? Test this FLAG
    if (dis_error == 0 || dis_error > setpoint) {
      integral = 0;
    } else if (dis_error < -1000) {
      integral = 0;
    }
    // NOT SURE IF ABOVE CODE WORKS PLZ TEST FLAG
    derivative = dis_error - prevError;
    prevError = dis_error;
    output = ((dis_error * kP) + (integral * kI) +(derivative * kD));
    
    if(heading >= upperlimit){ // May need to make a formula to correct robot based on heading
      // makes robot turn left
      if (output >= 12) {
        PIDcontrol.move(output - 1, output); // Reduces power to the right side
      }
      PIDcontrol.move(output, output + 1); // Applies more power to the left side

    } else if (heading <= lowerlimit) {
      // makes robot turn right
      if (output >= 12) {
        PIDcontrol.move(output, output - 1); // Reduces power to the left side
      }
      PIDcontrol.move(output + 1, output); // Applies more power to the right side

    } else {
      if (output > 12) {
        output = 12;
      }
      PIDcontrol.move(output, output);
    }


    wait(20, msec);
  }
  PIDcontrol.brake(); // Sets the motors to brake
  }
  

};