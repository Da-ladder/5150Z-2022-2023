// CONTROLLER CODE
#include "objects.cpp"
#include "vex.h"

using namespace vex;

//Odometry fucntion. Place in parameters: double xPos, double yPos, double hdg
void Odometry () { //Input parameters are where we want the robot to be.
  //Declarations
  double currentY = 0; //Robot's current yPos. Will be calculated every 20ms in a loop.
  double currentX = 0; //Robot's current xPos. Will be calculated every 20ms in a loop.
  double currentHdg = 0; //Robot's current heading. Will be calculated every 20ms in a loop.
 
  double leftVal; //Left encoder's current value.
  double rightVal; //Right encoder's current value.
  double backVal; //Back encoder's current value.
 
  double wheelDiam = 2.75; //Odometry wheel diameter. In inches.
  //double disTrackL = 7.250; //Distance of left odom wheel from tracking center. In inches.
  double disTrackR = 1; //Distance of Right odom wheel from tracking center. In inches.
  double disTrackBack = 0; //Distance of back odom wheel from tracking center. In inches.

  double moveLeft; //Distance left odom wheel moves in inches. Calculated using odom wheel diameter.
  double moveRight;
  double moveBack; 

  double arcRadY; //Radius of arc made by left/right odom wheels. In inches.
  double arcRadX; //Radius of arc made by back odom wheel. In inches.
  
  //Calculations.
  while (1) { 
    rightVal = rTracking.position(degrees);
    backVal = bTracking.position(degrees);

    moveRight = wheelDiam * (rightVal * (M_PI/180));
    moveBack = wheelDiam * (backVal * (M_PI/180));

    currentHdg = IMU.heading() * (M_PI/180); //Function TBD. Also, remember to calibrate/zero heading.
    //currentHdg = (moveLeft - moveRight)/(disTrackL + disTrackR); //Calculates current/new heading of robot.
    
    arcRadY = (moveRight/currentHdg) + disTrackR;
    arcRadX = (moveBack/currentHdg) + disTrackBack;
    
    currentY = 2 * (sin(currentHdg/2)) * arcRadY;
    currentX = 2 * (sin(currentHdg/2)) * arcRadX;

    //Makes changes to robot's position. CODE TO BE ADDED.
    //Declares relevant variables.
      
      //double vector;
      //vector = currentHdg + (90 - (tan(yPos/xPos))); //Vector from robot's current pos to destination.

    //Prints calculated robot position.
    Controller1.Screen.setCursor(2, 1);
    Controller1.Screen.print("X pos: ");
    Controller1.Screen.print(currentX);
    
    Controller1.Screen.setCursor(3, 1);
    Controller1.Screen.print("Y pos: ");
    Controller1.Screen.print(currentY);
    
    Controller1.Screen.setCursor(4, 1);
    Controller1.Screen.print("Hdg: ");
    Controller1.Screen.print(currentHdg * (180/M_PI));
    
    wait(20, msec);
  }
}