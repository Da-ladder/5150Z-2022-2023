// CONTROLLER CODE
#include "objects.cpp"
#include "vex.h"

using namespace vex;
 
// DEFINES A AREA WHERE CONTROLLER WILL NOT ACCEPT INPUT
int deadzone = 10;

// FUNCTION THAT ALLOWS FOR CONTROL OF FLYWHEEL

void SecondaryControlMap() { //L1 controls.
  //Declarations
  double sensitivity = 1;
  double rOutput = 0, lOutput = 0;
  double power = 0, turn = 0;
  double leftJoystickVal = 0;
  double rightJoystickVal = 0;
  chassis_Set controls;
  
  //Button commands.
  if (Controller1.ButtonA.pressing()) {
    hopper_feed.set(true); // extends pneumatics for indexer
  } 
  else if (Controller1.ButtonY.pressing()){
    t_junction.set(true); // switches the t_junction to supply air to the endgame 
    wait(5, msec);
    grappling_hook.set(true);
  } 
  else if (Controller1.ButtonL2.pressing()){
    controls.launch(12); // Max flywheel voltage.
    
    //Prints flywheel rpm to controller screen.
    Controller1.Screen.setCursor(1, 1);
    Controller1.Screen.print("SPEED:  ");
    Controller1.Screen.print(flywheel.velocity(velocityUnits::rpm) * 6);
    
    hopper_feed.set(false);
  } 
  else if (Controller1.ButtonR1.pressing()){
    controls.launch(9); // Voltage of flywheel motors.
    
    //Prints flywheel rpm to controller screen.
    Controller1.Screen.setCursor(1, 1);
    Controller1.Screen.print("SPEED:  ");
    Controller1.Screen.print(flywheel.velocity(velocityUnits::rpm) * 6);
    
    hopper_feed.set(false);
  } 
  else {
    // retracts pneumatics/stops flywheel.
    hopper_feed.set(false); 
    t_junction.set(false);
    controls.launch(0);
  }

  leftJoystickVal = Controller1.Axis3.value();
  rightJoystickVal = Controller1.Axis1.value();
  power = (leftJoystickVal * sensitivity) / 10.58;
  turn = (rightJoystickVal * sensitivity) / 10.58;

   rOutput = -turn;
   lOutput = turn;
  //controls.launch(power);
  controls.move(rOutput, lOutput);

     if (Controller1.Axis3.value() < deadzone ||
       Controller1.Axis4.value() < deadzone ||
       Controller1.Axis2.value() < deadzone) {
     controls.stop_launch();
   }
}
// FUNCTION THAT ALLOWS FOR A ARCADE STYLE OF DRIVE
void PrimaryControlMap() {

  int leftJoystickVal = 0, rightJoystickVal = 0;
 
  // ALLOWS FOR CONTROLS TO BE TUNED TO DRIVER'S PREFRENCE
  double sensitivity = 1;
  double turn = 0, power = 0;
  double lOutput = 0, rOutput = 0;
 
  // CREATES AN OBJECT
  chassis_Set controls;
  hopper_feed.set(false);
 
  rightJoystickVal = Controller1.Axis3.value();
  leftJoystickVal = Controller1.Axis1.value();

  if (Controller1.ButtonB.pressing()) {
    intake.spin(fwd, 12, voltageUnits::volt); // Button B spins the intake forwards

  } else if (Controller1.ButtonX.pressing()) {
    intake.spin(fwd, -12, voltageUnits::volt); // Button X spins the intake backwards
  } else {
    intake.spin(fwd, 0, voltageUnits::volt);
  }
 
  turn = (leftJoystickVal * sensitivity) / 10.58; //Sets power 
  power = (rightJoystickVal * sensitivity) / 10.58;
 
  lOutput = turn + power;
  rOutput = -turn + power;
 
  // APPLIES POWER TO THE MOTOR FROM OBJECT
  controls.move(rOutput, lOutput);

 
  // CHECKS IF THE CONTROLS ARE MOVING IF NOT
  // SET MOTORS TO BRAKE
  if (Controller1.Axis3.value() < deadzone ||
      Controller1.Axis4.value() < deadzone ||
      Controller1.Axis2.value() < deadzone) {
    controls.brake();
   }
 }