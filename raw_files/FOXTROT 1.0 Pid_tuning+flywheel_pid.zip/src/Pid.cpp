#include "vex.h"
#include "objects.cpp"
#include <math.h>
 
using namespace vex;

//Function directly below is temp

struct IMU_PID {

  void rep_turn(double degree, double target_reps, double delay, bool right_turn) {
   IMU_PID auton;
   double current_rep = 0;
   while (current_rep != target_reps){
     auton.turn(degree, true);
     current_rep += 1;
     wait(delay, sec);
   }

  }

  void test(double setpoint) { // The distance to be traveled by the robot is given in inches

   chassis_Set PIDcontrol; //Renames the entire structure of chassis_Set as PIDcontrol

   PIDcontrol.reset(); //resets the internal encoders inside of the motors of the chassis

   lTracking.setPosition(0, deg); //RESETS the tracking wheel
   // KNOWN WORKING VALUES: kP = 0.75, kI = 0.0, kD = 7.4 // kD needs to be fine tuned for more presision
 
   // Variables for correcting the distance traveled by the robot
   double kP = 0.66, kI = 0.0, kD = 7.4; // Variables which tune the output of the robot VALUE TOO HIGH WILL CAUSE UNCONTROLLED MOVEMENT TOO LOW NO MOVEMENT  FLAG VALUE OVERHAUL???
   double sens_avg = lTracking.position(rotationUnits::deg);
   double integral = 0;
   double derivative = 0;
   double prevError = 0;
   double out2 = 0;
   double errorMargin = 3; // Gives robot some space for errors and uncontrollable precision 3 degs is around  
   setpoint = inchesToTicks(setpoint);
   double dis_error = setpoint - sens_avg; // Sets the error first so the while loop can be triggered

   while (fabs(dis_error) > errorMargin) {
     double sens_avg = lTracking.position(rotationUnits::deg);
     dis_error = setpoint - sens_avg;
     integral += dis_error;
    
     // NOT SURE IF BELOW CODE WORKS PLZ TEST or is it even needed? Test this FLAG Tbh we arent even using integral rn
     
     if (dis_error == 0 || dis_error > setpoint) {
       integral = 0;
     } else if (dis_error < 90000) { //FLAG PLZ
       integral = 0;
     }
     // NOT SURE IF ABOVE CODE WORKS PLZ TEST FLAG

     derivative = dis_error - prevError;
     prevError = dis_error;
     out2 = ((dis_error * kP) + (integral * kI) + (derivative * kD));
     std::cout << "out2 :" << out2 << std::endl;

       if (out2 > 12) {
         out2 = 12;
         PIDcontrol.move(out2, out2);
       } else {
         PIDcontrol.move(out2, out2);
       }
     PIDcontrol.move(out2, out2);
     wait(5, msec);
     Brain.Screen.clearScreen();
     std::cout << "dis_error :" << dis_error << "NEW BATCH" << std::endl; //endl starts new line COUT displays to monitor/TERMINAL
     std::cout << "derivative :" << derivative << std::endl; // REMOVE WHEN IN COMP MODE
     std::cout << "integral :" << integral << std::endl; //DISPLAY STATS TO TERMINAL THROUGH CONTROLLER WIRE EVERY 7 MSEC
     std::cout << "sens_avg :" << sens_avg << std::endl;
     
     
  }
  PIDcontrol.rest(); // Sets the motors to brake
  }


  
  void turn(double rotation, bool right_turn) { // double = 15 points of prescion enough 4 us

   chassis_Set PIDcontrol; //PREV Values = kP = 2.1, kI = 8.5, kD = 4.65 kp may need to be set higher for more presion add ki

   //double brain_line = 0;

   double kP = 2.2, kI = 8.5, kD = 4.85; // Variables which tune the output of the robot VALUE TOO HIGH WILL CAUSE UNCONTROLLED MOVEMENT TOO LOW NO MOVEMENT  FLAG
   double sens_avg = IMU.orientation(yaw, degrees); // Average encoder values of the chassis motors
   double integral = 0;
   double derivative = 0;
   double prevError = 0;
   double output = 0;
   double errorMargin = 1; // Gives robot some space for errors and uncontrollable precision  // was 5 before FLAG
   double rot_error = rotation - sens_avg;

   while (fabs(rot_error) > errorMargin) { 
     sens_avg = IMU.orientation(yaw, degrees);
     rot_error = rotation - sens_avg;
     integral += rot_error;

     if (rot_error == 0 || rot_error > rotation) {
       integral = 0;
     } else if (rot_error < 90000) { //FLAG PLZ
       integral = 0;
     }

     derivative = rot_error - prevError;
     prevError = rot_error;
     output = ((rot_error * kP) + (integral * kI) + (derivative * kD));

     if (output > 12) {
       output = 12;
     }

     if (right_turn) {
       PIDcontrol.move(-output, output);
     } else {
       PIDcontrol.move(output, -output);
     }
        
     std::cout << "rot_error :" << rot_error << "NEW BATCH" << std::endl; //endl starts new line COUT displays to monitor/TERMINAL
     std::cout << "derivative :" << derivative << std::endl; // REMOVE WHEN IN COMP MODE
     std::cout << "integral :" << integral << std::endl; //DISPLAY STATS TO TERMINAL THROUGH CONTROLLER WIRE EVERY 7 MSEC
     std::cout << "sens_avg :" << sens_avg << std::endl;
     std::cout << "output:" << output << std::endl;
     
     /*
     if(brain_line == 10){
       brain_line = 0;
       Brain.Screen.clearScreen();
       Brain.Screen.setCursor(1, 1);
     }
     Brain.Screen.print(IMU.orientation(yaw, degrees));
     Brain.Screen.newLine();
     brain_line += 1;
     */
     wait(7, msec);

   }
   Brain.Screen.print("TURN COMPLETE");
   std::cout << "FINAL ANGLE:" << IMU.orientation(yaw, degrees) << std::endl;
   PIDcontrol.rest();
  }
  
  

  void flywheel_tbh (double tbh_at_zero, double kp, double tbh_approx) {
    
    double current_velocity = flywheel_sped.velocity(velocityUnits::dps);
    double error = flywheel_velocity - current_velocity;
    double tbh = 0;
    //double kp = 1; //cal = speed ramp up time. also how to visulize data?
    double prev_error = 0;
    bool first_cross = true;
    //double tbh_approx = 0; //cal

    while (auton_flywheel) {
     current_velocity = flywheel_sped.velocity(velocityUnits::dps);
     error = flywheel_velocity - current_velocity;
     chassis_Set flywheel;

     tbh = tbh + (error * kp); //SET MAX VOLTAGE TO 12 AND LOWEST TO 0
     
     if (tbh > 12) {
       tbh = 12;
     } else if (tbh < 0) {
       tbh = 0;
     }


     if (signbit(error) != signbit(prev_error)) { // ZERO CROSSING CHECK
       if (first_cross) {
           tbh = tbh_approx; // FIRST TIME SET TO APPROX VALUES
           first_cross = false;
         } else {
           tbh = 0.5 * (tbh + tbh_at_zero); // TAKE BACK HALF ALGO
           tbh_at_zero = tbh;
         }
     }

     
     std::cout << "rot_error :" << error << "NEW BATCH" << std::endl; //endl starts new line COUT displays to monitor/TERMINAL
     std::cout << "derivative :" << tbh << std::endl; // REMOVE WHEN IN COMP MODE
     std::cout << "integral :" << tbh_approx << std::endl; //DISPLAY STATS TO TERMINAL THROUGH CONTROLLER WIRE EVERY 7 MSEC
     std::cout << "sens_avg :" << kp << std::endl;

     flywheel.fly_vol(tbh);
     prev_error = error;
     wait(10, msec);
    }

  }

};