// CONTROLLER CODE
#include "objects.cpp"
#include "vex.h"
 
using namespace vex;
 
// DEFINES A AREA WHERE CONTROLLER WILL NOT ACCEPT INPUT
int deadzone = 10;
double time_shot = 0;
// FUNCTION THAT ALLOWS FOR CONTROL OF FLYWHEEL

void intake_back() {
  if (intake.voltage() > 5) {
   intake.spin(fwd, 0, voltageUnits::volt);
  } else {
   intake.spin(fwd, 12, voltageUnits::volt);
  }
}

void intake_fwd() {
  if (intake.voltage() < -5) {
   intake.spin(fwd, 0, voltageUnits::volt);
  } else {
   intake.spin(fwd, -12, voltageUnits::volt);
  }
}

void SecondaryControlMap() {
  double sensitivity = 1;
  double rOutput = 0, lOutput = 0;
  double power = 0, turn = 0;
  double leftJoystickVal = 0;
  double rightJoystickVal = 0;
  chassis_Set controls;
  if(Controller1.ButtonX.pressing()){ intake.spin(fwd, -12, voltageUnits::volt); }
  if(Controller1.ButtonB.pressing()){ intake.spin(fwd, 12, voltageUnits::volt); }
  
  if (Controller1.ButtonA.pressing()) {
    hopper_feed.set(true); // extends pneumatics
  } else if (Controller1.ButtonY.pressing()){
    t_junction.set(true); // switches the t_junction to supply air to the endgame 
  } else if (Controller1.ButtonL2.pressing()){
    controls.fly_vol(10.3);
    Controller1.Screen.setCursor(1, 1);
    Controller1.Screen.print("SPEED:  ");
    Controller1.Screen.print((flywheel.velocity(velocityUnits::rpm) * 6 + flywheel2.velocity(velocityUnits::rpm) * 6) /2);
    hopper_feed.set(false);
  } else if (Controller1.ButtonR1.pressing()){
    if(Controller1.ButtonX.pressing()){ intake.spin(fwd, -12, voltageUnits::volt); }
    hopper_feed.set(false);
    double count = 0;
    controls.fly_vol(9); //10.3
    while (Controller1.ButtonR1.pressing()) { //see if X rumbles
      if (count == 50) {
        controls.fly_vol(8.7); //9.7
        Controller1.rumble(".");
      }
      if (Controller1.ButtonA.pressing()) { hopper_feed.set(true); }
      if(Controller1.ButtonX.pressing()){ intake.spin(fwd, -12, voltageUnits::volt); }
      count += 1;
      wait(20, msec);
      hopper_feed.set(false);
    }
  } else if (Controller1.ButtonB.pressing()) {
    while(Controller1.ButtonB.pressing()) {
      if (time_shot == 0 || time_shot == 50 || time_shot == 100) {
        hopper_feed.set(true);
      } else if (time_shot == 10 || time_shot == 60 || time_shot == 110) {
      hopper_feed.set(false);
      } 
      time_shot += 1;
      wait(20, msec);
    }
  } else {
    hopper_feed.set(false); // retracts pn
    t_junction.set(false);
    controls.fly_vol(0);
    time_shot = 0;
  }

  leftJoystickVal = Controller1.Axis3.value();
  rightJoystickVal = Controller1.Axis1.value();
  power = (leftJoystickVal * sensitivity) / 10.58;
  turn = (rightJoystickVal * sensitivity) / 10.58;

   rOutput = -turn;
   lOutput = turn;
  //controls.launch(power);
  controls.move(rOutput, lOutput);

     if (Controller1.Axis3.value() < deadzone ||
       Controller1.Axis4.value() < deadzone ||
       Controller1.Axis2.value() < deadzone) {
     controls.stop_launch();
   }
}
// FUNCTION THAT ALLOWS FOR A ARCADE STYLE OF DRIVE
void PrimaryControlMap() {


  int leftJoystickVal = 0, rightJoystickVal = 0;
 
  // ALLOWS FOR CONTROLS TO BE TUNED TO DRIVER'S PREFRENCE
  double sensitivity = 1;
  double turn = 0, power = 0;
  double lOutput = 0, rOutput = 0;
 
  // CREATES AN OBJECT
  chassis_Set controls;
  hopper_feed.set(false);
 
  rightJoystickVal = Controller1.Axis3.value();
  leftJoystickVal = Controller1.Axis1.value();

  if(Controller1.ButtonX.pressing()){ intake.spin(fwd, -12, voltageUnits::volt); } 
  else if (Controller1.ButtonB.pressing()) { intake.spin(fwd, 12, voltageUnits::volt); }
  else {intake.spin(fwd, 0, voltageUnits::volt); }
 
  turn = (leftJoystickVal * sensitivity) / 10.58; //Sets power 
  power = (rightJoystickVal * sensitivity) / 10.58;
 
  lOutput = turn + power;
  rOutput = -turn + power;
 
  // APPLIES POWER TO THE MOTOR FROM OBJECT
  controls.move(rOutput, lOutput);

 
  // CHECKS IF THE CONTROLS ARE MOVING IF NOT
  // SET MOTORS TO BRAKE
  if (Controller1.Axis3.value() < deadzone ||
      Controller1.Axis4.value() < deadzone ||
      Controller1.Axis2.value() < deadzone) {
    controls.brake();
   }
 }
